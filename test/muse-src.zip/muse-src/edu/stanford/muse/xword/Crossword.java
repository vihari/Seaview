/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.xword;

import java.io.IOException;
import java.io.Serializable;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;

import javax.mail.Address;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.store.LockObtainFailedException;

import edu.stanford.muse.exceptions.ReadContentsException;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.Document;
import edu.stanford.muse.index.EmailDocument;
import edu.stanford.muse.index.Lexicon;
import edu.stanford.muse.index.LuceneIndexer;
import edu.stanford.muse.index.NER;
import edu.stanford.muse.index.SentenceTokenizer;
import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.Util;

/** terminology: word is a canonicalized word, without spaces that is used for placing letters in the grid.
 * term/answer is the actual answer (which could be a phrase). typically is canonicalized to lower case, multiple spaces removed, etc.
 */
public class Crossword implements Serializable {
	private static final long serialVersionUID = 1L;
    public static Log log = LogFactory.getLog(Crossword.class);
    public static final char STOP = '-', EMPTY = 0; // special chars
	private static final int MAX_WORD_LENGTH = 12;
	private static final int MIN_WORD_LENGTH = 3;
	private static final int MIN_CLUE_LENGTH = 25; // absolute min. clue length
	private static final int MIN_PREFERRED_CLUE_LENGTH = 60;
	private static final int MAX_PREFERRED_CLUE_LENGTH = 100;
	private static final int MAX_ANSWER_WORDS = 10000; // we'll only consider the top 1000 words for placement in the grid
	private static final int MAX_TWIN_SEEK_LENGTH = 1000; // how far we'll go down the candidates list (from the beginning, not from the original twin!) to ensure symmetry
	
	// see http://www.letterfrequency.org/#three-letter-word-frequency for freqs
	private static String[] mostCommonTLWArray = new String[]{"the", "and", "for", "are", "but", "not", "you", "all", "any", "can", "her", "was", "one", "our", "out", "day", "get", "has", "him", "his", "how", "man", "new", "now", "old", "see", "two", "way", "who", "boy", "did", "its", "let", "put", "say", "she", "too", "use"};
	private static Set<String> mostCommonTLW = new LinkedHashSet<String>();
	static { 
		for (String w: mostCommonTLWArray)
			mostCommonTLW.add(w);
	}
	
	public static class Clue implements Serializable {
		public final static long serialVersionUID = 8699239120657874242L;

		String clue; // actual clue, with the answer blanked out
		public String getClue() {
			return clue;
		}
		public void setClue(String clue) {
			// canonicalize whitespace
			this.clue = clue;
		}
		String hint;
		public String getHint() {
			return hint;
		}
		public void setHint(String hint) {
			this.hint = hint;
		}		

		String fullSentence; // original sentence, not blanked out
		public String getFullSentence() {
			return fullSentence;
		}
		public void setFullSentence(String fullSentence) {
			this.fullSentence = fullSentence;
		}
		
		String url;
		public String getUrl() {
			return url;
		}
		
		String fullMessage;
		public String getMessage() {
			return fullMessage;
		}
		
		Document doc;
		public Document getDoc() {
			return doc;
		}

		long date; 
		Address to[], cc[], bcc[], from[];
		String subject;
				
		public Clue (String c, String full, String h, String u, String m, EmailDocument d) { 
			this.clue = c; this.fullSentence = full; this.hint = h; this.url = u; this.fullMessage = m; 
			this.date = d.date.getTime();
			// extract the relevant fields from the email doc.
			// gson doesn't like us storing the emaildoc directly inside the clue
			this.to = d.to;
			this.cc = d.cc;
			this.bcc = d.bcc;
			this.from = d.from;
			this.subject = d.description;
		}
		public String toString() { return this.clue; }
	}

    /** captures a placed word's text, coordinates */
	public static class Word implements Comparable<Word>, Serializable {
		public final static long serialVersionUID = 1604516333421018737L;
		public String word;
		int x, y; // starting x, y
		public boolean acrossNotDown;
		int clueNum = -1; // just indicates its uninitialized
		Clue clue;
		List<Integer> wordLens; // word lengths for multi-word answers, word is 7 letters, but broken up as (5,2)
		boolean intersects /* other words */;
		
		public List<Integer> getWordLens() { return wordLens; }
		public void setWordLens(List<Integer> wordLens) { this.wordLens = wordLens; }

		Word(String s, int x, int y, boolean acrossNotDown, boolean intersects) {
			this.word = s;
			this.x = x;
			this.y = y;
			this.acrossNotDown = acrossNotDown;
			this.intersects = intersects;
		}
		
		// not consistent with equals!
		public int compareTo(Word other)
		{
			if (acrossNotDown && !other.acrossNotDown)
				return -1;
			if (!acrossNotDown && other.acrossNotDown)
				return 1;
			// both have same direction
			if (this.y != other.y)
				return this.y - other.y;
			return this.x - other.x;
		}

		public static String getWordLens(List<Integer> wordLens)
		{
			StringBuilder sb = new StringBuilder();
			sb.append("(");
			if (wordLens != null)
			{
				for (int i = 0; i < wordLens.size(); i++)
				{
					sb.append(wordLens.get(i));
					if (i < wordLens.size()-1)
						sb.append(",");
				}
			}
			sb.append (")");
			return sb.toString();
		}
		
		public String toString() 
		{
			StringBuilder sb = new StringBuilder();
			sb.append ("at "  + x + "," + y);
			sb.append(" wordlen: ");
			if (wordLens != null)
				for (Integer wl: wordLens)
					sb.append (wl + "-");
			sb.append(" " + clueNum + " " + (acrossNotDown ? "across":"down") + ". " + word + " " + (clue == null ? "no clue":clue));
			if (!intersects)
				sb.append(" (may not intersect)");
			return sb.toString();
		}
		
		public void setClueNum(int num)	{ this.clueNum = num; }
		public void setClue(Clue c)	{ this.clue = c; }
		public Clue getClue() { return this.clue; }
		public int getClueNum() { return clueNum; }
	}
	
	public int w, h; // w should be = h
	private char[][] box; // chars in each box
	private char[][] current_state; // current state of chars; not used in this class, but this field is used by javascript in the UI
	private int[][] clueNums;
	List<Integer> boxToPlacedWordsIdxs[][];
	public List<Word> placedWords = new ArrayList<Word>();
	
	/** these transient fields will not be serialized when we emit the xword json */
	transient boolean cantStartFrom[][][];
	transient Set<String> candidateWords;
	transient Set<String> candidateWordPrefixes;
	transient private Map<String, String> wordToOriginalTerm = new LinkedHashMap<String, String>();
	transient Set<String> sentencesUsedAsClues = new LinkedHashSet<String>();
	transient public Random random;
	
	public Crossword (int w, int h)
	{
		this.w = w;
		this.h = h;
		box = new char[w][h]; // coords start from 0, 0 in top left.
		current_state = new char[w][h]; // coords start from 0, 0 in top left.
		for (int i = 0; i < w; i++)
			for (int j = 0; j < h; j++)
				box[i][j] = EMPTY;
		cantStartFrom = new boolean[w][h][2];
		boxToPlacedWordsIdxs = new List[w][h];
		resetRNG();
	}

	private static boolean stopOrEmpty(char c)
	{
		return c == EMPTY || c == STOP;
	}
	
	/** trim the trailing rows/cols of the crossword if applicable. but still keep it square */
	public void trimCrossword()
	{
		int MIN_SIZE_FOR_TRIM = 5;
		int size = this.h;

		outer:
		while (size > MIN_SIZE_FOR_TRIM)
		{
			// check for empty last row
			for (int i = 0; i < w; i++)
				if (!stopOrEmpty(box[i][size-1]))
					break outer;
			// check for empty last col
			for (int i = 0; i < h; i++)
				if (!stopOrEmpty(box[size-1][i]))
					break outer;
			--size;
		}
		if (size != this.h)
			log.info ("Trimming crossword size from " + this.h + " to " + size);
		this.h = this.w = size;
	}
	
	/** returns the word without spaces, after canonicalization (replaces periods and hyphens with spaces), along with the breakup of the words in the term */
	public static Pair<String,List<Integer>> convertTermToWord(String s)
	{
		StringTokenizer st = new StringTokenizer(s);
		String trimmedWord = "";
		List<Integer> list = new ArrayList<Integer>();
		while (st.hasMoreTokens())
		{
			String token = st.nextToken();
			trimmedWord += token;
			list.add(token.length());
		}
		return new Pair<String, List<Integer>>(trimmedWord, list);
	}
	
	public String getOriginalAnswer(String w)
	{
		return wordToOriginalTerm.get(w);
	}
	
	/** returns the longest string covering this sq in given direction, if c was inserted at the given location. 
	 * returns null if that string would just be the letter c. */
	String wordCoveringSq(int x, int y, char c, boolean acrossNotDown)
	{
		int incrX = acrossNotDown ? 1 : 0;
		int incrY = acrossNotDown ? 0 : 1;

		// go back as much as possible to find the beginning of the word
		int ix = x, iy = y;
		if (ix-incrX >= 0 && iy-incrY >= 0 && box[ix-incrX][iy-incrY] != 0 && box[ix-incrX][iy-incrY] != STOP)
		{
			ix -= incrX;
			iy -= incrY;
		}
		int startX = ix, startY = iy;
		
		// scroll forward to find the end of the word
		ix = x; iy = y;
		if (ix+incrX < w && iy+incrY < h && box[ix+incrX][iy+incrY] != 0 && box[ix+incrX][iy+incrY] != STOP)
		{
			ix += incrX;
			iy += incrY;
		}
		int endX = ix, endY = iy;

		// if len is 1, do an early out (because this method is perf. critical)
		if (endX == startX && endY == startY)
			return null;

		return "$!$!$"; // junk string to disallow prefix
		/*
		// len more than 1, build up the word
		ix = startX; iy = startY;
		StringBuilder sb = new StringBuilder();
		while (true)
		{
			if (ix == x && iy == y)
				sb.append(c); // c hasn't yet been introduced into the grid, so can't use box here
			else
				sb.append(box[ix][iy]);
			
			if (ix == endX && iy == endY)
				break;
			ix += incrX;
			iy += incrY;			
		}
		
		return sb.toString();
		*/
	}
	
	private void markCantStartFrom(int x, int y, int b)
	{
		if (x >= w || y >= h)
			return;
		if (log.isDebugEnabled())
			log.debug ("marking can't start from " + x + " " + y + " " + b);
		cantStartFrom[x][y][b] = true;
	}	
	
	private void markStop (int x, int y)
	{
		if (x < 0 || x >= w || y < 0 || y >= h)
			return;
		box[x][y] = STOP;
	}
	
	private boolean canStartFrom(int x, int y, int b)
	{
		return !cantStartFrom[x][y][b] && box[x][y] != STOP;
	}	
	
	private boolean willWordFitOnGrid(String word, int x, int y, boolean acrossNotDown)
	{
		int incrX = acrossNotDown ? 1 : 0;
		int incrY = acrossNotDown ? 0 : 1;
		
		// check if word will even fit in the grid
		// also, beyond the end must be empty or stop, can't be a letter
		int endX = x + word.length() * incrX;
		int endY = y + word.length() * incrY;					
		// if it goes beyond the edge of the grid, give up
		if (endX > w || endY > h) // note > not >=
			return false;
		
		// if endX = w or endY = h, we end at the edge, so no need to check 
		
		// if we end before the grid, the box beyond the end of the word must be empty or stop
		if (endX < w && endY < h)
		{
			// if we did reach the end of the board, no need to check this
			if (!stopOrEmpty(box[endX][endY]))
				return false;
		}
	
		return true;
	}

	// make sure word has only alpha's and num's.
	private static boolean wordHasOnlyLetters(String w)
	{
		for (char c: w.toCharArray())
			if (!Character.isLetter(c))
				return false;
		return true;
	}
	
	/** is the string s a prefix or suffix of any of the given words? */
	private static boolean prefixOrSuffixOfAny(Collection<Word> words, String s)
	{
		if (s == null)
			return true;
		
		for (Word w: words)
			if (w.word.startsWith(s) || s.startsWith(w.word))
			{
				log.info ("prefix:suffix relationship between " + s + " - and word in collection: " + w.word);
				return true;
			}
		return false;
	}
	
	/** can word fit at given position? */
	private boolean canWordFitAt(String word, int x, int y, boolean acrossNotDown, boolean mustIntersect)
	{
		if (box[x][y] == STOP)
			return false;
		int b = acrossNotDown ? 0 : 1;
		if (!canStartFrom(x, y, b))
			return false;
		if (!willWordFitOnGrid(word, x, y, acrossNotDown))
			return false;
	
		int incrX = acrossNotDown ? 1 : 0;
		int incrY = acrossNotDown ? 0 : 1;
		int ix = x, iy = y;
	
		int intersects = 0; // #intersects with existing chars
		for (int i = 0; i < word.length(); i++)
		{
			char c = word.charAt(i);
			if (box[ix][iy] == EMPTY || box[ix][iy] == c)
			{
				if (box[ix][iy] == word.charAt(i))
					intersects++;
				
				// check whether word formed by placing this square is viable in the orthogonal direction
				// need to check only if its > length 1
				String orthogonalWord = wordCoveringSq(ix, iy, c, !acrossNotDown);	
				if (log.isDebugEnabled())
					log.debug("word covering sq in orthogonal direction for (" + ix + "," + iy + " " + (acrossNotDown?"across":"down") + ") is " + orthogonalWord);
				if (orthogonalWord != null && orthogonalWord.length() > 1)
				{
					// check orthogonal word only if we are introducing a letter in an empty box.
					// if the letter already existed, no need to check.
					if (box[ix][iy] == EMPTY && !candidateWordPrefixes.contains(orthogonalWord))
					{
						log.debug("giving up because no prefixes match " + orthogonalWord);
						return false;
					}
				}
				ix += incrX;
				iy += incrY;
			}
			else
				return false;
		}
		
		if (intersects == 0 && mustIntersect)
		{
			log.debug("can place " + word + " but doesn't intersect with existing chars");
			return false;
		}
		return true;
	}

	/** returns twin word, if one can be placed. note: a word can be its own twin */
	private Word findTwinFor(Word W, boolean mustIntersect, Archive archive, Set<String> filteredIds, Lexicon lex) throws CorruptIndexException, LockObtainFailedException, IOException, ParseException, GeneralSecurityException, ClassNotFoundException, ReadContentsException
	{
		int twinX = w-1-W.x, twinY = h-1-W.y;
		if (W.acrossNotDown)
			twinX -= (W.word.length()-1);
		else
			twinY -= (W.word.length()-1);
		
		int x = twinX, y = twinY;
		
		boolean acrossNotDown = W.acrossNotDown;

		// this logic is a little complicated but its necessary.
		// we haven't updated the vox array to reflect W, so we have to careful that W and its twin don't overlap.
		// however, W can be its own twin(!)
		if (W.x == twinX && W.y == twinY)
			return W;

		// now check if W and twin overlap
		if (acrossNotDown && W.y == twinY)
		{
			int twinEndX = twinX+W.word.length()-1, WEndX = W.x + W.word.length()-1;
			if (W.x <= twinX && WEndX >= twinX) // twin is sandwiched between W
				return null;
			if (twinX <= W.x && twinEndX >= W.x) // W is sandwiched between twin
				return null;
		}
		else if (!acrossNotDown && W.x == twinX)
		{
			int twinEndY = twinY+W.word.length()-1, WEndY = W.y + W.word.length()-1;
			if (W.y <= twinY && WEndY >= twinY) // twin start overlaps with W sandwiched between W
				return null;
			if (twinY <= W.y && twinEndY >= W.y) // W is sandwiched between twin
				return null;
		}
			
		int count = 0;

		word_loop:
		for (Iterator<String> it = candidateWords.iterator(); it.hasNext(); )  
		{
			if (++count == MAX_TWIN_SEEK_LENGTH)
				break;
			String word = it.next();
			word = word.toLowerCase();
			if (word.length() != W.word.length())
				continue;
			if (word.equals(W.word))
				continue;
			
			/*
			if (prefixOrSuffixOfAny(placedWords, word))
			{
				// if w is a prefix/suffix of any word, remove it so we don't consider it again. (e.g. if we placed "american", remove "america"
				it.remove();
				continue;
			}
			*/
			// now walk through boxes at this position for each letter of the word
			if (log.isDebugEnabled())
				log.debug ("Trying " + word + " at (" + x + "," + y + ") " + (acrossNotDown ? "across":"down"));
	
			boolean possible = canWordFitAt(word, x, y, acrossNotDown, mustIntersect);
	
			if (possible) 
			{
				Word twin = new Word(word, x, y, acrossNotDown, mustIntersect);
				String originalAnswer = getOriginalAnswer(word);
				Pair<String, List<Integer>> p1 = Crossword.convertTermToWord(originalAnswer);
                twin.setWordLens(p1.getSecond());

				// check that the word actually has a clue
				if (archive != null)
				{
					Crossword.Clue clue = createClue(archive, filteredIds, originalAnswer, sentencesUsedAsClues, lex);
					if (clue == null)
					{
						log.info ("Almost placed " +  twin + " at (" + x + "," + y + ") " + (acrossNotDown ? "across":"down") + " but dropped because no good clue was found");
						log.info ("Discarding word " + word);
						//it.remove(); don't fiddle with the collection because the iterator is still working on the original list
						continue word_loop;
					}
					twin.setClue(clue);
				}
				return twin;
			}
		}
		return null;
	}
			
	/** try to place the word somewhere on the grid. returns the placed word, or null if it can't. note: word could have embedded spaces 
	 * if mustIntersect is true, it must intersect with existing chars on the grid
	 * returns pair of <placed word (null if not placed), discardWord>
	 * if discardWord is true, the word should never be attempted again because it doesn't have a good clue
	 * @throws ReadContentsException 
	 * @throws ClassNotFoundException 
	 * @throws GeneralSecurityException 
	 * @throws ParseException 
	 * @throws IOException 
	 * @throws LockObtainFailedException 
	 * @throws CorruptIndexException */
	private void placeWordsAndCreateClues (Archive archive, Set<String> filteredIds, Lexicon lex, boolean doSymmetric) throws CorruptIndexException, LockObtainFailedException, IOException, ParseException, GeneralSecurityException, ClassNotFoundException, ReadContentsException 
	{
		boolean preferAcrossNotDown = true;
		
		word_loop:
		for (Iterator<String> it = candidateWords.iterator(); it.hasNext(); )  
		{
			String word = it.next();
			
			if (prefixOrSuffixOfAny(placedWords, word))
			{
				// if w is a prefix/suffix of any word, remove it so we don't consider it again. (e.g. if we placed "american", remove "america"
				it.remove();
				continue;
			}
			
			// sweep entire grid in both directions trying to place this word
			for (int intersect = 0; intersect < 2; intersect++)
			{
				// prefer intersecting placements if possible
				boolean mustIntersect = (intersect == 0);
				if (intersect == 1 && placedWords.size() > 10)
					continue;
				//				if (!mustIntersect && placedWords.size() > 10)
				//					continue;

				for (int dir = 0; dir < 2; dir++)
				{
					// ... in both directions
					// 2 dirs, if preferAcrossNotDown: we first check across, then down. and vice versa
					// b = 0 captures across not down.

					int b = (preferAcrossNotDown == (dir == 0)) ? 0 : 1;
					boolean acrossNotDown = (b == 0);

					// sweep entire grid
					for (int xit = 0; xit < w; xit++)
						for (int yit = 0; yit < h; yit++)
						{
							int x = xit, y = yit;
							boolean possible = canWordFitAt(word, x, y, acrossNotDown, mustIntersect);

							if (possible) 
							{
								Word W1 = new Word(word, x, y, acrossNotDown, mustIntersect);
								String originalAnswer = getOriginalAnswer(word);
								Pair<String, List<Integer>> p1 = Crossword.convertTermToWord(originalAnswer);
                                W1.setWordLens(p1.getSecond());
                                  
								// check that the word actually has a clue
								if (archive != null)
								{
									Crossword.Clue clue = createClue(archive, filteredIds, originalAnswer, sentencesUsedAsClues, lex);
									if (clue == null)
									{
										log.info ("Almost placed " +  W1 + " at (" + x + "," + y + ") " + (acrossNotDown ? "across":"down") + " but dropped because no good clue was found");
										log.info ("Discarding word " + word);
										it.remove();
										continue word_loop;
									}
									W1.setClue(clue);
								}

								Word W2 = null;
								if (doSymmetric)
								{
									W2 = findTwinFor(W1, mustIntersect, archive, filteredIds, lex);
									// t his will already have clue set up for it
									possible = (W2 != null);
									if (W1 == W2)
										log.info ("Wow: word is its own twin: " + W1);
								}

								if (possible)
								{
									// commit W1 (and W2) if found
									commitWordToGrid(W1);
									placedWords.add(W1);
									log.info("FINALLY PLACED WORD AT: " + W1  + " with pref. across not down =" + preferAcrossNotDown);
									candidateWords.remove(W1.word);
									sentencesUsedAsClues.add(W1.clue.getFullSentence());
									
									// note W2 can be = W1 if its right in the center
									if (doSymmetric && W2 != W1)
									{
										commitWordToGrid(W2);
										placedWords.add(W2);
										log.info("FINALLY PLACED TWIN WORD AT: " + W2  + " with pref. across not down =" + preferAcrossNotDown);
										candidateWords.remove(W2.word);
										sentencesUsedAsClues.add(W2.clue.getFullSentence());
									}
									preferAcrossNotDown = !W1.acrossNotDown; // toggle after every placed word to balance between across and down
									it = candidateWords.iterator(); // start from the beginning
									continue word_loop;
								}
								else if (W1 != null)
									log.info("Almost placed WORD AT: " + W1  + " but no twin found");
							}
						}
				}
			}
		}
	}

	private void commitWordToGrid(Word W)
	{
		int ix = W.x, iy = W.y;
		boolean acrossNotDown = W.acrossNotDown;
		int incrX = acrossNotDown ? 1 : 0;
		int incrY = acrossNotDown ? 0 : 1;
		String word = W.word;
		
		markStop(ix-incrX, iy-incrY); // put a stop before this word 
		int b = (acrossNotDown?0:1);
		
		for (int i = 0; i < word.length(); i++) 
		{
			box[ix][iy] = word.charAt(i);
			markCantStartFrom(ix, iy, b);
			// note: if we're going horiz, can't start from adjacent Y (therefore ix + incrY not ix + incrX)
			markCantStartFrom(ix+incrY, iy+incrX, 1-b);
			ix += incrX;
			iy += incrY;
		}
		markStop(ix, iy); // put a stop at the end of the word
		
		log.info ("placing " +  W + " at (" + W.x + "," + W.y + ") " + (acrossNotDown ? "across":"down"));
	}

	/** places candidateWords on the grid and generates clues 
	 * @throws ReadContentsException 
	 * @throws ClassNotFoundException 
	 * @throws GeneralSecurityException 
	 * @throws ParseException 
	 * @throws IOException 
	 * @throws LockObtainFailedException 
	 * @throws CorruptIndexException */
	public void generateGrid(Archive archive, Set<String> filteredIds, Lexicon lex, boolean doSymmetric) throws CorruptIndexException, LockObtainFailedException, IOException, ParseException, GeneralSecurityException, ClassNotFoundException, ReadContentsException 
	{
		// compute all prefixes of all lengths, including the entire words themselves
		candidateWordPrefixes = new LinkedHashSet<String>();
		for (String cand: candidateWords)
			for (int i = 1; i <= cand.length(); i++)
				candidateWordPrefixes.add(cand.substring(0, i));
		log.info ("Placing " + candidateWords.size() + " candidates, " + candidateWordPrefixes.size() + " candidate prefixes");

		placedWords = new ArrayList<Word>();
		boolean preferAcrossNotDown = true;
		placeWordsAndCreateClues(archive, filteredIds, lex, doSymmetric);
		boolean mustIntersect = false; // false only for the first word
		
		assignClueNums();
		Collections.sort(placedWords);
		computeBoxToPlacedWordIdxs();
	}

	/** this is a map going from x, y to placed word idx's */
	private void computeBoxToPlacedWordIdxs()
	{
		// compute boxToPlacedWordsIdxs, make sure to do this after sorting placedWords
		for (int p = 0; p < placedWords.size(); p++)
		{
			Word w = placedWords.get(p);
			// add p to boxToPlacedWordsIdxs for all the letters for this word;

			int ix = w.acrossNotDown ? 1 : 0;
			int iy = !w.acrossNotDown ? 1 : 0;

			int x = w.x, y = w.y;	
			for (int i = 0; i < w.word.length(); i++, x += ix, y += iy)
			{
				// add this word to the list of words that span this box
				List<Integer> wordsForThisBox = boxToPlacedWordsIdxs[x][y];
				boolean insertAtBegin = false;
				if (wordsForThisBox == null)
					wordsForThisBox = boxToPlacedWordsIdxs[x][y] = new ArrayList<Integer>();
				else
				{
					// if this box belongs to 2 words, and the new word starts from this box, but the existing word did not, kill the existing word
					// because if we click on this box, we want it to fill the new word. 
					// update: we don't remove it but we will place at first
					Word existingWord = placedWords.get(wordsForThisBox.get(0));
					boolean thisBoxStartsExistingWord = existingWord.x == x && existingWord.y == y;
					boolean thisBoxStartsNewWord = w.x == x && w.y == y;
					if (thisBoxStartsNewWord && !thisBoxStartsExistingWord)
						insertAtBegin = true; // wordsForThisBox.clear(); // remove the existing word, because the current word overrides it
				}
				if (insertAtBegin)
					wordsForThisBox.add (0, p);
				else
					wordsForThisBox.add(p);
			}		
		}
	}

	/** assign clue numbers going from L->R and Top->Bottom in the grid */
	public void assignClueNums()
	{
		// mark all boxes+dir that are the starting of a placed word
		Word[][][] mark = new Word[w][h][2];
		for (Word w: placedWords)
			mark[w.x][w.y][w.acrossNotDown ? 0 : 1] = w;
		
		/** assign clue numbers going from L->R and Top->Bottom in the grid */
		clueNums = new int[w][h];
		int count = 1;
		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++)
			{
				boolean assigned = mark[j][i][0] != null || mark[j][i][1] != null;
				
				if (assigned && mark[j][i][0] != null)
					mark[j][i][0].setClueNum(count);
				if (assigned && mark[j][i][1] != null)
					mark[j][i][1].setClueNum(count);
				if (assigned)
				{
					clueNums[j][i] = count;
					count++;
				}
			}
	}
	
	
	/** checks if sentence is ok as clue. returns true if yes, false otherwise */
	public boolean sentenceIsValidAsClue(String lowerCaseSentence)
	{					
		if (lowerCaseSentence.indexOf("/") >= 0 || lowerCaseSentence.indexOf("|") >= 0 || lowerCaseSentence.indexOf(">") >= 0 || lowerCaseSentence.indexOf("---") >= 0 || lowerCaseSentence.indexOf("<") >= 0 || lowerCaseSentence.indexOf("___") >= 0) // get rid of things like http:// or >> or | quotes
			return false;
		if (lowerCaseSentence.charAt(0) < 'a' || lowerCaseSentence.charAt(0) > 'z')
			return false;
		if (lowerCaseSentence.startsWith("to")) // too generic
			return false;
		if (lowerCaseSentence.startsWith(")") || lowerCaseSentence.startsWith(","))
			return false;
		
		// unbalanced parens look ugly
		// unless they are in emoticons (so first nuke emoticons
		lowerCaseSentence = lowerCaseSentence.replaceAll("[:;][-][\\)\\(DP]", "");
		lowerCaseSentence = lowerCaseSentence.replaceAll("[:;][\\)\\(DP]", "");
		if (lowerCaseSentence.indexOf(")") >= 0 !=  lowerCaseSentence.indexOf("(") >= 0) 
			return false;
		
		if (lowerCaseSentence.indexOf("]") >= 0 !=  lowerCaseSentence.indexOf("[") >= 0) 
			return false;
		if (lowerCaseSentence.indexOf("html") >= 0) // junk like html randomly shows up sometimes
			return false;
		if (lowerCaseSentence.indexOf("@") >= 0)
			return false;
		
		// find cases where a period is not really the end of a sentence. this can be if the sentence ends with a single-letter dot.
		// or vs. or mr. or mrs.
		if (lowerCaseSentence.length() > 2 && Character.isWhitespace(lowerCaseSentence.charAt(lowerCaseSentence.length()-2)))
			return false;
		if (lowerCaseSentence.endsWith(" vs") || lowerCaseSentence.endsWith(" mr") || lowerCaseSentence.endsWith(" mrs"))
			return false;
		char char0 = lowerCaseSentence.charAt(0), char1 = lowerCaseSentence.charAt(1), char2 = lowerCaseSentence.charAt(2);
		if (Character.isDigit(char0) && Character.isDigit(char1) && Character.isSpaceChar(char2)) // happens for time 12:30 or 12.30
			return false;
		if (lowerCaseSentence.startsWith("edu")  || lowerCaseSentence.startsWith("com") || lowerCaseSentence.startsWith("net"))
			return false;
		if (lowerCaseSentence.indexOf("http") >= 0 || lowerCaseSentence.indexOf("=") >= 0) // also "=" because we see url params authKey=someLongHashCode
			return false;	

		return true;
	}	

	
	public void resetRNG() 
	{
		random = new Random(0);
	}
	
	/** replaced w in sentence with _ */
	private static String blankout(String sentence, String w)
	{
		String lowerCaseSentence = sentence.toLowerCase();
		w = w.toLowerCase();
		
		String blanks = w.replaceAll(".", "_"); // . (regexp) matches any char, so blanks is a string of _ of the same length as w
		lowerCaseSentence = lowerCaseSentence.replaceAll(w, blanks);
		char[] clueArray = new char[lowerCaseSentence.length()];
		
		// insert those blanks into the original sentence
		// we need to retain capitalization
		for (int i = 0; i < lowerCaseSentence.length(); i++)
			clueArray[i] = (lowerCaseSentence.charAt(i) == '_') ? '_' : sentence.charAt(i); // original sentence
		
		String c = new String(clueArray);
		return c;		
	}
	
	final static Set<String> goodSentiments = new LinkedHashSet<String>();
	static {
		goodSentiments.add("superlative");
		goodSentiments.add("congratulations");
		goodSentiments.add("wow");
		goodSentiments.add("confidential");
		goodSentiments.add("memories");
		goodSentiments.add("family");
		goodSentiments.add("life event");
		goodSentiments.add("religion");
		goodSentiments.add("festivals");
		goodSentiments.add("love");
		goodSentiments.add("vacations");
		goodSentiments.add("racy");
		goodSentiments.add("emergency");
		goodSentiments.add("grief");
	}
	
	// note: sentimentToDocs captures all docs in index, not just the filterDocIds
	// createClue will first filter 
	static Map<String, Set<Document>> sentimentToDocs = new LinkedHashMap<String, Set<Document>>();
	
	private static float scoreDocForSentiments(Document d)
	{
		float score = 1.0f;
		for (String sentiment: sentimentToDocs.keySet())
		{
			Set<Document> set = sentimentToDocs.get(sentiment);
			if (set != null && set.contains(d))
			{
				if (goodSentiments.contains(sentiment))
					score += 10.0; // increase by 10
				else
					score += 2.0;
			}
		}
		return score;
	}
	
		// returns a score for the given string as a clue
		private static float scoreClue(String s) throws ClassCastException, IOException, ClassNotFoundException
		{
			// first look for signs of bad clues and return a low score
			int maxTokenLength = Util.maxTokenLength(s);
			if (maxTokenLength > 20) // some token is very long... suspicious... seems to be a jumble of letters, 
				return -10.0f;
			
			if (s.startsWith("hello") || s.startsWith("hi ") || s.startsWith("regards, ") || s.startsWith("thanks, "))
				return -10.0f;
			if (s.indexOf("wrote:") >= 0)
				return -20.0f;		// lot of bad sentences like: "So-and-so wrote:..."

			// thank heavens. at least its a reasonable clue.
					
			// how many names does it have? more names is good.
			List<Pair<String, Float>> names = NER.namesFromText(s); // make sure we do NER before lower-casing
			s = s.toLowerCase();		
			float namesScore = names.size();
			
			// prefer exclamations, highly memorable
			float exclamationScore = (s.indexOf("!") >= 0) ? 10.0f : 0.0f;
				
			// good if it has emoticons
			float smileyScore = 0.0f;
			if (s.indexOf(":)") >= 0)
				smileyScore += 10;
			if (s.indexOf(":-)") >= 0)
				smileyScore += 10;
			if (s.indexOf(":(") >= 0)
				smileyScore += 10;
			if (s.indexOf(":-(") >= 0)
				smileyScore += 10;
			if (s.indexOf(";)") >= 0)
				smileyScore += 10;
			if (s.indexOf(";-)") >= 0)
				smileyScore += 10;
			
			// clue gets points if the closer it is to the preferred clue length
			// lengthBoost is really a penalty (its -ve)
			float lengthBoost = 0.0f;
			if (s.length() < MIN_PREFERRED_CLUE_LENGTH)
				lengthBoost = -10.0f * Math.abs((MIN_PREFERRED_CLUE_LENGTH - (float) s.length())/MIN_PREFERRED_CLUE_LENGTH);
			else if (s.length() > MAX_PREFERRED_CLUE_LENGTH)
				lengthBoost = -10.0f * Math.abs( (((float) s.length()) - MAX_PREFERRED_CLUE_LENGTH)/MAX_PREFERRED_CLUE_LENGTH );
			else
				lengthBoost = 0.0f;
					
	
			// these are things that make the clue less interesting, but we'll use them if we can't find anything else!
			// see if the sentence mainly consists of the word
//			int sChars = Util.nLetterChars(s);
//			int wChars = Util.nLetterChars(w);
//			if (sChars < wChars + 20)
//				score = -10.0f;
			float score = 1.0f + namesScore + exclamationScore + smileyScore + lengthBoost;
		//	if (log.isDebugEnabled())
			log.info ("score = " + score + " namesScore = " + namesScore + " exclamationScore = " + exclamationScore + " smileyScore = " + smileyScore + " lengthBoost = " + lengthBoost);
			return score;	
		}

	/** check if answer occurs only as a complete word in sentence. complete word => char before and after the answer is not a letter. 
	 * sentence, answer should already be space, case-canonicalized.
	 * note that answer could occur multiple times -- this method returns true if EVERY occurrence of answer is a word.
	 * e.g. for params ("americans in america", "america"), this method returns false
	 */
	private static boolean occursOnlyAsCompleteWord(String sentence, String answer)
	{
		// answer might be a partial match, e.g. india matches against "indians" in the sentence. disallow the match
		// if the char just before or just after the match is a letter. (it should be space or some delim)
		
		int idx = sentence.indexOf(answer); // answer is already lower case and space normalized... 
		if (idx < 0)
			return false;
		
		while (idx >= 0)
		{
			// idx is the position that has matched
			// see if the place before the match is a char
			if (idx > 0)
				if (Character.isLetter(sentence.charAt(idx-1)))
					return false;

			// see if the place after the match is a char
			int end_idx = idx + answer.length()-1;
			if (end_idx+1 < sentence.length())
				if (Character.isLetter(sentence.charAt(end_idx+1)))
					return false;
			
			// ok, so the match at idx succeeded.
			// look for more matches in this string
			// end_idx+1 is the delim for the prev. occurrence of answer, so now look for the answer again starting at end_idx+2
			if (end_idx+2 < sentence.length())
				sentence = sentence.substring(end_idx+2);
			else
				break; // we've reached the end
			idx = sentence.indexOf(answer); // answer is already lower case and space normalized... 
		}
		return true;
	}
	
	/** create clue for the given answer.
	    cannot pick clue from sentences that have taboo clues
	    if filterDocIds is not null, we use only clues from docs with ids in filterDocIds.
	 */
	public Crossword.Clue createClue(Archive archive, Set<String> filterDocIds, String answer, Set<String> tabooClues, Lexicon lex) throws CorruptIndexException, LockObtainFailedException, IOException, ParseException, GeneralSecurityException, ClassNotFoundException, ReadContentsException
	{
		LuceneIndexer li = (LuceneIndexer) archive.indexer;
		// first canonicalize w
		answer = answer.toLowerCase();
		Set<EmailDocument> docs = li.luceneLookupDocs("\"" + answer + "\""); // safer to look up inside double quotes since answer may contain blanks
		int docNum = 0; 
		
		List<EmailDocument> candidates = new ArrayList<EmailDocument>();
		for (EmailDocument ed: docs)
			candidates.add(ed);

		// lucenelookupDocs returns emails sorted by time
		// permute the candidates randomly otherwise lots of clues might be from nearby docs, e.g. from the same time range in the corpus
		/*
		for (int i = 0; i < candidates.size()-1; i++)
		{
			int idx = i + random.nextInt(candidates.size() - i);
			// interchange idx and i
			EmailDocument tmp = candidates.get(idx);
			candidates.set(idx, candidates.get(i));
			candidates.set(i, tmp);
		}
		*/
		
		// now look for the clue with the best score
		Clue bestClue = null; 
		float bestScore = -100.0f;
	
		// we want a good pool of docs to select clues from. at the same time, we don't want to look at ALL docs with the term because the
		// number could be very large. so we look at at least N_DOCS_TO_CHECK_AT_LEAST and return the best from it.
		int N_DOCS_TO_CHECK_FOR_CLUES = 50;
		int count = 0;
		for (EmailDocument ed: candidates)
		{
			if (filterDocIds != null && !filterDocIds.contains(ed.getUniqueId()))
				continue; // not in filter docs, so can't use this doc
			
			// ok, we've looked at the min. # of docs, return the best clue if there is one
			if (count >= N_DOCS_TO_CHECK_FOR_CLUES)
				if (bestClue != null)
					return bestClue;
			count++;

			float docScore = scoreDocForSentiments(ed);
			List<String> names = archive.indexer.getNamesForDocId(ed.getUniqueId());
			if (names.size() > 10)
			{
				docScore /= names.size(); // drastic cutoff in doc score if there are a lot of names in it (typically a complete news article)
				log.info("devalued " + names.size() + " names in doc " + ed + ": " + Util.join(names, " | "));
			}
			
			Set<String> namesSet = new LinkedHashSet<String>();
			for (String name: names)
				namesSet.add( Util.canonicalizeSpaces(name.toLowerCase()));

			if (!namesSet.contains(Util.canonicalizeSpaces(answer.toLowerCase())))
			{
				docScore /= 10;
//				log.info("Sorry! namesset for doc \"" + ed + "\" does not contain: " + answer + " names: " + Util.join(names,  " | "));
			}

			try {
				String contents = archive.getContents(ed);
				SentenceTokenizer st = new SentenceTokenizer(contents);
				int sentenceNum = 0;

				outer:
				while (st.hasMoreSentences())
				{				
					sentenceNum++;
					String sentence = st.nextSentence(true); // include trailing delim
					sentence.replaceAll("\r", "\n"); // weird DOS type stuff has \r's sometimes

					// 1 newline is normal, but 2 or more is bad...it tends to be a signature or list... doesn't make for a good clue.
					float linesBoost = 1.0f;
					int nLines = new StringTokenizer(sentence, "\n").countTokens();
					if (nLines > 2)
						linesBoost = (float) -Math.pow(5.0f, nLines-1); // steep penalty if it spans more than one line
				
					sentence = sentence.trim().replaceAll("\n", " ");
					sentence = Util.canonicalizeSpaces(sentence);
					String lowerCaseSentence = sentence.toLowerCase();

					if (!occursOnlyAsCompleteWord(lowerCaseSentence, answer))
						continue;
					

					int MAX_CLUE_CHARS = 200;
					
					if (sentence.length() >= MAX_CLUE_CHARS)
						continue;

					// check if #letter chars in sentence = #letters chars in word.
					// we can't just check length of sentence == length of word
					// because sometimes we get a sentence like <X + punctuation> as a clue for X and we want to eliminate such sentences
					if (Util.nLetterChars(sentence) == Util.nLetterChars(answer))
						continue; 

					if (!sentenceIsValidAsClue(lowerCaseSentence))
						continue;

					sentence = sentence.replaceAll("\n", " ");
					
					if (tabooClues != null && (tabooClues.contains(lowerCaseSentence) || tabooClues.contains(sentence)))
						continue;
					if (sentence.length() < MIN_CLUE_LENGTH)
						continue;					

					// now score the sentence

					String unblankedLowerCaseSentence = lowerCaseSentence;
					String blankedSentence = blankout(sentence, answer);
					String hint = ed.toStringAsHint();
					String blankedHint = blankout(hint, answer);
					String url = "browse?docId=" + ed.getUniqueId();
					String fullMessage = archive.getContents(ed);
					fullMessage = Util.ellipsize(fullMessage, 3000); 
					Clue clue = new Clue(blankedSentence, unblankedLowerCaseSentence, blankedHint, url, fullMessage, ed);
					float clueScore = scoreClue(sentence);

					// a small boost for sentences earlier in the message -- other things being equal, they are likely to be more important
					float sentenceNumBoost = -0.2f*sentenceNum;
					log.info ("clue score for " + answer + " is " + clueScore + " sentence num boost = " + sentenceNumBoost);
					clueScore += docScore;
					clueScore += sentenceNumBoost;
					clueScore += linesBoost;
					
					log.info ("clue score for " + answer + " is " + clueScore + " (docscore: " + docScore + ") for sentence# " + sentenceNum + " in doc #" + docNum + ":" + clue + " lines boost = " + linesBoost);
					
					if (clueScore > bestScore)
					{
						log.info ("Prev. clue: New high!");
						bestClue = clue;
						bestScore = clueScore;
					}
				}
			} catch (Exception e) { Util.print_exception(e, log); }
			docNum++;
		}
		return bestClue;
	}

	private static String cleanCandidate(String t)
	{
		// replace periods and hyphens
		t = t.replaceAll("\\.", " ");
		t = t.replaceAll("-", " ");
		t = Util.canonicalizeSpaces(t);
		t = t.trim();
		return t;
	}
	
	/** removes periods, hyphens, canonicalizes spaces, trims */
	private static List<String> cleanCandidates(List<String> terms)
	{
		List<String> result = new ArrayList<String>();
		for (String t: terms)
			result.add(cleanCandidate(t));
		return result;
	}

	/** removes the terms that are bad as answers */
	private static List<String> removeBadCandidates(List<String> terms, Set<String> tabooTerms)
	{
		// create list of candidates words 
		List<String> result = new ArrayList<String>();
		int count = 0;
		for (String term: terms) 
		{			
			term = term.toLowerCase();
			term = Util.canonicalizeSpaces(term);
			
			// eliminate own name from the candidates, its too obvious for a puzzle
			if (tabooTerms.contains(term))
				continue;
			
			if (term.equals("thu") || term.equals("sun") || term.equals("mon")
					|| term.equals("tue") || term.equals("wed")
					|| term.equals("fri") || term.equals("sat"))
				continue;
			if (term.equals("jan") || term.equals("feb") || term.equals("mar")
					|| term.equals("apr") || term.equals("may")
					|| term.equals("jun") || term.equals("jul")
					|| term.equals("aug") || term.equals("sep")
					|| term.equals("oct") || term.equals("nov")
					|| term.equals("dec"))
				continue;
			
			if (term.equals("fyi") || term.equals("pdf") || term.equals("yahoo") || term.equals("rsvp") || term.equals("eur") || term.equals("usd") || term.equals("llc") || term.equals("url") || term.equals("asap") || term.equals("hope") || term.equals("room") || term.equals("nice") || term.equals("free") || term.equals("sorry") 
					|| term.equals("pst") || term.equals("est") || term.equals("cst") || term.equals("gmt") || term.equals("ust"))
				continue;
			if (term.equals("messages") || term.equals("reply"))  /* yahoo mailing list */ 
				continue;
			if (mostCommonTLW.contains(term))
				continue;

			// some sanity checks on whether this is a good word to use
			
			if (term.length() <= 2)
				continue;

			// hope and nice are frequently recognized as names... Hope it goes well... Nice to hear from you
			if (term.indexOf('&') >= 0)
				continue;
			if (term.endsWith(".")) // this tends to be names that are recog. along with a period. e.g. "Guil." in Hamlet. These tend to be bad words (could also happen for titles like Mr.?)
				continue;
	
			// check word len (without spaces)
			String word = term.replaceAll(" ", "");
			if (word.length() > MAX_WORD_LENGTH || word.length() < MIN_WORD_LENGTH) {
				log.info("Dropping answer word due to length: " + word);
				continue;
			}

			result.add(term);
			count++;
			if (count >= MAX_ANSWER_WORDS)
				break;
		}
		log.info ("after removing bad candidates, answer terms: " + result.size() + " original terms: " + terms.size());
		return result;
	}
	
	/** create xword of the given size from possibleAnswers (in decreasing order of preference), with clues drawn from the filtered ids */
	public static Crossword createCrossword(List<Pair<String, Integer>> possibleAnswersAndWeight, int size, Archive archive, Lexicon lex, Set<String> filteredIds, Set<String> tabooWords, boolean doSymmetric) throws CorruptIndexException, LockObtainFailedException, IOException, ParseException, GeneralSecurityException, ClassNotFoundException, ReadContentsException
	{		
		List<String> possibleAnswers = new ArrayList<String>();
		Map<String, Float> originalWeights = new LinkedHashMap<String, Float>();
		for (Pair<String, Integer> p: possibleAnswersAndWeight) 
		{
			possibleAnswers.add(p.getFirst());
			originalWeights.put(cleanCandidate(p.getFirst()), (float) p.getSecond());
		}
		
		long startTimeMillis = System.currentTimeMillis();
		int nMessages = ((archive != null) ? archive.getAllDocs().size() : 0);
		if (filteredIds != null)
			nMessages = filteredIds.size();
		int nTabooWords = (tabooWords != null) ? tabooWords.size():0;
		log.info ("Starting crossword generation with " + nMessages + " messages, " + possibleAnswers.size() + " possible answers, " + nTabooWords + " taboo words");
		Crossword c = new Crossword(size, size);
		if (archive != null)
			sentimentToDocs = archive.getSentimentMap(lex); // note this does not take filtered ids into account, createClue will use the filterIds first before looking up sentiments
		
		Map<String, Collection<String>> wordToSentiments = new LinkedHashMap<String, Collection<String>>();
		
		for (String s: sentimentToDocs.keySet())
		{
			Collection<Document> docs = sentimentToDocs.get(s);
			log.info (docs.size() + " docs for sentiment:" + s);
			for (Document d: docs)
			{
				log.info ("     " + d + Util.join (archive.indexer.getNamesForDocId(d.getUniqueId()), " | "));
				for (String n: archive.indexer.getNamesForDocId(d.getUniqueId()))
				{
					Collection<String> coll = wordToSentiments.get(n);
					if (coll == null)
					{
						coll = new LinkedHashSet<String>();
						wordToSentiments.put(n,  coll);
					}
					coll.add(s);
				}
			}
		}

/*		log.info ("Sentiments associated with terms:");
		wordToSentiments = Util.sortMapByListSize(wordToSentiments);
		for (String w: wordToSentiments.keySet())
		{
			StringBuilder sb = new StringBuilder("Sentiments for " + w + ": ");
			for (String s: wordToSentiments.get(w))
				sb.append (s + " ");
			log.info (sb);
		}
	*/	
		// clean and filter the answers first
		possibleAnswers = Crossword.cleanCandidates(possibleAnswers);
		Set<String> ownNameTerms = new LinkedHashSet<String>();
		if (archive != null && archive.addressBook != null)
		{			
			Set<String> ownNames = archive.addressBook.getOwnNamesSet();
			for (String n: ownNames)
			{
				n = Util.canonicalizeSpaces(n);
				n = n.toLowerCase();
				ownNameTerms.add(n);
				ownNameTerms.addAll(Util.tokenize(n));
			}			
		}
		
		// filter the possibleanswers down to a feasible candidate list
		possibleAnswers = removeBadCandidates(possibleAnswers, ownNameTerms);
		
		c.candidateWords = new LinkedHashSet<String>();
		c.wordToOriginalTerm = new LinkedHashMap<String, String>();
		for (String s: possibleAnswers)
		{
			String originalAnswer = s; // original answer is what will be used for clue lookup
			// canonicalize te-yuan, u.s., i.b.m. to "te yuan", "u s", "i b m"
			Pair<String, List<Integer>> p = Crossword.convertTermToWord(s);
			String word = p.getFirst();
			if (word.length() < 3) // drop 2 letters, they tend to be acronyms, like "u.s." and are often hard to guess
				continue;
			if (tabooWords != null && tabooWords.contains(word))
				continue;
			c.candidateWords.add(word);
			c.wordToOriginalTerm.put(word, originalAnswer);
		}

		//List<String> list = new ArrayList<String>(c.candidateWords);
		//computeLetterFreqs(list, originalWeights);
		/*
		sortCandidateWordsByLength(list);
		c.candidateWords = new LinkedHashSet<String>(list);
		*/
		log.info ("generating grid from " + c.candidateWords.size() + " words " + " size = " + c.w + "x" + c.h);
		
		// place words on grid, creating clues along the way
		c.generateGrid(archive, filteredIds, lex, doSymmetric);
		c.trimCrossword();
		log.info ("generated grid from " + c.candidateWords.size() + " words " + " size = " + c.w + "x" + c.h + " in " + Util.commatize(System.currentTimeMillis()-startTimeMillis) + "ms");
		log.info (c.toString());

		return c;
	}
	
	public static void sortCandidateWordsByLength(List<String> words)
	{
		Collections.sort(words, new Comparator<String>() { 
			public int compare(String s1, String s2) {
				return s1.length() - s2.length();
			}
		});
	}
	

	public static void computeLetterFreqs(List<String> words, Map<String, Float> weights)
	{
		Map<Character, Integer> charFreqs = new LinkedHashMap<Character, Integer>();
		for (String w: words)
		{
			for (char c: w.toCharArray())
			{
				Integer I = charFreqs.get(c);
				if (I != null)
					charFreqs.put(c, I+1);
				else
					charFreqs.put(c, 1);
			}
		}
		
		List<Pair<Character, Integer>> pairs = Util.sortMapByValue(charFreqs);
		for (Pair<Character, Integer> p: pairs)
			log.info ("freq of " + p.getFirst() + " is " + p.getSecond());
		
		final Map<String, Float> costMap = new LinkedHashMap<String, Float>();
		for (String w: words)
		{
			float cost = 0;
			for (char c: w.toCharArray())
			{
				int count = charFreqs.get(c);
				cost += 1.0/count;
			}
			costMap.put(w, cost);
		}
		
		List<Pair<String, Float>> fpairs = Util.sortMapByValue(costMap);
		for (Pair<String, Float> p: fpairs)
			log.info ("cost of " + p.getFirst() + " is " + p.getSecond() + " (weight: " + weights.get(p.getFirst()));
		
		Collections.sort(words, new Comparator<String>() { 
			public int compare(String s1, String s2) {
				return (costMap.get(s1) - costMap.get(s2)) > 0 ? 1 : -1;
			}
		});
	}
	
	public String toString() 
	{
		StringBuilder sb = new StringBuilder();
		sb.append (placedWords.size() + " placed words\n");
		for (int j = 0; j < h; j++)
		{
			for (int i = 0; i < w; i++)
			{
				char c = box[i][j];
				if (c == EMPTY)
					c = '#';	
				sb.append (c + " ");
			}
			sb.append('\n');
		}
		
		for (Word w: placedWords)
			sb.append (w + "\n");
		sb.append (stats());

		return sb.toString();
	}
	
	public String toHTMLString(boolean printAnswers) 
	{
		StringBuilder sb = new StringBuilder();
		for (int j = 0; j < h; j++)
		{
			for (int i = 0; i < w; i++)
			{
				char c = box[i][j];
				String s = "_", css_class = "empty";
				if (c == EMPTY)
					css_class = "empty";
				else if (c == STOP)
					css_class = "stop";
				else
				{
					s = printAnswers ? Character.toString(c) : "_";
					css_class = "letter";
				}
				String clueNumSpan = "";
				if (clueNums[i][j] != 0)
					clueNumSpan = "<span class=\"cluenum-in-box\">" + clueNums[i][j] + "</span>";
				sb.append ("<div class=\"box " + css_class + "\">" + clueNumSpan + s + "</div>");
			}
			sb.append("<div class=\"endRow\"></div>");
		}
		return sb.toString();
	}

	public String stats() 
	{
		int count = 0; 
		for (char[] col: box)
			for (char c: col)
				if (c != STOP && c != EMPTY)
					count++;
		int pct_filled = (int) (100 * count)/(w*h);		
//		return count + "/" + (w*h) + " boxes filled (" + pct_filled + "%)";
		
		int sum = 0;
		for (int i = 0; i < boxToPlacedWordsIdxs.length; i++)
			for (int j = 0; j < boxToPlacedWordsIdxs[0].length; j++)
				if (boxToPlacedWordsIdxs[i][j] != null)
					sum += boxToPlacedWordsIdxs[i][j].size();
		
		return count + "/" + (w*h) + " squares filled (occupancy:" + pct_filled + "%) " + String.format("%.2f", (sum*1.0/count)) + " words/letter";
	}
	
	public static void main (String args[]) throws CorruptIndexException, LockObtainFailedException, IOException, ParseException, GeneralSecurityException, ClassNotFoundException, ReadContentsException
	{
	    String[] test1 = {
	    		"Aberi",
	    			"Abheri",
	    			"Abhogi",
	    			"Adbut kalyan",
	    			"Alhaiya Bilawal",
	    			"Ambika",
	    			"Anand kalyan",
	    			"Asavari",
	    			"Bageshree",
	    			"Bagesree Kanada",
	    			"Bagesree-Suddha",
	    			"Bahar",
	    			"Bairagi Bhairav",
	    			"Basant",
	    			"Basant Mukhari",
	    			"Begada",
	    			"Behag",
	    			"Bhairav",
	    			"Bhairavi",
	    			"Bhimpalas",
	    			"Bhimpalasi",
	    			"Bhoop",
	    			"Bihag",
	    			"Bilahari",
	    			"Bilaval",
	    			"Bilawal",
	    			"Brindavani Sarang",
	    			"Champakali",
	    			"Champok",
	    			"Chandrakauns",
	    			"Chandrika",
	    			"Chhaya",
	    			"Deepak",
	    			"Desh",
	    			"Deshkar",
	    			"Desi",
	    			"Devagandhari",
	    			"Devaranji",
	    			"Dhana",
	    			"Dhanasari",
	    			"Dhanashree",
	    			"Dhanasri",
	    			"Dhani",
	    			"Dhanyasi",
	    			"Dharmavati",
	    			"Dheera",
	    			"Dhwani",
	    			"Durga",
	    			"Dwijavanthi",
	    			"Gara",
	    			"Gauri",
	    			"Giri",
	    			"Girija",
	    			"Gopi",
	    			"Gopikabasant",
	    			"Hameer",
	    			"Hamir",
	    			"Hamsadhwani",
	    			"Hamsakalyan",
	    			"Hamsanadham",
	    			"Hamsanandi",
	    			"Hanumathodi",
	    			"Hemakalyan",
	    			"Hemant",
	    			"Hindol",
	    			"Hindolam",
	    			"Jaijaiwanti",
	    			"Jait",
	    			"Jaitkalyan",
	    			"Jaunpuri",
	    			"Jeevanpuri",
	    			"Jinjhoti",
	    			"Jog",
	    			"Kafi",
	    			"Kalavati",
	    			"Kalyan",
	    			"Kalyani",
	    			"Kamalamanohari",
	    			"Kamavardani",
	    			"Kambhoji",
	    			"Kanakavarali",
	    			"Kapi",
	    			"Karaharapriya",
	    			"Kedar",
	    			"Kedaram",
	    			"Khamaj",
	    			"Lalit",
	    			"Maand",
	    			"Madhumad",
	    			"Madhyamavati",
	    			"Malayamarutham",
	    			"Malhar",
	    			"Malkauns",
	    			"Manavi",
	    			"Manohari",
	    			"Manorama",
	    			"Marwa",
	    			"Matura",
	    			"Mohan Kalyan",
	    			"Mohana",
	    			"Mohanam",
	    			"Multani",
	    			"Nagaswaravali",
	    			"Nagavarali",
	    			"Nagavari",
	    			"Nalinakanti",
	    			"Nand",
	    			"Nat bhairav",
	    			"Nata Narayani",
	    			"Pahadi",
	    			"Palasi",
	    			"Patamanjari",
	    			"Patdeep",
	    			"Pilu",
	    			"Poorvi",
	    			"Puriya",
	    			"Purvi",
	    			"Pushpalatika",
	    			"Shahana",
	    			"Shankara",
	    			"Shankarabharanam",
	    			"Shree",
	    			"Shuddha kalyan",
	    			"Sohni",
	    			"Suha kanada",
	    			"Tilak kamod",
	    			"Tilang",
	    			"Todi",
	    			"Udaya",
	    			"Vanthi",
	    			"Varam",
	    			"Varata",
	    			"Varati",
	    			"Yaman",
	    			"Yaman kalyan"
	    };
	    
	    String[] test = {"abhogi", 
	    		"adana",
	    		"ahir bhairav",
	    	//	"anandi kalyan",
	    		"asavari",
	    		"bageshree",
	    	//	"bageshwari",
	    		"bageshree kauns",
	    		"bahar",
	    		"bahaduri todi",
	    		"bairagi",
	    		"bairagi bhairav",
	    		"basant",
	    		"basant mukhari",
	    		"bhairav",
	    		"bhairavi",
	    		"bhankar",
	    		"bhatiyar",
	    		"bhimpalas",
	    		"bhinna shadja",
	    		"bhoopal todi",
	    		"bhoopali",
	    		"bhoop",
	    		"bihag",
	    		"bihagda",
	    		"bilaskhani todi",
	    		"bilawal",
	    		"brindavani sarang",
	    		"alhaiya bilawal",
	    		"chandni kedar",
	    		"chandrakauns",
	    		"charukeshi",
	    		"chhayanat",
	    		"darbari",
	    		"darbari kanada",
	    		"desh",
	    		"deshkar",
	    		"deskar",
	    		"des",
	    		"desi",
	    		"desi todi",
	    		"dhani",
	    		"durga",
	    		"gara",
	    		"gaud malhar",
	    		"gaud sarang",
	    		"gorakh kalyan",
	    		"gunkali",
	    		"gujri todi",
	    		"hameer",
	    		"hamsadhwani",
	    		"hindol",
	    		"jaijaiwanti",
	    		"janasammohini",
	    		"jaunpuri",
	    		"jhinjhoti",
	    		"jogiya",
	    		"jog",
	    		"jogkauns",
	    		"kafi",
	    		"kafi kanada",
	    		"kalavati",
	    		"kalingada",
	    		"kalashree",
	    		"kamod",
	    		"kedar",
	    		"khamaj",
	    		"kirwani",
	    		"lalit",
	    		"lalit pancham",
	    		"madhuvanti",
	    		"madhmad sarang",
	    		"malgunji",
	    		"malhar",
	    		"malkauns",
	    		"malkauns pancham",
	    		"maand",
	    		"madhukauns",
	    		"madhuvanti",
	    		"maru bihag",
	    		"marwa",
	    		"mian malhar",
	    		"mian ki sarang",
	    		"mian ki todi",
	    		"multani",
	    		"nand",
	    		"nat bhairav",
	    		"nat bihag",
	    		"pahadi",
	    		"patdeep",
	    		"pat bihag",
	    		"piloo",
	    		"poorvi",
	    		"puriya",
	    		"puriya dhanashri",
	    		"puriya kalyan",
	    		"rageshree",
	    		"ramkali",
	    		"raj kalyan",
	    		"suha",
	    		"suha kanada",
	    		"shahana",
	    		"sham kalyan",
	    		"shankara",
	    		"shivranjani",
	    		"shree",
	    		"shuddha kalyan",
	    		"shuddha sarang",
	    		"sohni",
	    		"tilak kamod",
	    		"tilang",
	    		"todi",
	    		"vibhas",
	    		"brindavani sarang",
	    		"yaman",
	    		"yaman kalyan",
	    		"yamani bilawal"};

		List<String> candidates = new ArrayList<String>();
		for (String t: test)
			candidates.add(t);
		
		List<Pair<String, Integer>> pairs = new ArrayList<Pair<String, Integer>>();
		
		for (String c: candidates)
			pairs.add(new Pair<String, Integer>(c, 1));
			
		sortCandidateWordsByLength(candidates);
		computeLetterFreqs(candidates, null);
		Crossword c = createCrossword(pairs, 15, null, null, null, null, true);
	//	System.out.println (c);
	}
}
