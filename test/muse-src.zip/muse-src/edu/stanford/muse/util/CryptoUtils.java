/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.util;


import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

public class CryptoUtils {
	 private static final byte[] salt = {
	        (byte)0x11, (byte)0xaf, (byte)0x21, (byte)0x17,
	        (byte)0x24, (byte)0x96, (byte)0x14, (byte)0xa5
	    };

	 private static Cipher getCipher(int mode) throws GeneralSecurityException
	 {
		 // Create PBE parameter set
		 PBEParameterSpec pbeParamSpec = new PBEParameterSpec(salt, 20);
		 PBEKeySpec pbeKeySpec = new PBEKeySpec("1BhmsnJsh".toCharArray());
		 SecretKey pbeKey = SecretKeyFactory.getInstance("PBEWithMD5AndDES").generateSecret(pbeKeySpec);
		 Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
		 pbeCipher.init(mode, pbeKey, pbeParamSpec);
		 return pbeCipher;
	 }

	 public static void writeEncryptedString (String s, String filename) throws IOException, GeneralSecurityException
	 {
		 writeEncryptedBytes(s.getBytes("UTF-8"), filename); // is utf-8 ok ? java strings are actually utf-16
	 }

	 public static byte[] getEncryptedBytes (byte[] clearText) throws IOException, GeneralSecurityException
	 {
		 Cipher cipher = getCipher(Cipher.ENCRYPT_MODE);
		 byte[] ciphertext = cipher.doFinal(clearText);
		 return ciphertext;
	 }

	 public static void writeEncryptedBytes (byte[] clearText, String filename) throws IOException, GeneralSecurityException
	 {
		 byte[] ciphertext = getEncryptedBytes(clearText);
		 FileOutputStream fos = new FileOutputStream(filename);
		 fos.write(ciphertext);
		 fos.close();
	 }

	public static byte[] readEncryptedBytes (String filename) throws IOException, GeneralSecurityException
	{
		return decryptBytes(Util.getBytesFromFile(filename));
	}

	public static byte[] decryptBytes(byte[] b) throws GeneralSecurityException
	{
		Cipher cipher = getCipher(Cipher.DECRYPT_MODE);
		byte[] clearBytes = cipher.doFinal(b);
		return clearBytes;
	}

	public static String readEncryptedString (String filename) throws IOException, GeneralSecurityException
	{
		return new String(readEncryptedBytes(filename));
	}


	public static void main (String[] args) throws Exception
	{
		writeEncryptedBytes("String to encode".getBytes(), "TEST");
		byte b[] = readEncryptedBytes("TEST");
		System.out.println (new String(b));
	}
}
