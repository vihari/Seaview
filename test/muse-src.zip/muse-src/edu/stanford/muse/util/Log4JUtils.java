/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.util;


import java.io.File;
import java.io.RandomAccessFile;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.RollingFileAppender;

public class Log4JUtils {
    public static Log log = LogFactory.getLog(Log4JUtils.class);
    private static boolean initialized = false;

	public static synchronized void initialize()
	{
		if (initialized)
			return;

		// redirect muse.log because it may not be writable - same name as in log4j.properties file and debug.jsp
		String newLog = System.getProperty("muse.log");
		if (Util.nullOrEmpty(newLog))
			newLog = System.getProperty("java.io.tmpdir") + File.separator + "muse.log";
		try {
			try {
				File f = new File(newLog);
				if (f.exists())
				{
					RandomAccessFile raf = new RandomAccessFile(f, "rwd");
					raf.setLength(0);
					raf.close();
				}
			} catch (Exception e) { Util.print_exception(e);}
			System.out.println ("Log messages will be recorded in " + newLog);
			log.info ("Log messages will be recorded in " + newLog);
			addLogFileAppender(newLog);
		} catch (Exception e) { Util.print_exception(e);}
		initialized = true;
	}

	/** adds a new file appender to the root logger. expects root logger to have at least a console appender from which it borrows the layout */
 	public static void addLogFileAppender(String filename)
 	{
 	    try
 	    {
            Logger rootLogger = LogManager.getLoggerRepository().getRootLogger();
            Enumeration allAppenders = rootLogger.getAllAppenders();
            while(allAppenders.hasMoreElements())
            {
                Object next = allAppenders.nextElement();
                if (next instanceof ConsoleAppender)
                {
                	Layout layout = ((ConsoleAppender) next).getLayout();
                	RollingFileAppender rfa = new RollingFileAppender(layout, filename);
                	rfa.setMaxFileSize("5MB");
                	rfa.setMaxBackupIndex(2);
                	rfa.setEncoding("UTF-8");
                	rootLogger.addAppender (rfa);
                }
            }
 	    }
 	    catch(Exception e)
 	    {
 	        log.error("Failed creating log appender in " + filename);
 	        System.err.println("Failed creating log appender in " + filename);
 	    }
 	    log.info ("Log messages will be recorded in " + filename);
 	}

 	public static void setLoggingLevel (Logger logger, String level)
 	{
 		if ("debug".equalsIgnoreCase(level))
	    	logger.setLevel(Level.DEBUG);
	    else if ("info".equalsIgnoreCase(level))
	    	logger.setLevel(Level.INFO);
	    else if ("warn".equalsIgnoreCase(level))
	    	logger.setLevel(Level.WARN);
	    else if ("error".equalsIgnoreCase(level))
	    	logger.setLevel(Level.ERROR);
	    else if ("trace".equalsIgnoreCase(level))
	    	logger.setLevel(Level.TRACE);
	    else
	    	log.warn ("Unknown logging level: for " + logger + " to " + level);
 		
 		log.info ("Effective logging level for " + logger.getName() + " is " + logger.getEffectiveLevel());
	}

 	/** taken from: http://stackoverflow.com/questions/3060240/how-do-you-flush-a-buffered-log4j-fileappender */
 	public static void flushAllLogs()
 	{
 	    try
 	    {
 	        Set<FileAppender> flushedFileAppenders = new LinkedHashSet<FileAppender>();
 	        Enumeration currentLoggers = LogManager.getLoggerRepository().getCurrentLoggers();
 	        while (currentLoggers.hasMoreElements())
 	        {
 	            Object nextLogger = currentLoggers.nextElement();
 	            if (nextLogger instanceof Logger)
 	            {
 	                Logger currentLogger = (Logger) nextLogger;
 	                Enumeration allAppenders = currentLogger.getAllAppenders();
 	                while(allAppenders.hasMoreElements())
 	                {
 	                    Object nextElement = allAppenders.nextElement();
 	                    if(nextElement instanceof FileAppender)
 	                    {
 	                        FileAppender fileAppender = (FileAppender) nextElement;
 	                        if(!flushedFileAppenders.contains(fileAppender) && !fileAppender.getImmediateFlush())
 	                        {
 	                            flushedFileAppenders.add(fileAppender);
 	                            //log.info("Appender "+fileAppender.getName()+" is not doing immediateFlush ");
 	                            fileAppender.setImmediateFlush(true);
 	                            currentLogger.info("Flushing appender: " + fileAppender.getName() + "\n" + fileAppender);
 	                            fileAppender.setImmediateFlush(false);
 	                        }
 	                        else
 	                        {
 	                            //log.info("fileAppender"+fileAppender.getName()+" is doing immediateFlush");
 	                        }
 	                    }
 	                }
 	            }
 	        }
 	    }
 	    catch(RuntimeException e)
 	    {
 	        log.error("Failed flushing logs", e);
 	    }
 	}
}
