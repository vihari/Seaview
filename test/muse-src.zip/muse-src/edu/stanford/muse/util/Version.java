package edu.stanford.muse.util;
public class Version {  public static final String num = "0.9.45 (beta)"; 
public static final String buildInfo = "Built by hangal, Thu 07 Feb 2013 7:40 PM";} 
