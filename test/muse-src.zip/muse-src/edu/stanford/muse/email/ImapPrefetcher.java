/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.email;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Session;
import javax.mail.internet.MimeMessage;

import com.sun.mail.iap.Argument;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.protocol.BODY;
import com.sun.mail.imap.protocol.FetchResponse;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.imap.protocol.IMAPResponse;

public class ImapPrefetcher implements IMAPFolder.ProtocolCommand {

/** Index on server of first mail to fetch **/
int start;

/** Index on server of last mail to fetch **/
int end;
Session session;

/* start and end are inclusive */
public ImapPrefetcher(Session session, int start, int end) {
	this.session = session;
    this.start = start;
    this.end = end;
}

// see http://stackoverflow.com/questions/8322836/javamail-imap-over-ssl-quite-slow-bulk-fetching-multiple-messages
@Override
public Object doCommand(IMAPProtocol protocol) throws ProtocolException {

	Argument args = new Argument();
	args.writeString(Integer.toString(start) + ":" + Integer.toString(end));
	args.writeString("BODY[]");
	Response[] r = protocol.command("FETCH", args);
	List<MimeMessage> result = new ArrayList<MimeMessage>();
	Response response = r[r.length - 1]; 
	if (response.isOK()) 
	{
		for (int i = 0 ; i < r.length - 1 ; i++) {

			if (r[i] instanceof IMAPResponse) {

				FetchResponse fetch = (FetchResponse)r[i];
				Object o = fetch.getItem(0);
				if (!(o instanceof BODY))
				{
					EmailFetcherThread.log.warn ("Warning: o is " + o.getClass() + " r.length = " + r.length);
					continue;
				}
				BODY body = (BODY) o;
				ByteArrayInputStream is = body.getByteArrayInputStream();
				try {
					MimeMessage mm = new MimeMessage(session, is);
					result.add(mm);
					//    Contents.getContents(mm, i);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} 
		}
	}
	// dispatch remaining untagged responses
	protocol.notifyResponseHandlers(r);
	protocol.handleResult(response);
	return result;
}

}
