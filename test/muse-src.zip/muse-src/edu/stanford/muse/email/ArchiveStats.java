/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.email;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.Util;

/** used to be fetch stats, but is really doing most stats on the docs themselves */
public class ArchiveStats implements Serializable {
	private final static long serialVersionUID = 1L;

	public Date lastUpdate;
	public long fetchAndIndexTimeMillis;
	public String userKey;
	public int nMessagesOriginal, nMessagesAfterFiltering, nMessages;
	public int nMessagesSent, nMessagesReceived;
	public List<Pair<String,Integer>> selectedFolders = new ArrayList<Pair<String,Integer>>(); // selected folders and their counts
	public Filter messageFilter;
	public Calendar firstMessageDate, lastMessageDate;
	public int spanInMonths;

	public String toString()
	{
		// do not use html special chars here!
		Calendar c = new GregorianCalendar();
		c.setTime(lastUpdate);
		String s = "Date: " + Util.formatDateLong(c) + "\n";
//		s += "user_key: " + userKey + "\n";
//		s += "total_folders: " + nFolders + "\n";
		if (selectedFolders == null)
			s += "selected_folders: null";
		else
		{
			s += "selected_folders: " + selectedFolders.size();
			for (Pair<String,Integer> p: selectedFolders)
				s += " - " + p.getFirst() + " (" + p.getSecond() + ")";
		}
		s += "\n";
		s += "message_filter: " + messageFilter + "\n";

		s += "selected_messages: " + nMessages + " original: " + nMessagesOriginal +  " post_filtering: " + nMessagesAfterFiltering + " dups: " + (nMessagesAfterFiltering-nMessages) + "\n";
		s += "sent_messages: " + nMessagesSent + " received_messages: " + nMessagesReceived + "\n";
		s += "first_date: " + Util.formatDate(firstMessageDate) + " last_date: " + Util.formatDate(lastMessageDate) + " span_in_months: " + spanInMonths + "\n";
		s += "fetch_time_in_secs: " + fetchAndIndexTimeMillis/1000 + "\n";

		return s;
	}

}
