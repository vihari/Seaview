/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.email;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.mail.AuthenticationFailedException;
import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;

import edu.stanford.muse.datacache.BlobStore;
import edu.stanford.muse.exceptions.CancelledException;
import edu.stanford.muse.exceptions.MboxFolderNotReadableException;
import edu.stanford.muse.exceptions.NoDefaultFolderException;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.EmailDocument;
import edu.stanford.muse.util.EmailUtils;
import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.Util;

/** important class -- this is the primary class used by clients to fetch email with muse.
 * fetches email from multiple accounts.
 * use simpleSetup() for easy setup with just one account for Yahoo, Gmail, Hotmail, Stanford accounts 
 * and default folders for these accounts (Sent mail for Y, G and Stanford, INBOX for Hotmail).
 * 
 * here's the flow for more elaborate options (custom servers, multiple accounts):
 * call the add accounts to specify the accounts.
 * then call getFolderInfosAsJson(idx) for each account to get the folder list if needed.
 * then call setupFetchers()
 * then call fetchAndIndexEmails() */

public class MuseEmailFetcher {
    public static Log log = LogFactory.getLog(MuseEmailFetcher.class);

    private transient List<MTEmailFetcher> fetchers;
    private transient MTEmailFetcher aggregatingFetcher;
    public transient List<EmailStore> emailStores = new ArrayList<EmailStore>();
	
	/////////////////////////// account setup stuff
	
	/** clear current emailstores */
	public void clearAccounts()
	{
		emailStores = new ArrayList<EmailStore>();
	}
	
	public void addEmailStore(EmailStore stores)
	{
		int initialSize = emailStores.size();
		// we could check for duplicates here
		emailStores.add(stores);
		log.info("Email fetcher went from " + initialSize + " stores to " + emailStores.size());
	}
	
	/** sets up fetchers for the emailstores */
	public void setupFetchers(int last_N_msgs)
	{
		// create the fetchers (not connecting yet)
	    fetchers = new ArrayList<MTEmailFetcher>();
	    for (EmailStore store: emailStores)
	    {
	    	MTEmailFetcher f = new MTEmailFetcher(1, store, last_N_msgs);
	    	fetchers.add (f); // # of threads
	    }
	}

	/////////////////////////////////////
	
	public int getNAccounts()
	{
		if (Util.nullOrEmpty(emailStores))
			return 0;
		return emailStores.size();
	}

	public String getFolderInfosAsJson(int accountIdx)
	{
		return emailStores.get(accountIdx).getFolderInfosAsJson();
	}

	public boolean folderInfosAvailable(int accountIdx)
	{
		return emailStores.get(accountIdx).isFolderCountReadingComplete();
	}

	public List<FolderInfo> readFoldersInfos(int accountIdx, String cacheDir)
	{
		EmailStore store = emailStores.get(accountIdx);
		try {
			store.doneReadingFolderCounts = false;
			store.computeFoldersAndCounts(cacheDir);
			return store.folderInfos;
		} catch (Exception e) {
			String failMessage = getUserDisplayableMessageForException(store, e);
			throw new RuntimeException(failMessage);
		}
	}

	public String getDisplayName(int accountIdx)
	{
		return emailStores.get(accountIdx).getDisplayName();
	}

	public Collection<String> getDataErrors()
	{
		Collection<String> result = new LinkedHashSet<String>();
		if (fetchers == null)
			return result;
		
		for (MTEmailFetcher fetcher: fetchers)
			result.addAll(fetcher.getDataErrors());
		return result;
	}

	/**
	 * @param params
	 * set up account for a server-based a/c, either:
	 * a) <server, login, password> for an a/c where the imap server is specified.
	 * or if server is null:
	 * b) <email addr, password> for a standard server like G/Y/H/Stanford
	 * c) <email addr, password> for an a/c whose info is known to Thunderbird
	 * Note: emailAddress is slightly overloaded (can be a plain login name also in case server is specified)
	 * imapServer is ignored (and can be null) for a well-known email address like Gmail/Y/H/Stanford etc.
	 * @throws IOException 
	 * returns true if the a/c was actually created.
	 */
	public String addServerAccount(String server, String protocol, String defaultFolderName, String emailAddress, String password)
	{
		String loginName = emailAddress;
		EmailStore emailStore;
		// if emailaddress is from a known domain, set up imap/pop server
		
		if (Util.nullOrEmpty(server) && !Util.nullOrEmpty(emailAddress))
		{
			emailAddress = emailAddress.trim();
			if (emailAddress.endsWith("@live.com") || emailAddress.endsWith("@hotmail.com"))
			{
				server = "pop3.live.com";
				defaultFolderName = "INBOX";
				loginName = emailAddress; // special case for hotmail
			}
			else if (emailAddress.endsWith("@yahoo.com") || emailAddress.endsWith("@ymail.com"))
			{
				server = "imap.mail.yahoo.com";
				protocol = "imaps";
				defaultFolderName = "Sent";
			}
			else if (emailAddress.endsWith("@gmail.com") || emailAddress.endsWith("@googlemail.com"))
			{
				server = "imap.gmail.com";
				protocol = "imaps";
				defaultFolderName = "[Gmail]/Sent Mail";
			}
			else if (emailAddress.endsWith("@cs.stanford.edu"))
			{
				// monica special
				server = "lam@cs.stanford.edu".equals(emailAddress) ? "csl-mail.stanford.edu" : "xenon.stanford.edu";
				protocol = "imaps";
//				protocol = "imap";
				defaultFolderName = "Sent";
			}
			else if (emailAddress.endsWith("@stanford.edu"))
			{
				String login = EmailUtils.getLoginFromEmailAddress(emailAddress);
				server = login + ".pobox.stanford.edu";
				protocol = "imaps";
				defaultFolderName = "Sent";
			}
		}
		
		// ispdb stuff here
		
		// saw some logs that people just typed in server name as "gmail"
		// so help them out a bit
		if ("gmail".equalsIgnoreCase(server))
			server = "imap.gmail.com";
		else if ("yahoo".equalsIgnoreCase(server) || "ymail".equalsIgnoreCase(server)) 
			server = "imap.mail.yahoo.com";
		else if ("hotmail".equalsIgnoreCase(server) || "microsoft".equalsIgnoreCase(server) || "live".equalsIgnoreCase(server))
			server = "pop3.live.com";
		
		// if still no server, we don't know what do
		if (Util.nullOrEmpty(server))
			return "No server found";
		
		// set up the server
		
		// only imap/pop
		// we don't want to support plain imap/pop and get into explaining the security implications to end-users
		if (Util.nullOrEmpty(protocol))
		{
		    protocol = "imaps";
		    if (server.startsWith("pop"))
		        protocol = "pop3s";
		}	
		
	    ImapPopConnectionOptions connection = new ImapPopConnectionOptions(protocol, server, -1, loginName, password);
	    emailStore = new ImapPopEmailStore(connection, emailAddress);
	    if (!Util.nullOrEmpty(defaultFolderName))
	    	emailStore.addDefaultFolderName(defaultFolderName);

		return doConnect(emailStore);
	}
	
	/** add mbox stores, given comma separated email directories. 
	 * if localFolders, sets the display name of the store to "Local Folders" instead of the full path 
	 * @throws MboxFolderNotReadableException */
	public String addMboxAccount(String mailDirs, boolean localFolders) throws IOException, MboxFolderNotReadableException	    
	{
		if (Util.nullOrEmpty(mailDirs))
			return null;
		EmailStore emailStore = new MboxEmailStore(localFolders ? "Local Folders" : mailDirs, mailDirs);
		return doConnect(emailStore);
	}

	private String doConnect(EmailStore emailStore)
	{
		// now actual login
		try {
			if (emailStore != null)
			{
				emailStore.connect();
				log.info ("Successful login for account: " + emailStore);
				addEmailStore(emailStore);
			}
		} catch (Exception e)
		{
			String failMessage = getUserDisplayableMessageForException(emailStore, e);
			return failMessage;
		}

		return "";		
	}
	
	/** utility method for converting an exception encountered in this fetcher to something that can be shown to the user */
	public static String getUserDisplayableMessageForException(EmailStore store, Exception e)
	{
		String failMessage = null;

		if (e instanceof AuthenticationFailedException)
		{
			failMessage =  "Invalid password for " + store.getDisplayName() + ". Please try again.";
			log.warn ("Login failed, cause: " + failMessage + "\n" + Util.stackTrace(e));
		}
		else if (e instanceof MessagingException)
		{
			Throwable cause = e.getCause();
			if (cause != null && cause instanceof UnknownHostException)
			{
				if (store instanceof ImapPopEmailStore)
				{
					ImapPopEmailStore ipes = (ImapPopEmailStore) store;
					failMessage = "Unable to contact host: " + ipes.getServerHostname();
				}
				else
					failMessage = "Unknown Host. Not expected with a " + store.getClass().getName() + ". Hmmm...";
			}
			else
			{
				String server = "";
				if (store instanceof ImapPopEmailStore)
				{
					ImapPopEmailStore ipes = (ImapPopEmailStore) store;
					server = "Unknown server: " + ipes.getServerHostname();
				}
				failMessage = "Unable to communicate with server " + server + ": " + e.getMessage() + ". \n";
				if (cause != null)
					failMessage += "Cause: " + cause + "\n";
			}
			log.warn ("Login failed, cause: " + failMessage + "\n" + Util.stackTrace(e));
		}
		else
		{
			Throwable cause = e.getCause();
			failMessage = "Internal error, " + cause;
			log.error ("Exception trying to access folders: \n" + e + " : " + Util.stackTrace(e));
		}
		return failMessage;
	}
	
	/** sets up folderInfo's for each fetcher based on the given request params in allFolders (or using default if useDefaultFolders)
	 * allFolders folders are in the <account name>^-^<folder name> format from folders.jsp
	 */
	private void setupFoldersForFetchers(List<MTEmailFetcher> fetchers, String[] selectedFolders, boolean downloadText, boolean downloadAttachments, boolean useDefaultFolders) throws UnsupportedEncodingException, MessagingException, NoDefaultFolderException
	{
	    // now compute foldersForEachFetcher
	    Map<String, Integer> accountNameToFetcherIdx = new LinkedHashMap<String, Integer>();
	    List<List<String>> foldersForEachFetcher = new ArrayList<List<String>>();
	    for (int i = 0; i < fetchers.size(); i++)
	    {
	    	accountNameToFetcherIdx.put (emailStores.get(i).getDisplayName(), i);
	    	foldersForEachFetcher.add(new ArrayList<String>());
	    }

	    if (selectedFolders != null)
	    {
			// convert iso8859 to utf-8, e.g. see http://forums.sun.com/thread.jspa?threadID=5362133
			// important to convert encoding for unicode folders
			// convert iso8859 to utf-8, e.g. see http://forums.sun.com/thread.jspa?threadID=5362133
			// and http://illegalargumentexception.blogspot.com/2009/05/java-rough-guide-to-character-encoding.html
			// and http://java.sun.com/developer/technicalArticles/Intl/HTTPCharset/

		    // tokenize the folder params to separate account name from folder name
			String accountNameToFolderNameSeparator = "^-^";
			for (String folder: selectedFolders)
			{
				// example: folder = GMail^-^MyFolder

				int idx = folder.indexOf(accountNameToFolderNameSeparator);
				if (idx == -1)
				{
					log.error("Bad folder name received: " + folder);
					continue;
				}
				String accountName = folder.substring (0, idx); // example: GMail
				String folderName = folder.substring (idx + accountNameToFolderNameSeparator.length()); // example: MyFolder
				Integer I = accountNameToFetcherIdx.get(accountName);
				if (I == null)
				{
					log.error("Bad account name: " + accountName + " in folder name: " + folder);
					continue;
				}
				foldersForEachFetcher.get(I).add(folderName);
			}
	    }

		// now we have foldersForEachFetcher
		// fetchers could be run concurrently.
		// but... need to worry about synchronizing address books as well as the filedatastore
		// since all fetchers share them
		for (int i = 0; i < fetchers.size(); i++)
		{
			MTEmailFetcher fetcher = fetchers.get(i);
		    fetcher.clearFolderNames();

			List<String> foldersForThisFetcher = foldersForEachFetcher.get(i);
			boolean usingDefault = false;
			if (useDefaultFolders && (foldersForThisFetcher == null || foldersForThisFetcher.size() == 0))
			{
				foldersForThisFetcher = fetcher.getDefaultFolderNames();
				usingDefault = true;
			}

			if (foldersForThisFetcher == null || foldersForThisFetcher.size() == 0)
				continue;

		    for (String folder: foldersForThisFetcher)
			    fetcher.addFolderNameAndComputeMessageCount(folder);

		    if (usingDefault) {
		    	for (FolderInfo fi: fetcher.folderInfos)
		    		if (fi.messageCount == -1)
		    			throw new NoDefaultFolderException(fetcher.toString(), fi.longName);
		    }
		}
	}

	/** ensures passwords do not get saved with serialization */
	public void wipePasswords() 
	{
		if (fetchers == null)
			return;
		for (MTEmailFetcher f: fetchers)
			f.wipePasswords();	
	}
	
    /** key method to fetch actual email messages. can take a long time.
     * @param session is used only to set the status provider object. callers who do not need to track status can leave it as null
     * @param requestParams map of filter params.
     * @param baseDir directory where indexes etc. will be stored
     * @param selectedFolders is in the format <account name>^-^<folder name>
     * @param last_N_msgs => only last n messages for each folder will be considered
     * @session is used only to put a status object in. can be null in which case status object is not set.
     * @return triple (e.g. setup has not been called); otherwise returns a triple containing
     * emailDocs, addressBook and blobstore
     * @throws NoDefaultFolderException 
     * @throws Exception 
     * */
	public void fetchAndIndexEmails(Archive archive, Map<String, String> filterParams, String[] selectedFolders, HttpSession session, boolean downloadMessageText, boolean downloadAttachments, boolean useDefaultFolders, int last_N_messages)
				throws UnsupportedEncodingException, MessagingException, InterruptedException, IOException, JSONException, NoDefaultFolderException, CancelledException
	{
		BlobStore attachmentsStore = archive.getBlobStore();
		downloadAttachments &= attachmentsStore != null;

		if (Util.nullOrEmpty(fetchers))
		{
			log.warn ("Trying to fetch email with no fetchers, setup not called ?");
			return;
		}
		
		if (last_N_messages != -1)
			log.info ("last_N_messages: " + last_N_messages);
		
		Filter filter = Filter.parseFilter(filterParams);

	    setupFoldersForFetchers(fetchers, selectedFolders, downloadMessageText, downloadAttachments, useDefaultFolders);
	    List<FolderInfo> fetchedFolderInfos = new ArrayList<FolderInfo>();
	    
	    // one fetcher will aggregate everything
		aggregatingFetcher = null;

		long startTimeMillis = System.currentTimeMillis();
	    for (MTEmailFetcher fetcher: fetchers)
	    {
			if (session != null)
				session.setAttribute("statusProvider", fetcher);

		    fetcher.setFilter(filter);
			fetcher.setArchive(archive);
			fetcher.setDownloadMessages (downloadMessageText);
			fetcher.setDownloadAttachments (downloadAttachments);
			fetcher.set_last_N(last_N_messages);
		    log.info("Memory status before fetching emails: " + Util.getMemoryStats());

		    List<FolderInfo> foldersFetchedByThisFetcher = fetcher.run();	
		    
			// if fetcher was cancelled, bail out of all fetchers
			if (fetcher.isCancelled())
			{
				log.info ("Fetcher was cancelled");
				throw new CancelledException();
			}
			if (fetcher.mayHaveRunOutOfMemory())
				throw new OutOfMemoryError();

			fetchedFolderInfos.addAll(foldersFetchedByThisFetcher);

	    	// in theory, different iterations of this loop could be run in parallel ("archive" access will be synchronized)
			if (aggregatingFetcher == null && !Util.nullOrEmpty(foldersFetchedByThisFetcher))
				aggregatingFetcher = fetcher; // first non-empty fetcher

			if (aggregatingFetcher != null)
				aggregatingFetcher.merge (fetcher);
		}

		long endTimeMillis = System.currentTimeMillis();
		long elapsedMillis = endTimeMillis - startTimeMillis;
	    log.info(elapsedMillis + " ms for fetch+index, Memory status: " + Util.getMemoryStats());
	    
		List<EmailDocument> allEmailDocs = (List) archive.getAllDocs();

		archive.addFetchedFolderInfos(fetchedFolderInfos);

		if (allEmailDocs.size() == 0)
			log.warn ("0 messages from email fetcher");

		EmailUtils.cleanDates((Collection) allEmailDocs);

		// create a new address book	
		if (session != null)
			session.setAttribute("statusProvider", new StaticStatusProvider("Resolving aliases..."));
		AddressBook addressBook = EmailDocument.buildAddressBook(allEmailDocs, archive.ownerEmailAddrs, archive.ownerNames);
		log.info ("Address book stats: " + addressBook.getStats());
		if (session != null)
			session.setAttribute("statusProvider", new StaticStatusProvider("Finishing up..."));
		archive.setAddressBook(addressBook);

		///////////////////////// apply filter ///////////////////////////////
		// this is a pre-indexing filter, not really used or tested much
		/*
		if (filter != null)
			filter.setAddressBook(addressBook);
		stats.messageFilter = filter;
		List<EmailDocument> newAllDocs = new ArrayList<EmailDocument>();

		if (log.isDebugEnabled())
		{
			for (EmailDocument ed: allEmailDocs)
				log.debug ("Message " + ed.toFullString());
		}

		log.info ("Pre-filter: " + allEmailDocs.size() + " messages");
		if (allEmailDocs.size() == 0)
			log.warn ("0 messages before filtering");

		for (EmailDocument ed: allEmailDocs)
			try {
				if (filter == null || (filter != null && filter.matches(ed)))
					newAllDocs.add(ed);
			} catch (ReadContentsException e) {
				Util.print_exception(e, log);
			}

		allEmailDocs = newAllDocs;
		stats.nMessagesAfterFiltering = allEmailDocs.size();
		log.info ("Post-filter: " + allEmailDocs.size() + " messages");
		if (allEmailDocs.size() == 0)
			log.warn ("0 messages after filtering");
		 */
		///////////////////////// end apply filter ///////////////////////////////

		// we shouldn't really have dups now because the archive ensures that only unique docs are added
		// move sorting to archive.postprocess? 
	    allEmailDocs = EmailUtils.removeDupsAndSort(allEmailDocs);

	    // report stats
		ArchiveStats stats = new ArchiveStats();
		stats.lastUpdate = new Date();
		stats.nMessagesOriginal = allEmailDocs.size();
		stats.userKey = "USER KEY UNUSED"; // (String) JSPHelper.getSessionAttribute(session, "userKey");
	    updateStats(archive, addressBook, stats);	    
	}
	
	/** this should probably move to archive.java */
	private static void updateStats(Archive archive, AddressBook addressBook, ArchiveStats stats)
	{
		Collection<EmailDocument> allEmailDocs = (Collection) archive.getAllDocs();
		// the rest of this is basically stats collection
		int nSent  = 0, nReceived = 0;
		for (EmailDocument ed: allEmailDocs)
		{
			Pair<Boolean, Boolean> p = addressBook.isSentOrReceived(ed.getToCCBCC(), ed.from);
			boolean sent = p.getFirst();
			boolean received = p.getSecond();
			if (sent)
				nSent++;
			if (received)
				nReceived++;
		}
		stats.nMessagesSent = nSent;
		stats.nMessagesReceived = nReceived;
	
		stats.nMessages = allEmailDocs.size();
	
		/* compute stats for time range */
		if (allEmailDocs.size() > 0)
		{
			Pair<Date, Date> p = EmailUtils.getFirstLast((List) allEmailDocs);
			Calendar start = new GregorianCalendar();
			start.setTime(p.getFirst());
			Calendar end = new GregorianCalendar();
			end.setTime(p.getSecond());
			stats.firstMessageDate = start;
			stats.lastMessageDate = end;
			int spanInMonths = 0;
			if (end != null && start != null)
			{
				spanInMonths = (end.get(Calendar.YEAR) * 12 + end.get(Calendar.MONTH))
							 - (start.get(Calendar.YEAR) * 12 + start.get(Calendar.MONTH));
			}
	
			stats.spanInMonths = spanInMonths;
		}
	
		log.info ("Fetcher stats: " + stats);
	}

	public BlobStore getAttachmentsStore()
	{
		return aggregatingFetcher.getAttachmentsStore();
	}
	
	public String toString()
	{
		return "Muse email fetcher with " + fetchers.size() + " fetcher(s)";
	}
}
