/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.email;


import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.StringTokenizer;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Address;
import javax.mail.AuthenticationFailedException;
import javax.mail.BodyPart;
import javax.mail.FetchProfile;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.MultipartDataSource;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.Store;
import javax.mail.UIDFolder;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;

import com.sun.mail.imap.IMAPFolder;

import edu.stanford.muse.datacache.Blob;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.EmailDocument;
import edu.stanford.muse.index.Indexer;
import edu.stanford.muse.index.InternTable;
import edu.stanford.muse.index.LinkInfo;
import edu.stanford.muse.util.EmailUtils;
import edu.stanford.muse.util.JSONUtils;
import edu.stanford.muse.util.Util;
import edu.stanford.muse.webapp.HTMLUtils;

/** implements an email contacts fetcher for a range of message #s within a single folder. 
 * In contrast, MTEmailFetcher is responsible for an entire email account, including multiple folders. 
 * and MuseEmailFetcher is responsible for multiple accounts. */

public class EmailFetcherThread extends EmailProcessorThread {
	private final static long serialVersionUID = 1L;

	public static final int IMAP_PREFETCH_BUFSIZE = 50*1024*1024; /* used for buffering imap prefetch data -- necessary for good imap performance */
	
    public static Log log = LogFactory.getLog(EmailFetcherThread.class);

	private boolean downloadMessages = false, downloadAttachments = false;
    private Filter filter;
    private boolean mayHaveRunOutOfMemory = false;
    FolderInfo fetchedFolderInfo;
    transient Folder folder;
    boolean use_uid_if_available;
    
    public boolean mayHaveRunOutOfMemory() {
		return mayHaveRunOutOfMemory;
	}

	//	private String folderPrefix; // prefix for folder files
	transient Store store;  // we don't really need this serialized across sessions

	transient Archive archive;
	Collection<String> dataErrors = new LinkedHashSet<String>(); // log of input data errors

	Date prevDate = null;
	
	public EmailFetcherThread() { super(); }

	public EmailFetcherThread(EmailStore store, String folder_name)
	{
		super(store, folder_name);
	}

	public EmailFetcherThread(EmailStore store, String folder_name, int begin_msg_index, int end_msg_index)
	{
		super(store, folder_name, begin_msg_index, end_msg_index);
	}

	public void setArchive(Archive a)
	{
	    archive = a;
	}

	public Archive getArchive()
	{
		return archive;
	}

	/** merges results with another email fetcher. does some lightweight work including updating stats. consider removing this and simplifying in the future */
	public void merge(EmailFetcherThread other)
	{
		verify();
		if (other != null)
		{
			other.verify();

			// TOFIX: we should eliminate duplicates
			dataErrors.addAll(other.dataErrors);
			stats.merge(other.stats);
			
			nMessagesProcessedSuccess += other.nMessagesProcessedSuccess;
			nErrors += other.nErrors;
			mayHaveRunOutOfMemory |= other.mayHaveRunOutOfMemory;
		}
		verify();
	}
	
	/** intern a bunch of addrs, to save memory 
	 * @throws UnsupportedEncodingException */
	private static void internAddressList (Address[] addrs) throws UnsupportedEncodingException
	{
		if (addrs == null)
			return;
		
		for (Address a: addrs)
		{
			if (a instanceof InternetAddress)
			{
				InternetAddress ia = (InternetAddress) a;
				String address = ia.getAddress(), personal = ia.getPersonal();
				if (address != null)
					ia.setAddress(InternTable.intern(address));
				if (personal != null)
					ia.setPersonal(InternTable.intern(personal));
			}
		}
	}

	/** convert the javamail obj. to our own data struct. */
	//public EmailDocument convertToEmailDocument(MimeMessage m, int num, String url) throws MessagingException, IOException
	public EmailDocument convertToEmailDocument(MimeMessage m, int num) throws MessagingException, IOException
	{
		// get the date.
		// prevDate is a hack for the cases where the message is lacking an explicit Date: header. e.g.
		//		From hangal Sun Jun 10 13:46:46 2001
		//		To: ewatkins@stanford.edu
		//		Subject: Re: return value bugs
		// though the date is on the From separator line, the mbox provider fails to parse it and provide it to us.
		// so as a hack, we will assign such messages the same date as the previous one this fetcher has seen! ;-)
		// update: having the exact same date causes the message to be considered a duplicate, so just increment
		// the timestamp it by 1 millisecond!
		// a better fix would be to improve the parsing in the provider

		boolean hackyDate = false;
		Date d = m.getSentDate();
		if (d == null)
			d = m.getReceivedDate();
		if (d == null)
		{
			dataErrors.add ("null date: message #" + num + ": " + EmailUtils.formatMessageHeader(m));
			if (prevDate != null)
			{
				long newTime = prevDate.getTime()+1L; // added +1 so that this email is not considered the same object as the prev. one if they are in the same thread
				d = new Date(newTime);
			}
			else
				d = new Date(); // wrong, but what can we do... :-(
			hackyDate = true;
		}
		else 
		{
			Calendar c = new GregorianCalendar();
			c.setTime(d);
			int yy = c.get(Calendar.YEAR);
			if (yy <= 1970 || yy > 2020)
			{
				dataErrors.add ("Probably bad date: " + Util.formatDate(c) + " message: " + EmailUtils.formatMessageHeader(m));
				hackyDate = true;			
			}
		}
		
		if (hackyDate && prevDate != null)
		{			
			long newTime = prevDate.getTime()+1L; // added +1 so that this email is not considered the same object as the prev. one if they are in the same thread
			d = new Date(newTime);
			Util.ASSERT (!d.equals(prevDate));			
		}
		
		Calendar c = new GregorianCalendar();
		c.setTime (d != null ? d: new Date());
		
		prevDate = d;

		Address to[] = null, cc[] = null, bcc[] = null;
		Address[] from = null;
		try {
// 			allrecip = m.getAllRecipients(); // turns out to be too expensive because it looks for newsgroup headers for imap
			// assemble to, cc, bcc into a list and copy it into allrecip
			List<Address> list = new ArrayList<Address>();
			from = m.getFrom();
			to = m.getRecipients(Message.RecipientType.TO); if (to != null) list.addAll(Arrays.asList(to));
			cc = m.getRecipients(Message.RecipientType.CC); if (cc != null) list.addAll(Arrays.asList(cc));
			bcc = m.getRecipients(Message.RecipientType.BCC); if (bcc != null) list.addAll(Arrays.asList(bcc));
			
			// intern the strings in these addresses to save memory cos they are repeated often in a large archive
			internAddressList(from);
			internAddressList(to);
			internAddressList(cc);
			internAddressList(bcc);			
		} catch (AddressException ae) {
			String s = "Bad address in folder " + folder_name + " message#" + num + " " + ae;
			dataErrors.add(s);
		}

		EmailDocument ed = new EmailDocument(num, folder_name, to, cc, bcc, from, m.getSubject(), m.getMessageID(), c.getTime());
		String[] headers = m.getHeader("List-Post");
		if (headers != null && headers.length > 0)
		{
			// trim the headers because they usually look like: "<mailto:prpl-devel@lists.stanford.edu>"
			ed.sentToMailingLists = new String[headers.length];
			int i = 0;
			for (String header: headers)
			{
				header = header.trim();
				header = header.toLowerCase();

				if (header.startsWith("<") && header.endsWith(">"))
					header = header.substring (1, header.length()-1);
				if (header.startsWith("mailto:") && !"mailto:".equals(header)) // defensive check in case header == "mailto:"
					header = header.substring (("mailto:").length());
				ed.sentToMailingLists[i++] = header;
			}
		}
		if (hackyDate)
		{
			String s = "Guessed date " + Util.formatDate(c) + " for message #" + num + ": " + ed.getHeader();
			dataErrors.add(s);
			ed.hackyDate = true;
		}

		// check if the message has attachments.
		// if it does and we're not downloading attachments, then we mark the ed as such.
		// otherwise we had a problem where a message header (and maybe text) was downloaded but without attachments in one run
		// but in a subsequent run where attachments were needed, we thought the message was already cached and there was no
		// need to recompute it, leaving the attachments field in this ed incorrect.
		List<String> attachmentNames = getAttachmentNames(m, m);
		if (!Util.nullOrEmpty(attachmentNames))
		{
			ed.attachmentsYetToBeDownloaded = true; // will set it to false later if attachments really were downloaded (not sure why)
//			log.info ("added " + attachmentNames.size() + " attachments to message: " + ed);
		}
		return ed;
	}

	/* we try to get the attachment names cheaply, i.e. without having to process the whole message */
	private List<String> getAttachmentNames(MimeMessage m, Part p) throws MessagingException, IOException
	{
		List<String> result = new ArrayList<String>();
		if (p.isMimeType("multipart/*") || p.isMimeType("message/rfc822"))
		{
			if (p.isMimeType("multipart/alternative"))
				return result; // ignore alternative's because real attachments don't have alternatives
			DataHandler dh = p.getDataHandler();
			DataSource ds = dh.getDataSource();
			if (ds instanceof MultipartDataSource)
			{
				MultipartDataSource mpds = (MultipartDataSource) ds;
				for (int i = 0; i < mpds.getCount(); i++)
					result.addAll(getAttachmentNames(m, mpds.getBodyPart(i)));
			}
			else
			{
				String name = ds.getName();
				if (!Util.nullOrEmpty(name))
					result.add(name);
			}
		}
		else
		{
			String filename = p.getFileName();
			if (filename != null)
				result.add(filename);
		}
		return result;
	}

//	public void setEmailCache (DocCache cache)
//	{
//		this.cache = cache;
//	}

	/** this method returns the text content of the message as a list of strings
	// each element of the list could be the content of a multipart message
	// m is the top level subject
	// p is the specific part that we are processing (p could be == m)
	 * also sets up names of attachments (though it will not download the attachment unless downloadAttachments is true)
	 * */
	private List<String> processMessagePart(int idx, Message m, Part p, List<Blob> attachmentsList) throws MessagingException, IOException
	{
		List<String> list = new ArrayList<String>(); // return list
		if (p == null)
		{
			dataErrors.add("part is null: " + folder_name + " idx " + idx);
			return list;
		}
		
		if (p == m && p.isMimeType("text/html"))
		{
			String s = "top level part is html! message:" + m.getSubject() + " " + m.getDescription();
			dataErrors.add(s);
		}

		if (p.isMimeType("text/plain"))
		{
			log.debug ("Message part with content type text/plain");
			String content;
			String type = p.getContentType();
			try { 
				content = (String) p.getContent();				
			} catch (UnsupportedEncodingException uee) {
				dataErrors.add("Unsupported encoding: " + folder_name + " Message #" + idx + " type " + type + ", using brute force conversion");
				// a particularly nasty issue:javamail can't handle utf-7 encoding which is common with hotmail and exchange servers.
				// we're using the workaround suggested on this page: http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4304013
				// though it may be better to consider official support for utf-7 or other encodings.
				
				// TOFIX: I get an exception for utfutf8-encoding which has a base64 encoding embedded on it. 
				// Unsupported encoding: gmail-sent Message #10477 type text/plain; charset=x-utf8utf8; name="newyorker.txt", 
				// the hack below doesn't work for it.
				ByteArrayOutputStream bao = new ByteArrayOutputStream();
				p.writeTo(bao);
				content = bao.toString();
			}			
			list.add(content);
		}
		else if (p.isMimeType("multipart/*") || p.isMimeType("message/rfc822"))
		{
			// rfc822 mime type is for embedded mbox format or some such (appears for things like
			// forwarded messages). the content appears to be just a multipart.
			Object o = p.getContent();
			if (o instanceof Multipart)
			{
				Multipart allParts = (Multipart) o;
				if (p.isMimeType("multipart/alternative"))
				{
					// this is an alternative mime type. v common case to have text and html alternatives
					// so just process the text part if there is one, and avoid fetching the alternatives.
					// useful esp. because many ordinary messages are alternative: text and html and we don't want to fetch the html.
					// revisit in future we want to retain the html alternative for display purposes
					Part[] parts = new Part[allParts.getCount()];
					for (int i = 0; i < parts.length; i++)
						parts[i] = allParts.getBodyPart(i);
					
					for (int i = 0; i < parts.length; i++)
					{
						Part thisPart = parts[i];
						if (thisPart.isMimeType("text/plain"))
						{
							// common case, return quickly
							list.add((String) thisPart.getContent());
							log.debug ("Multipart/alternative with content type text/plain");
							return list;
						}
					}

					// no text part, let's look for an html part. this happens for html parts.
					for (int i = 0; i < allParts.getCount(); i++)
					{
						Part thisPart = parts[i];
						if (thisPart.isMimeType("text/html"))
						{
							// common case, return quickly
							String html = (String) thisPart.getContent();
							String text = Util.unescapeHTML(html);
							org.jsoup.nodes.Document doc = Jsoup.parse(text);

							StringBuilder sb = new StringBuilder();
							HTMLUtils.extractTextFromHTML(doc.body(), sb);
							list.add(sb.toString());
							
							log.debug ("Multipart/alternative with content type text/html");
							return list;
						}
					}

					// no text or html part. hmmm... blindly process the first part only
					if (allParts.getCount() >= 1)
						list.addAll(processMessagePart(idx, m, allParts.getBodyPart(0), attachmentsList));
				}
				else
				{
					// process it like a regular multipart
					for (int i = 0; i < allParts.getCount(); i++)
					{
						BodyPart bp = allParts.getBodyPart(i);
						list.addAll(processMessagePart(idx, m, bp, attachmentsList));
					}
				}
			}
			else if (o instanceof Part)
				list.addAll(processMessagePart(idx, m, (Part) o, attachmentsList));
			else
				dataErrors.add ("Unhandled part content, Java type: " + o.getClass() + " Content-Type: " + p.getContentType());
		}
		else
		{
			try {
				// do attachments only if downloadAttachments is set.
				// some apps do not need attachments, so this saves some time.
				// however, it seems like a lot of time is taken in imap prefetch, which gets attachments too?
				if (downloadAttachments)
					handleAttachments(idx, m, p, attachmentsList);
			} catch (Exception e) {
				dataErrors.add ("Ignoring attachment for " + folder_name + " Message #" + idx + ": " + Util.stackTrace(e));
			}
		}

		return list;
	}

	/** recursively processes attachments, fetching and saving it if needed
	 * @throws MessagingException */
	private void handleAttachments(int idx, Message m, Part p, List<Blob> attachmentsList) throws MessagingException
	{
	    String ct = null;
	    if (!(m instanceof MimeMessage))
	    {
	    	Exception  e = new IllegalArgumentException ("Not a MIME message!");
	    	e.fillInStackTrace();
	    	log.warn (Util.stackTrace(e));
	    	return;
	    }

	    String filename = null;
	    try { filename = p.getFileName(); } 
	    catch (Exception e) { 
	    	// seen this happen with:
	    	// Folders__gmail-sent Message #12185 Expected ';', got "Message"
	    	// javax.mail.internet.ParseException: Expected ';', got "Message"

	    	dataErrors.add ("Unable to read attachment name: " + folder_name + " msg# " + idx);	    	
	    	return;
	    }
	    
	    String sanitizedFName = Util.sanitizeFolderName(emailStore.getAccountID() + "." + folder_name);
	    if (filename == null)
	    {
	    	filename = sanitizedFName + "." + idx;
	    	dataErrors.add("attachment filename = null for " + sanitizedFName + " Message#" + idx + "\nassigning dummy name: " + filename);
	    }
	    
	    // Replacing any of the disallowed filename characters (\/:*?"<>|&) to _ 
	    // (note: & causes problems with URLs for serveAttachment etc, so it's also replaced)
	    String newFilename = Util.sanitizeFileName(filename);
	    
	    // Updating filename if it's changed after sanitizing.
	    if(!newFilename.equals(filename)){
	    	log.info("Filename changed from " + filename + " to " + newFilename);
	    	filename = newFilename;
	    }
	    
	    try {
	        ct = p.getContentType();
	        if (filename.indexOf(".") < 0) // no ext in filename... let's fix it if possible
	        {
	        	// Using startsWith instead of equals because sometimes the ct has crud beyond the image/jpeg;...crud....
	        	// Below are the most common file types, more type can be added if needed
	        	
	        	
	        	// Most common APPLICATION TYPE
	        	if (ct.startsWith("application/pdf"))
	        		filename = filename + ".pdf";
	        	if (ct.startsWith("application/zip"))
	        		filename = filename + ",zip";
	        	// Most common IMAGE TYPE
	        	if (ct.startsWith("image/jpeg")) 
	        		filename = filename + ".jpg";
	        	if (ct.startsWith("image/gif"))
	        		filename = filename + ".gif";
	        	if (ct.startsWith("image/png"))
	        		filename = filename + ".png";
	        	// Most Common VIDEO TYPE
	        	if (ct.startsWith("video/x-ms-wmv"))
	        		filename = filename + ".wmv";
	        	// Most Common AUDIO TYPE
	        	if (ct.startsWith("audio/mpeg"))
	        		filename = filename + ".mp3";
	        	if (ct.startsWith("audio/mp4"))
	        		filename = filename + ".mp4";
	        	// Most Common TEXT TYPE
	        	if (ct.startsWith("text/html"))
	        		filename = filename + ".html";
	        	// Windows Office
	        	if (ct.startsWith("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))     //Word
	        		filename = filename + ".docx";
	        	if (ct.startsWith("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))     //Excel
	        		filename = filename + ".xlsx";
	        	if (ct.startsWith("application/vnd.openxmlformats-officedocument.presentationml.presentation"))     //PowerPoint
	        		filename = filename + ".pptx";
	        }
	        // retain only up to first semi-colon; often ct is something like text/plain; name="filename"' we don't want to log the filename
	        int x = ct.indexOf(";");
	        if (x >= 0)
	        	ct = ct.substring (0, x);
	        log.info ("Attachment content type: " + ct + " filename = " + Util.blurKeepingExtension(filename));
	    } catch (Exception pex) {
	        dataErrors.add("Can't read CONTENT-TYPE: " + ct + " size = " + p.getSize() + " subject: " + m.getSubject() + " Date : " + m.getSentDate().toString() + "\n Exception: " + pex + "\n" + Util.stackTrace(pex));
	        return;
	    }

//	    if (filename == null && !p.isMimeType("text/html") && !p.isMimeType("message/partial")) // expected not to have a filename with mime type text/html
//	    	log.warn ("Attachment filename is null: " + Util.stackTrace());

	    // fetch (only) image attachment and hand it to the data store
	    // overruled... we'll get all attachments
	    if ((filename != null)) // && (Util.is_image_filename (filename) || Util.is_pdf_filename(filename)
	    						// || Util.is_office_document(filename) || Util.is_supported_file(filename)))
	    {
	        boolean success = true;
	        Blob b = new EmailAttachmentBlob(filename, p.getSize(), (MimeMessage) m, p);

	        if (downloadAttachments)
	        {
		        // this containment check is only on the basis of file name and size currently,
		        // not on the actual hash
		        if (archive.getBlobStore().contains (b))
		        {
		            log.debug ("Cache hit! " + b);
		        }
		        else
		        {
		            try {
		            	if (filename.endsWith(".tif"))
		            		log.info ("Fetching attachment..." + Util.blurKeepingExtension(filename));
		            	
		                // performance critical! use large buffer! currently 256KB
		                // stream will be closed by callee
		                
		                long start = System.currentTimeMillis();
	                	long nBytes = archive.getBlobStore().add(b, new BufferedInputStream (p.getInputStream(), 256 * 1024));
	                	long end = System.currentTimeMillis();
	                	if (nBytes != -1)
	                	{
	                		long diff = end-start;
	                		String s = "attachment size " + nBytes + " bytes, fetched in " + diff + " millis";
	                		if (diff > 0)
	                			s += " (" + (nBytes/diff) + " KB/s)";
	                		log.info(s);
	                	}
	                
	                	Util.ASSERT (archive.getBlobStore().contains(b));
		                
		            } catch (IOException ioe) {
		            	success = false;
		                dataErrors.add("WARNING: Unable to fetch attachment: size = " + p.getSize() + " subject: " + m.getSubject() + " Date : " + m.getSentDate().toString() + "\nException: " + ioe); ioe.printStackTrace(System.out);
		            }
		        }

		        if (success)
		        {
		        	attachmentsList.add(b);

		        	/// generate thumbnail only if not already cached
			        try {
			        	archive.getBlobStore().generate_thumbnail(b); // supplement
			        } catch (IOException ioe) {
			        	log.warn ("failed to create thumbnail, size = " + p.getSize() + " subject: " + m.getSubject() + " Date : " + m.getSentDate().toString() + "\nException: " + ioe);
			        	ioe.printStackTrace(System.out);
			        }
		        }
	        }
	    }
	}

	@SuppressWarnings("unused")
	private static String processLastReceived(String header)
	{
		header = header.toLowerCase();
		StringTokenizer st = new StringTokenizer(header, " \t()[]");
		String x = st.nextToken();
		if (!x.equals("from"))
		{
			log.warn ("Warning: unrecognized header: " + header);
			return null;
		}

		while (st.hasMoreTokens())
		{
			String s = st.nextToken();
			if (Character.isDigit(s.charAt(0)))
			{
				log.warn ("IP address: " + s);
				return s;
			}
		}
		return null;
	}

	public void verify()
	{
	}

	public void setDownloadMessages(boolean b)
	{
		this.downloadMessages = b;
	}

	public void setDownloadAttachments(boolean b)
	{
		this.downloadAttachments = b;
	}

	public void setFilter(Filter f) { this.filter = f; }

	public void finish()
	{
		currentStatus = JSONUtils.getStatusJSON("Verifying email headers...");
		currentStatus = JSONUtils.getStatusJSON("");
	}

	private void doFetchHeaders(Folder folder, Message[] messages, FetchProfile fp) throws MessagingException
	{
		long startTime = System.currentTimeMillis();
		int totalMessages = messages.length;

		// chunk header fetch instead of doing it all in one shot, so that we can provide periodic status updates to the user
		// up to 50 chunks, but at least 100 messages per chunk
		int N_CHUNKS = 50;
		int chunkSize = (totalMessages/N_CHUNKS);
		if (chunkSize < 100)
			chunkSize = 100;

		int N_TEASERS = 10; // keep teaser size low. It was set to 100, which increased header fetch time by 4X!

		for (int chunkStart = 0; chunkStart < totalMessages; )
		{
			if (isCancelled)
				return;

			int chunkEnd = chunkStart + chunkSize;
			if (chunkEnd > messages.length)
				chunkEnd = messages.length;

			int thisChunkSize = chunkEnd - chunkStart;

			Message chunkMessages[] = new Message[thisChunkSize];
			for (int i = 0; i < thisChunkSize; i++)
				chunkMessages[i] = messages[chunkStart + i];

			folder.fetch (chunkMessages, fp);

			// generate teasers -- names from the most recent messages
			List<String> teasers = new ArrayList<String>();
			outer:
			for (int i = chunkMessages.length-1; i >= 0; i--)
			{
				Message m = chunkMessages[i];
				Address[] addrs = m.getAllRecipients();
				if (addrs != null)
					for (Address a: addrs)
						if (a instanceof InternetAddress)
						{
							String email = ((InternetAddress) a).getAddress();
							if (email != null)
								teasers.add(email);
							if (teasers.size() > N_TEASERS)
								break outer;
						}
			}
			
			chunkStart += thisChunkSize;
			int pctDone = (chunkStart * 100)/totalMessages;

			long elapsedMillis = System.currentTimeMillis() - startTime;
			long unprocessedSecs = Util.getUnprocessedMessage(chunkStart, totalMessages, elapsedMillis);
			currentStatus = JSONUtils.getStatusJSONWithTeaser("Fetching " + Util.commatize(totalMessages) + " headers...", pctDone, elapsedMillis/1000, unprocessedSecs, teasers);
		}
	}

	/** prepare a status json with up to N_TEASERS teasers from the most recent emails, starting backwards from idx. specifically ask for ArrayList as List.get() can be costly otherwise. */
	private static String getStatusJSONWithTeasers(String message, int pctComplete, long secsElapsed, long secsRemaining, ArrayList<EmailDocument> emails, int N_TEASERS)
	{
		JSONObject json = new JSONObject();
		try {
			json.put("pctComplete", pctComplete);
			json.put("message", message);
			json.put("secsElapsed", secsElapsed);
			json.put("secsRemaining", secsRemaining);
			if (!Util.nullOrEmpty(emails))
			{
				JSONArray arr = new JSONArray();
				int idx_end = emails.size();
				int idx_start = idx_end - N_TEASERS;
				if (idx_start < 0) idx_start = 0;
				for (int i = idx_start, j = 0; i < idx_end; i++)
				{
					EmailDocument email = emails.get(i);
					if (email != null)
					{
						String subject = email.description;
						if (!Util.nullOrEmpty(subject))
							arr.put(j++, subject);
					}
				}
				json.put("teasers", arr);
			}
		} catch (JSONException jsone) {
			try {
				json.put("error", jsone.toString());
			} catch (Exception e) { Util.report_exception(e); }
		}
		return json.toString();
	}
	
	/** do a prefetch of messages for messages[startMsgIdx] onwards, as long as message nums are consecutive, up to the IMAP_PREFETCH_BUFSIZE
	 * return new, prefetched message objects. */
	private List<MimeMessage> do_imap_prefetch(Message[] messages, int startMsgIdx, Folder folder)
	{
		List<MimeMessage> prefetchedMessages = null;
		try {
			
			if (IMAP_PREFETCH_BUFSIZE > 0 && folder instanceof IMAPFolder)
			{
				int prefetch_messages_size = 0;
				int msgIdx = startMsgIdx;
				int start_message_num = messages[msgIdx].getMessageNumber();
				int end_message_num = start_message_num;
		
				// figure out message num range to fetch
				while (++msgIdx < messages.length) 
				{
					int next_message_num = messages[msgIdx].getMessageNumber();
					// NB: uses next_idx-1, because idx's go from 1 upwards, while messages array is indexed from 0 upwards
					boolean is_not_consecutive = (next_message_num != end_message_num + 1);
					// break out if message #s not sequential
					if (is_not_consecutive)
						break;					
					prefetch_messages_size += messages[msgIdx].getSize();
					// if this message would push prefetcwh size beyond the buf size, break out, not including this message
					if (prefetch_messages_size >= IMAP_PREFETCH_BUFSIZE)
						break;
					end_message_num++;					
				}
				
				// now we prefetch messages from start_message_num to end_message_num
				long startMillis = System.currentTimeMillis();
				prefetchedMessages = (List<MimeMessage>) ((IMAPFolder) folder).doCommand(new ImapPrefetcher(((ImapPopEmailStore) emailStore).session, start_message_num, end_message_num)); 
				long elapsedMillis = System.currentTimeMillis() - startMillis;
				long kb_per_sec = prefetch_messages_size/elapsedMillis;
				log.info ("prefetched messages in " + Util.blur(folder.getName()) + " [" + start_message_num + ":" + end_message_num + "], " + Util.commatize(prefetch_messages_size/1024) + "KB in " + Util.commatize(elapsedMillis) + "ms (" + Util.commatize(kb_per_sec) + " KB/sec)");
			}
		} catch (Exception e) {
			Util.print_exception(e, log);
		}
		return prefetchedMessages;
	}
	
	public void fetchHeaders(Message[] messages) throws MessagingException
	{
		// fetch headers (don't do it for mbox folders, waste of time)
		// this is an essential perf. step so that we fetch the headers in bulk. otherwise it takes a long time to fetch it one at a time for each message
		if (!(emailStore instanceof MboxEmailStore))
		{
			long startTimeMillis = System.currentTimeMillis();
			currentStatus = JSONUtils.getStatusJSON("Reading headers from " + folder.getName() + "...");
			FetchProfile fp = new FetchProfile();
			fp.add(FetchProfile.Item.ENVELOPE);
			fp.add(FetchProfile.Item.CONTENT_INFO);
			fp.add("List-Post");
			
			folder.fetch(messages, fp);
			long endTimeMillis = System.currentTimeMillis();
			log.info ("Done fetching headers: " + Util.commatize(endTimeMillis - startTimeMillis) + "ms");
		}		
	}
	
	/** fetch given message idx's in given folder -- @performance critical */
	//private void fetchUncachedMessages(String sanitizedFName, Folder folder, DocCache cache, List<Integer> msgIdxs) throws MessagingException, FileNotFoundException, IOException, GeneralSecurityException {
	private void fetchAndIndexMessages(Folder folder, Message[] messages, boolean updateUID) throws MessagingException, FileNotFoundException, IOException, GeneralSecurityException {
		currentStatus = JSONUtils.getStatusJSON((emailStore instanceof MboxEmailStore) ? "Parsing " + folder.getName() + " (can take a while)..." : "Reading " + folder.getName() + "...");


		// the values in idxs typically run linearly... like [1,2,3,4,5...]
		// idxs are offset by 1... because they refer to javamail message #s which run from 1 upwards
		// allEmails indexes run from 0 upwards, so be careful when using idx's to index into allEmails
		ArrayList<EmailDocument> emails = new ArrayList<EmailDocument>();

		long startTimeMillis = System.currentTimeMillis();

		int firstMessagePrefetchedIdx = -1, last_i_prefetched = -1;
		List<MimeMessage> prefetchedMessages = null;
		long highestUID = -1;
		if (folder instanceof UIDFolder)
			highestUID = fetchedFolderInfo.lastSeenUID;
		
		for (int i = 0; i < messages.length; i++)
		{
			// critical step: (thanks, yourkit!)
			// null out the ref to the previous message, otherwise it stays in memory, and the heap effectively needs to be as big as the entire archive
			if (i > 0)
				messages[i-1] = null;
			
			int idx = messages[i].getMessageNumber();

			if (downloadMessages && i >= last_i_prefetched)
			{
				// critical perf. step: do a bulk imap prefetch
				// the prefetch will fetch as many messages as possible up to a max buffer size, and return the messages prefetched
				// last_i_prefetched tracks what is the last index into idxs that we have prefetched.
				// when we run out of prefetched messages, we do another bulk prefetch
				
				prefetchedMessages = do_imap_prefetch(messages, i, folder);
				if (prefetchedMessages != null)
				{
					firstMessagePrefetchedIdx = idx;
					last_i_prefetched = i + prefetchedMessages.size();
				}
			}
			int pctDone = (i * 100)/messages.length;
			long elapsedMillis =  System.currentTimeMillis() - startTimeMillis;
			long unprocessedSecs = Util.getUnprocessedMessage(i, messages.length, elapsedMillis);
			int N_TEASERS = 50; // 50 ok here, because it takes a long time to fetch and process messages, so teaser computation is relatively not expensive
			int nTriesForThisMessage = 0;
			
			if (downloadMessages)				
				currentStatus = getStatusJSONWithTeasers("Reading " + Util.commatize(messages.length) + " messages from " + folder.getName() + "..." , pctDone, elapsedMillis/1000, unprocessedSecs, emails, N_TEASERS);
			else
				currentStatus = JSONUtils.getStatusJSON("Reading " + Util.commatize(messages.length) + " headers from " + folder.getName() + "... ", pctDone, elapsedMillis/1000, unprocessedSecs);

			try {
				if (isCancelled)
					break;

				Message m = messages[i];
				MimeMessage mm = (MimeMessage) m;
				if (folder instanceof UIDFolder)
				{
					long uid = ((UIDFolder) folder).getUID(m);
					if (uid > highestUID)
						highestUID = uid;
				}
				
				EmailDocument ed = convertToEmailDocument(mm, idx);

				// fetch text content if needed
				if (downloadMessages)
					if (!archive.containsDoc(ed))
					{
						// only now apply filter because this is the expensive part
						if (filter == null || filter.matches(ed))
						{
							emails.add(ed);
	
							MimeMessage original_mm = mm; // this is the mm that has all the headers etc.
							List<Blob> attachmentsList = new ArrayList<Blob>();
							
							// if we already have it prefetched, use the prefetched version
							if (firstMessagePrefetchedIdx >= 0 && prefetchedMessages != null)
								mm = prefetchedMessages.get(idx - firstMessagePrefetchedIdx); // note: this_mm only has the prefetched content, but not the headers
							
							// if mm is not prefetched, it is the same as original_mm
							// will also work, but will be slow as javamail accesses and fetches each mm separately, instead of using the bulk prefetched version
							// even when prefetched, the processMessagePart is somewhat expensive because the attachments have to be extracted etc.
		
							// we could overlap processMessagePart with do_imap_prefetch by prefetching in a separate thread, since prefetch is network limited.
							// but profiling shows processMessagePart takes only 1/4th the time of do_imap_prefetch so overlapping would be a relatively small gain.
							// not worth the effort right now.
							List<String> contents = processMessagePart(idx, original_mm, mm, attachmentsList);
							ed.attachments = attachmentsList;
							if (downloadAttachments)
								ed.attachmentsYetToBeDownloaded = false; // we've already downloaded our attachments
	
							StringBuilder sb = new StringBuilder();
							for (String s: contents)
							{
								sb.append(s);
								sb.append("\n");
							}
	
							String contentStr = sb.toString();
							archive.addDoc(ed, contentStr);
	
							List<LinkInfo> linkList = new ArrayList<LinkInfo>();
							Indexer.preprocessDocument(ed, contentStr, linkList, true);
							ed.links = linkList;
							stats.nMessagesAdded++;
						}
						else
						{
							stats.nMessagesFiltered++;
						}
					}
					else
					{
						stats.nMessagesAlreadyPresent++;
					}
			} catch (Exception ex) {
				// sometimes we get unexpected folder closed, so try again
				boolean retry = false;
				if (ex instanceof javax.mail.FolderClosedException)
				{
					log.warn("Oops, thread " + threadID + " got the folder closed in its face! " + ex.getMessage());

					// sometimes we get this exception about folder closed
					// retry up to 3 times, then give up
					if (nTriesForThisMessage < 3)
					{
						retry = true;
						log.info("Re-opening email store; attempt #" + (nTriesForThisMessage+1) + " for message " + i);
						nTriesForThisMessage++;
						messages = openFolderAndGetMessages();
						fetchHeaders(messages);
						--i; // adjust the message index n try again
					}
				}

				if (!retry)
				{
					// we sometimes see UnsupportedEncodingException with x-utf8utf8 mime type and ParseException
					// nothing much can be done, just create a dummy doc and add it to the cache
					nErrors++;
					stats.nErrors++;
					EmailDocument ed = new EmailDocument(idx);
					log.warn("Exception reading message from " + folder_name + " Message #" + idx + " " + ex.getMessage() + "\n" + Util.stackTrace(ex));

					ed.setErrorString(Util.stackTrace(ex));
				}
			}
		}

		if (updateUID && folder instanceof UIDFolder)
		{
			fetchedFolderInfo.lastSeenUID = highestUID;
			log.info ("at end of fetch, folder info is " + fetchedFolderInfo);
		}

		log.info("emailfetcher thread completed, archive has " + archive.getAllDocs().size() + " docs");
	}

	public FolderInfo getFetchedFolderInfo() { return fetchedFolderInfo; }
	public void setFolderInfo(FolderInfo fi) { this.fetchedFolderInfo = fi;	}

	private Message[] openFolderAndGetMessages() throws AuthenticationFailedException, NoSuchProviderException, MessagingException
	{
		folder = null;
		Message[] messages = null; 

		store = emailStore.connect();
		folder = emailStore.get_folder(store, folder_name);
		if (folder == null)
			return messages;

		String descr = emailStore.getAccountID() + ":" + folder;
		boolean haveUID = false;
		int count = folder.getMessageCount();
		use_uid_if_available = (begin_msg_index == 1 && end_msg_index == count+1);
		log.info ("use_uid_if_available is set to " + use_uid_if_available);
		
		if (use_uid_if_available && (folder instanceof UIDFolder))
		{
			// for uidfolders, we want to update the last seen uid in the FolderInfo
			long uid = archive.getLastUIDForFolder(emailStore.getAccountID(), folder_name);	
			if (uid > 0)
			{
				messages = ((UIDFolder) folder).getMessagesByUID(uid+1, UIDFolder.LASTUID);
				log.info ("Archive has already seen this folder: " +  descr + " will only fetch messages from uid " + uid + " onwards, " + messages.length + " messages will be incrementally fetched");
				haveUID = true;
			}
			else
				log.info(descr + " is a UIDFolder but not seen before");
		}
		else
			log.info(descr + " is not a UIDFolder");
			
		if (!haveUID)
		{
			log.info ("All " + count + " messages in " + descr + " will be fetched");
			messages = folder.getMessages();
			if (begin_msg_index > 0 && end_msg_index > 0)
			{
				// we have to use only specified messages
				// if there are 8 messages, count = 8, end_msg_index will be 9
				if (end_msg_index > count+1)
					log.warn ("Warning: bad end_msg_index " + end_msg_index + " count = " + count); // use the full messages
				else
				{
					int nMessages = end_msg_index - begin_msg_index;
					Message[] newMessages = new Message[nMessages];
					for (int i = 0; i < end_msg_index-begin_msg_index; i++)
						newMessages[i] = messages[begin_msg_index-1 + i]; // -1 cos messages array is indexed from 0, but begin_msg_index from 1
					log.info ("total # of messages: " + messages.length + " reduced # of messages: " + newMessages.length);
					messages = newMessages;
				}
			}
		}		
		return messages;
	}
	
	/** main fetch+index method */
	public void run()
	{
		currentStatus = JSONUtils.getStatusJSON("Starting to read messages from " + folder_name);

		isCancelled = false;
		Thread.currentThread().setName("EmailFetcher");
		nErrors = 0;
		Message[] messages = null;
		// use_uid is set only if we are reading the whole folder. otherwise we won't use it, and we won't update the highest UID seen for the folder in the archive.
		try
		{
//			long t1 = System.currentTimeMillis();

			messages = openFolderAndGetMessages();
			nMessagesProcessedSuccess = 0;

			currentStatus = JSONUtils.getStatusJSON("");
			if (isCancelled)
				return;

			if (messages.length > 0)
			{
				try {
					log.info(messages.length + " messages will be fetched for indexing");
					fetchAndIndexMessages (folder, messages, use_uid_if_available);
					// fetchedFolderInfo = ...
				} catch (Exception e)
				{
					log.error("Exception trying to fetch messages, results will be incomplete! " + e + "\n" + Util.stackTrace(e));
				}
			}
		} catch (Exception e) { Util.print_exception(e); }
		finally {
			try {
				if (folder != null)
					folder.close(false);
				if (store != null)
					store.close();
				
				// only pack if some messages were uncached, otherwise it wastes time
				if (messages != null &&  messages.length > 0)
				{
					if (downloadAttachments)
						archive.getBlobStore().pack();
				}
			} catch (Exception e) { Util.print_exception(e); }
		}
	}

	/* code for handling other kinds of headers, e.g. to find location of the message -- not used right now, but may use in the future.
	public void processHeaders(MimeMessage m) throws Exception
	{
		Address[] froms = m.getFrom();
		if (froms == null)
			return;
		InternetAddress a = (InternetAddress) froms[0];
		ContactInfo ci = addressBook.getContactInfoForAddress(a);
		Enumeration<Header> e = (Enumeration<Header>) m.getAllHeaders();
		String lastReceivedHeader = null;
		while (e.hasMoreElements())
		{
			Header h = e.nextElement();
			String n = h.getName();
			String v = h.getValue();
//			log.info ("header: " + n + " = " + n);
			String s = n.toLowerCase();
			if ("x-mailer".equals(s) || "user-agent".equals(s))
			{
				log.warn (m.getFrom()[0] +  " --> " + n + " " + v);
				ci.addMailer(v);
			}
			if ("x-originating-ip".equals(s) || "x-yahoo-post-ip".equals(s))
			{
				log.warn (m.getFrom()[0] + " --> " + n + " " + v);
				ci.addIPAddr(v);
			}
			if ("x-yahoo-profile".equals(s))
				log.warn (m.getFrom()[0] + " --> " + n + " " + v);
			if ("message-id".equals(s))
			{
				log.warn("messageID = " + v);
				ci.addMessageID(v);
			}
			if ("received".equals(s) || "x-received".equals(s))
			{
				lastReceivedHeader = v;
			}
		}

		// sometimes the headers have an extra ctrl-m at the end, strip it if this is the case.
		if (lastReceivedHeader != null && lastReceivedHeader.endsWith("\r"))
			lastReceivedHeader = lastReceivedHeader.substring(0, lastReceivedHeader.length()-1);

		ci.addLastReceivedHeader(lastReceivedHeader);

		String from = froms[0].toString();

		log.info (from + " lastReceived " + lastReceivedHeader);
		if (lastReceivedHeader == null)
			log.warn ("WARNING: " + from + " --> no received header!?");
		else
		{
			String ipAddrStr = processLastReceived(lastReceivedHeader);
			if (ipAddrStr != null)
			{
				byte[] ipAddrBytes = Util.parseIPAddress(ipAddrStr);
				if (ipAddrBytes != null)
				{
				//	InetAddress ipAddr = InetAddress.getByAddress(ipAddrBytes);
				//	log.info ("Received: " + locationService.lookupLocation(ipAddr));
				}
			}
		}
	}
*/

	public String toString()
	{
		return Util.fieldsToString(this);
	}
}
