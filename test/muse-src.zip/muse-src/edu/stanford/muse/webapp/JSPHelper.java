/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.webapp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import edu.stanford.muse.datacache.Blob;
import edu.stanford.muse.datacache.BlobStore;
import edu.stanford.muse.datacache.FileBlobStore;
import edu.stanford.muse.email.AddressBook;
import edu.stanford.muse.email.Contact;
import edu.stanford.muse.email.EmailStore;
import edu.stanford.muse.email.MuseEmailFetcher;
import edu.stanford.muse.email.StaticStatusProvider;
import edu.stanford.muse.exceptions.CancelledException;
import edu.stanford.muse.exceptions.NoDefaultFolderException;
import edu.stanford.muse.groups.Group;
import edu.stanford.muse.groups.GroupAlgorithmStats;
import edu.stanford.muse.groups.GroupHierarchy;
import edu.stanford.muse.groups.Grouper;
import edu.stanford.muse.groups.SimilarGroup;
import edu.stanford.muse.groups.SimilarGroupMethods;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.DataSet;
import edu.stanford.muse.index.DatedDocument;
import edu.stanford.muse.index.Document;
import edu.stanford.muse.index.EmailDocument;
import edu.stanford.muse.index.GroupAssigner;
import edu.stanford.muse.index.IndexUtils;
import edu.stanford.muse.index.Indexer;
import edu.stanford.muse.index.Lexicon;
import edu.stanford.muse.index.LinkInfo;
import edu.stanford.muse.index.LuceneIndexer;
import edu.stanford.muse.index.MemoryDocument;
import edu.stanford.muse.index.MultiDoc;
import edu.stanford.muse.index.NER;
import edu.stanford.muse.util.EmailUtils;
import edu.stanford.muse.util.Log4JUtils;
import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.SloppyDates;
import edu.stanford.muse.util.SloppyDates.DateRangeSpec;
import edu.stanford.muse.util.Util;
import edu.stanford.muse.xword.Crossword;
import edu.stanford.nlp.util.Sets;

/** helper code that would otherwise clutter JSPs. its ok for this file to handle HTML/HTTP.
 * All HTML/HTTP and presentation Java code must be present only in this file,
 * because the rest of the Muse code can be used in other, non-web apps.
 */
public class JSPHelper {
    public static Log log = LogFactory.getLog(JSPHelper.class);

    public static final int nColorClasses = 20;
	public final static int DEFAULT_N_CARD_TERMS = 30;
 
	// jetty processes request params differently from tomcat
	// tomcat assumes incoming params (both get/post) are iso8859.
	// jetty assumes utf-8.
	// so if we are not running jetty, we convert the string from iso8859 to utf8, which is what we eventually want.
	// can set RUNNING_ON_JETTY in either of 2 ways:
	// define -Dmuse.container=jetty
	// check request.getSession().getServletContext().getServerInfo()

	public static boolean RUNNING_ON_JETTY = false;

	static {
    	// log4j initialize should be called before anything else happens. this is the best place to initialize
    	Log4JUtils.initialize();
    	// check container
    	String container = System.getProperty("muse.container");
    	if ("jetty".equals(container))
    		RUNNING_ON_JETTY = true;
		log.info ("Muse is running on the Jetty web server (due to system property muse.container: " + RUNNING_ON_JETTY + ")");
    }

    public static void checkContainer(HttpServletRequest req)
    {
		String serverInfo = req.getSession().getServletContext().getServerInfo();
		log.info ("Running inside container: " + serverInfo);
		if (serverInfo.toLowerCase().indexOf("jetty") >= 0)
			RUNNING_ON_JETTY = true;
		log.info ("Running on jetty: " + RUNNING_ON_JETTY);
    }

    /** gets the LOCAL/CLIENT session attribute (to make explicit distinction from shared/global/server session)
     */
	public static Object getHttpSessionAttribute(HttpSession session, String attr_name)
    {
		if (Config.isPublicMode() && "cacheDir".equals(attr_name)) // disallow cacheDir change via browser in public mode
			return Sessions.getDefaultCacheDir();

    	return session . getAttribute(attr_name); // intentional use of session . getSessionAttribute()
    }

	/** gets the cache (base) dir for the current session */
	public static String getBaseDir(MuseEmailFetcher m, HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		
		if (session == null)
			return Sessions.getDefaultCacheDir();
		else
		{
			String baseDir = (String) getHttpSessionAttribute(session, "cacheDir"); 
			// if we have an existing cache dir, use it
			if (!Util.nullOrEmpty(baseDir))	
				return baseDir;
			
			String userKey = "user";
			
			if (!runningOnLocalhost(request))
			{
				Collection<EmailStore> emailStores = m.emailStores;
				if (Util.nullOrEmpty(emailStores))
					return "";
				
				// go through the stores till we have a non-empty key
				for (EmailStore store: emailStores)
				{
					String e = store.emailAddress;
					if (!Util.nullOrEmpty(e))
					{
						userKey = e;
						break;
					}
				}
			}
			
			session.setAttribute("userKey", userKey); // this is needed for the root dir for piclens
			// now we have the user key				
			baseDir = Sessions.getDefaultBaseDir() + File.separator + userKey;
			log.info ("base dir set to " + baseDir);
			return baseDir;
		}
	}

	public static Archive getArchive(HttpSession session)
	{
		return (Archive) getSessionAttribute(session, "archive");
	}

	/** gets the session attribute - look up from the client-side session storage first then the server-side.
     * session name (archive name) is determined by attribute ARCHIVE_NAME_STR of the client-side session.
     */
	public static Object getSessionAttribute(HttpSession session, String attr_name)
    {
		Object value = getHttpSessionAttribute(session, attr_name);
		if (value != null) return value;
		Map<String, Object> s = null;
		try {
			s = Sessions.getGlobalSession(session);
		} catch (Exception e) { Util.print_exception(e, log); }
		
		if (s != null) return s.get(attr_name);

		return null;
    }

	/** perform XSLT transformation on the XML
	 * @param xml_fname
	 * @param xsl_fname
	 * @param out
	 * @throws TransformerException 
	 */
	public static void xsltTransform(String xml_fname, String xsl_fname, JspWriter out) throws TransformerException
	{
		TransformerFactory factory = TransformerFactory.newInstance();
		Source xslt = new StreamSource(new File(xsl_fname));
		Transformer transformer = factory.newTransformer(xslt);

		Source text = new StreamSource(new File(xml_fname));
		transformer.transform(text, new StreamResult(out));
	}

	/** gets the root dir for the logged in user -- this is the dir. corresponding to /<userkey> 
     * inside the actual webapp dir.
     * currently used only for attachments and save messages. the eventual goal is to get
     * rid of this method because it is not secure in a multi-user environment. */
    public static String getRootDir(HttpServletRequest request)
    {
    	HttpSession session = request.getSession();
    	String userKey = (String) getSessionAttribute(session, "userKey");
    	ServletContext application = session.getServletContext();
    	String documentRootPath = application.getRealPath("/").toString();
    	String rootDir = documentRootPath + File.separatorChar + userKey;    	 
    	
    	return rootDir;
    }
    
	/** converts an array of strings from iso-8859-1 to utf8. useful for converting i18n chars in http request parameters.
    	if throwExceptionIfUnsupportedEncoding is true, throws an exception, otherwise returns  */
	public static String[] convertRequestParamsToUTF8(String params[], boolean throwExceptionIfUnsupportedEncoding) throws UnsupportedEncodingException
	{
		if (RUNNING_ON_JETTY)
			return params;
		if (params == null)
			return null;
		
		// newParams will contain only the strings that successfully can be converted to utf-8
		// others will be reported and ignored
		List<String> newParams = new ArrayList<String>();
		for (int i = 0; i < params.length; i++)
		{
			try {
				newParams.add(convertRequestParamToUTF8(params[i]));
			} catch (UnsupportedEncodingException e) { 
				log.warn ("Unsupported encoding exception for " + params[i]); 
				Util.print_exception(e, log); 
				if (throwExceptionIfUnsupportedEncoding)
					throw (e);
				// else swallow it
			}
		}
		return newParams.toArray(new String[newParams.size()]);
	}
	
	public static String[] convertRequestParamsToUTF8(String params[]) throws UnsupportedEncodingException
	{
		return convertRequestParamsToUTF8(params, true);
	}

	// key finding after a lot of experimentation with jetty and tomcat.
	// make all pages UTF-8 encoded.
	// setRequestEncoding("UTF-8") before reading any parameter
	// even with this, with tomcat, GET requests are iso-8859-1.
	// so convert in that case only...
	// converts an array of strings from iso-8859-1 to utf8. useful for converting i18n chars in http request parameters
	public static String convertRequestParamToUTF8(String param) throws UnsupportedEncodingException
	{
		if (RUNNING_ON_JETTY)
		{
			log.info("running on jetty: no conversion for " + param);
			return param;
		}
		if (param == null)
			return null;
		String newParam = new String(param.getBytes("ISO-8859-1"), "UTF-8");
		if (!newParam.equals(param))
			log.info ("Converted to utf-8: " + param + " -> " + newParam);
		return newParam;
	}

	public static boolean runningOnLocalhost(HttpServletRequest request)
	{
		return "localhost".equals(request.getServerName());
	}
	
//	/* this version of fetchemails must have folders defined in request since there is no primary email address */
//	public static Triple<Collection<EmailDocument>, AddressBook, BlobStore> fetchEmails(HttpServletRequest request, HttpSession session, boolean download) throws Exception
//	{
//		return fetchEmails (request, session, download, /* downloadattachments = */ false, false);
//	}
//
//	/** fetches messages without downloading or attachments.
//	 * support default folder for primary email address */
//	public static Triple<Collection<EmailDocument>, AddressBook, BlobStore> fetchEmails(HttpServletRequest request, HttpSession session, String primaryEmailAddress) throws Exception
//	{
//		return fetchEmails (request, session, false, false, false);
//	}
//
//	public static boolean fetchEmailsDefaultFolders(HttpServletRequest request, HttpSession session, boolean downloadMessageText, boolean downloadAttachments) throws Exception
//	{
//		try { 
//			fetchEmails(request, session, downloadMessageText, downloadAttachments, true);
//		} catch (Exception e) {
//			return false;
//		}
//		return true;
//	}
//	
//	public static Triple<Collection<EmailDocument>, AddressBook, BlobStore> fetchEmails(HttpServletRequest request, HttpSession session, boolean downloadMessageText, boolean downloadAttachments, boolean useDefaultFolders) 
//			throws UnsupportedEncodingException, MessagingException, InterruptedException, IOException, JSONException, NoDefaultFolderException, CancelledException
//	{
//		return fetchEmails(request, session, downloadMessageText, downloadAttachments, useDefaultFolders, null);
//	}

	/** A VIP method.
	 * reads email accounts and installs addressBook and emailDocs into session
	 * useDefaultFolders: use the default folder for that fetcher if there are no explicit folders in that fetcher
	 * @throws JSONException 
	 * @throws IOException 
	 * @throws InterruptedException 
	 * @throws MessagingException 
	 * @throws UnsupportedEncodingException 
	 * @throws NoDefaultFolderException 
	 * @throws Exception */
	public static void fetchAndIndexEmails(Archive archive, MuseEmailFetcher m, HttpServletRequest request, HttpSession session, boolean downloadMessageText, boolean downloadAttachments, boolean useDefaultFolders) 
			throws UnsupportedEncodingException, MessagingException, InterruptedException, IOException, JSONException, NoDefaultFolderException, CancelledException
	{
		// first thing, set up a static status so user doesn't see a stale status message
		session.setAttribute("statusProvider", new StaticStatusProvider("Starting up..."));

		checkContainer(request);
		String encoding = request.getCharacterEncoding();
		log.info ("request parameter encoding is " + encoding);

		if (!downloadMessageText)
			if ("true".equalsIgnoreCase(request.getParameter("downloadMessageText")))
			{
				downloadMessageText = true;
				log.info ("Downloading message text because advanced option was set");
			}

		if (!downloadAttachments)
			if ("true".equalsIgnoreCase(request.getParameter("downloadAttachments")))
			{
				downloadAttachments = true;
				downloadMessageText = true; // because text is needed for attachment wall -- otherwise we can't break out from piclens to browsing messages associated with a particular thumbnail
				log.info ("Downloading attachments because advanced option was set");
			}

		String[] allFolders = request.getParameterValues("folder");
		if (allFolders != null)
		{
			// try to read folder strings, first checking for exceptions
			try { 
				allFolders = JSPHelper.convertRequestParamsToUTF8(allFolders, true);
			} catch (UnsupportedEncodingException e) { 
				// report exception and try to read whatever folders we can, ignoring the exception this time
				log.warn ("Unsupported encoding exception: " + e); 
				try { 
					allFolders = JSPHelper.convertRequestParamsToUTF8(allFolders, false);
				} catch (UnsupportedEncodingException e1) {
					log.warn ("Should not reach here!" + e1);
				}
			}
		}
		
		Map<String, String> requestMap = convertRequestToMap(request);
		int last_N = HTMLUtils.getIntParam(request, "last", -1);
		m.fetchAndIndexEmails(archive, requestMap, allFolders, session, downloadMessageText, downloadAttachments, useDefaultFolders, last_N);
		// add the new stores
	}

	/* creates a new blob store object from the given location (may already exist) and returns it */
	public static BlobStore preparedBlobStore(String baseDir)
	{
		// always set up attachmentsStore even if we are not fetching attachments
		// because the user may already have stuff in it -- if so, we should make it available.
		String attachmentsStoreDir = baseDir + File.separator + "blobs" + File.separator;
		BlobStore attachmentsStore = null;		
		try {
			new File(attachmentsStoreDir).mkdirs();
			attachmentsStore = new FileBlobStore(attachmentsStoreDir);
		} catch (IOException ioe) {
			log.error("MAJOR ERROR: Disabling attachments because unable to initialize attachments store in directory: " + attachmentsStoreDir + " :" + ioe + " " + Util.stackTrace(ioe));
			attachmentsStore = null;
		}
		return attachmentsStore;
	}

	public static Archive preparedArchive(HttpServletRequest request, String baseDir) throws IOException
	{
		return preparedArchive(request, baseDir, null);
	}
	
	/** creates a new archive and returns it */
	public static Archive preparedArchive(HttpServletRequest request, String baseDir, List<String> extraOptions) throws IOException
	{
		List<String> list = new ArrayList<String>();

		if (request != null)
		{
			if ("yearly".equalsIgnoreCase(request.getParameter("period")))
				list.add ("-yearly");

			if (request.getParameter("noattachments") != null)
				list.add ("-noattachments");
	
			// filter params
			if ("true".equalsIgnoreCase(request.getParameter("sentOnly")))
				list.add ("-sentOnly");
	
			String str = request.getParameter("dateRange");
			if (str != null && str.length() > 0)
			{
				list.add ("-date");
				list.add(str);
			}
			String keywords = request.getParameter("keywords");
			if (keywords != null && !keywords.equals(""))
			{
				list.add ("-keywords");
				list.add(keywords);
			}
	
			String filter = request.getParameter("filter");
			if (filter != null && !filter.equals(""))
			{
				list.add ("-filter");
				list.add(filter);
			}
			// end filter params
	
			// advanced options
			if ("true".equalsIgnoreCase(request.getParameter("incrementalTFIDF")))
				list.add ("-incrementalTFIDF");
			if ("true".equalsIgnoreCase(request.getParameter("NER")))
				list.add ("-NER");
			if (!"true".equalsIgnoreCase(request.getParameter("allText")))
				list.add ("-noalltext");
			if ("true".equalsIgnoreCase(request.getParameter("locationsOnly")))
				list.add ("-locationsOnly");
			if ("true".equalsIgnoreCase(request.getParameter("orgsOnly")))
				list.add ("-orgsOnly");
			if ("true".equalsIgnoreCase(request.getParameter("includeQuotedMessages")))
				list.add ("-includeQuotedMessages");
			String subjWeight = request.getParameter("subjectWeight");
			if (subjWeight != null)
			{
				list.add("-subjectWeight");
				list.add(subjWeight);
			}
		}
		
		if (!Util.nullOrEmpty(extraOptions))
			list.addAll(extraOptions);

		String[] s = new String[list.size()];
		list.toArray(s);

		// careful about the ordering here.. first setup, then read indexer, then run it
		Archive archive = Archive.createArchive();
		archive.setup (baseDir, s);
		BlobStore blobStore = JSPHelper.preparedBlobStore(baseDir);
		archive.setBlobStore(blobStore); // should we pass blobStore to preparedArchive?	
		return archive;
	}

	public static String getRequestDescription(HttpServletRequest request)
	{
		return getRequestDescription(request, true);
	}

	/** also sets current thread name to the path of the request */
	public static String getRequestDescription(HttpServletRequest request, boolean includingParams)
	{
		String page = request.getServletPath();
	    Thread.currentThread().setName(page);
	    StringBuilder sb = new StringBuilder ("Request: " + request.getRequestURL());
	    // return here if params are not to be included
	    if (!includingParams)
	    	return sb.toString();
	    Map rpMap = request.getParameterMap();
	    if (rpMap.size() > 0)
	    	sb.append (" params: ");
	    for (Object o: rpMap.keySet())
	    {
	    	String str1 = (String) o;
	    	sb.append (str1 + " -> ");
	    	if (str1.startsWith("password"))
	    	{
	    		sb.append ("*** ");
	    		continue;
	    	}
	    	
	    	String[] vals = (String[]) rpMap.get(str1);
	    	if (vals.length == 1)
	    		sb.append(Util.ellipsize(vals[0], 100));
	    	else
	    	{
	    		sb.append ("{");
	      	    for (String x : vals)
	      	    	sb.append (Util.ellipsize(x, 100) + ",");
	            sb.append ("}");
	    	}
	    	sb.append (" ");
	    }
	    return sb.toString();
	}

	public static void logRequest(HttpServletRequest request, boolean includingParams)
	{
		log.info ("NEW " + getRequestDescription(request, includingParams));
	}

	public static void logRequest(HttpServletRequest request)
	{
		log.info ("NEW " + getRequestDescription(request, true));
	}

	public static void logRequestComplete(HttpServletRequest request)
	{
		log.info ("COMPLETED " + getRequestDescription(request, true));
		String page = request.getServletPath();
	    Thread.currentThread().setName("done-" + page);
	}

	public static Map<String,String> convertRequestToMap(HttpServletRequest request)
	{
		Map<String, String> result = new LinkedHashMap<String, String>();
		Map<String, String[]> map = (Map) request.getParameterMap();
		for (String key: map.keySet())
		{
			String[] values = map.get(key);
			if (values == null || values.length == 0)
				result.put (key, "");
			else
				result.put(key, values[0]);
		}
		return result;
	}

	// returns just the request params as a string
	public static String getRequestParamsAsString(HttpServletRequest request)
	{
		// could probably also do it by looking at request url etc.
		String requestParams = "";
		Map<String, String[]> rpmap = request.getParameterMap();
		for (String key: rpmap.keySet())
			for (String value: rpmap.get(key)) // rpmap has a string array for each param
				requestParams += (key + '=' + value + "&");
		return requestParams;
	}

	/** returns a string for documents.
	 * @param highlightAttachments 
	 * @throws Exception */
	public static String htmlForDocument(Document d, Archive archive, String datasetTitle, BlobStore attachmentsStore,  
							Set<String> highlightTermsStemmed, Set<String> highlightTermsUnstemmed, Set<Blob> highlightAttachments, boolean IA_links) throws Exception
	{
		log.debug("Generating HTML for document: " + d);
		EmailDocument ed = null;
		if (d instanceof EmailDocument)
		{
			// for email docs, 1 doc = 1 page
			ed = (EmailDocument) d;
			StringBuilder page = new StringBuilder();
			page.append ("<div class=\"muse-doc\">\n");
			
			page.append ("<div class=\"muse-doc-header\">\n");
			page.append(ed.getHTMLForHeader(archive, highlightTermsStemmed, highlightTermsUnstemmed, IA_links));
			page.append ("</div>"); // muse-doc-header
			
			/*
			Map<String, List<String>> sentimentMap = indexer.getSentiments(ed);
			for (String emotion: sentimentMap.keySet())
			{
				page.append ("<b>" + emotion + "</b>: ");
				for (String word: sentimentMap.get(emotion))
					page.append (word + " ");
				page.append ("<br/>\n");
				page.append("<br/>\n");
			}
			*/
			page.append ("\n<div class=\"muse-doc-body\">\n");
			StringBuilder htmlMessageBody = archive.getHTMLForContents(d, ((EmailDocument) d).getDate(), d.getUniqueId(), highlightTermsStemmed, highlightTermsUnstemmed, IA_links);			
//			page.append(ed.getHTMLForContents(indexer, highlightTermsStemmed, highlightTermsUnstemmed, IA_links));
			page.append(htmlMessageBody);
			page.append ("\n</div> <!-- .muse-doc-body -->\n"); // muse-doc-body

		//	page.append("\n<hr class=\"end-of-browse-contents-line\"/>\n");
			List<Blob> attachments = ed.attachments;
			if (attachments != null && attachments.size() > 0)
			{
				// show thumbnails of all the attachments

				if (Config.isPublicMode()) {
					page.append(attachments.size() + " attachment" + (attachments.size()==1 ? "" : "s") + ".");
				} else {
					page.append("<hr/>\n<div class=\"attachments\">\n");
					page.append("<table>\n");
					int i = 0;
					for (; i < attachments.size(); i++)
					{
						if (i % 4 == 0)
							page.append((i == 0) ? "<tr>\n" : "</tr><tr>\n");
						page.append("<td>");
	
						Blob attachment = attachments.get(i);
						String thumbnailURL = null, attachmentURL = null;
				    	boolean is_image = Util.is_image_filename(attachment.filename);
	
						if (attachmentsStore != null)
						{
					    	String contentFileDataStoreURL = attachmentsStore.get_URL(attachment);
					    	attachmentURL = "serveAttachment.jsp?file=" + Util.URLtail(contentFileDataStoreURL);
					    	String tnFileDataStoreURL = attachmentsStore.getViewURL(attachment, "tn");
					    	if (tnFileDataStoreURL != null)
					    		thumbnailURL = "serveAttachment.jsp?file=" + Util.URLtail(tnFileDataStoreURL);
					    	else
					    	{
					    		if (attachment.is_image())
						    		thumbnailURL = attachmentURL;
					    		else
						    		thumbnailURL = "images/sorry.png";
					    	}
						}
						else
							log.warn ("attachments store is null!");
	
						// print the filename in any case,
						String s = attachment.filename;
						// cap to a length of 25, otherwise the attachment name overflows the tn
						if (s.length() > 25)
							s = s.substring(0,22) + "...";
						page.append ("&nbsp;" + s + "&nbsp;");
						page.append ("<br/>");
						
						boolean highlight = highlightAttachments != null && highlightAttachments.contains(attachment);
						String css_class = "attch" + (is_image ? " img" : "") + (highlight ? " highlight" : "");
						String leader = "<img class=\"" + css_class + "\" ";

						// punt on the thumbnail if the attachment tn or content URL is not found
						if (thumbnailURL != null && attachmentURL != null)
						{
							// d.hashCode() is just something to identify this page/message
							page.append("<a rel=\"page" + d.hashCode() + "\" title=\"" + attachment.filename + "\" href=\"" + attachmentURL + "\">");
							page.append (leader + "href=\"" + attachmentURL + "\" src=\"" + thumbnailURL + "\"></img>\n");
							page.append ("<a>\n");
						}
						else
						{
	//								page.append ("&nbsp;<br/>&nbsp;<br/>Not fetched<br/>&nbsp;<br/>&nbsp;&nbsp;&nbsp;");
						//	page.append("<a title=\"" + attachment.filename + "\" href=\"" + attachmentURL + "\">");
							page.append (leader + "src=\"images/no-attachment.png\"></img>\n");
						//	page.append ("<a>\n");
	
							if (thumbnailURL == null)
								log.info ("No thumbnail for " + attachment);
							if (attachmentURL == null)
								log.info ("No attachment URL for " + attachment);
						}
						page.append("</td>\n");
					}
					if (i % 4 != 0)
						page.append("</tr>");
					page.append("</table>");
					page.append ("\n</div>  <!-- .muse-doc-attachments -->\n"); // muse-doc-attachments
				}

			}
			page.append ("\n</div>  <!-- .muse-doc -->\n"); // .muse-doc
			return page.toString();
		}
		else if (d instanceof DatedDocument)
		{
			/*
			DatedDocument dd = (DatedDocument) d;
			StringBuilder page = new StringBuilder();

			page.append (dd.getHTMLForHeader()); // directly jam in contents
			page.append ("<div class=\"muse-doc\">\n");
			page.append (dd.getHTMLForContents(indexer)); // directly jam in contents
			page.append ("\n</div>"); // doc-contents
			return page.toString();
			*/
			return "To be implemented";
		}
		else 
		{
			log.warn("Unsupported Document: " + d.getClass().getName());
			return "";
		}
	}

	/* returns pages and html for a collection of docs, which can be put into a jog frame.
	 * indexer clusters are used to 
	 */
	@SuppressWarnings("unchecked")
	public static Pair<DataSet, String> pagesForDocuments(Collection<Document> ds, Archive archive, String datasetTitle, Set<String> highlightTermsStemmed, Set<String> highlightTermsUnstemmed, Set<Blob> highlightAttachments) throws Exception
	{
		Indexer indexer = archive.indexer;
		StringBuilder html = new StringBuilder();
		int pageNum = 0;
		List<String> pages = new ArrayList<String>();

		// need clusters which map to sections in the browsing interface
		List<MultiDoc> clusters;

		// indexer may or may not have indexed all the docs in ds
		// if it has, use its clustering (could be yearly or monthly or category wise)
//		if (indexer != null && indexer.clustersIncludeAllDocs(ds))
//		if (indexer != null)
		clusters = archive.clustersForDocs(ds);
			/*
			else
			{
				// categorize by month if the docs have dates
				if (EmailUtils.allDocsAreDatedDocs(ds))
					clusters = IndexUtils.partitionDocsByInterval(new ArrayList<DatedDocument>((Set) ds), true);
				else // must be category docs
					clusters = CategoryDocument.clustersDocsByCategoryName((Collection) ds);
			}
			 */
			
		List<Document> datasetDocs = new ArrayList<Document>();
		
		// we build up a hierarchy of <section, document, page>
		for (MultiDoc md: clusters)
		{
			if (md.docs.size() == 0)
				continue;

			String description = md.description;
			description = description.replace("\"", "\\\""); // escape a double quote if any in the description
			html.append ("<div class=\"section\" name=\"" + description + "\">\n");

			List<List<String>> clusterResult = new ArrayList<List<String>>();

			for (Document d: md.docs)
			{
				String pdfAttrib = "";
				/*
				if (d instanceof PDFDocument)
					pdfAttrib = "pdfLink=\"" + ((PDFDocument) d).relativeURLForPDF + "\"";
				 */
				html.append ("<div class=\"document\" " + pdfAttrib + ">\n");

				datasetDocs.add(d);
				pages.add(null);
				clusterResult.add(null);
//				clusterResult.add(docPageList);
 	//			for (String s: docPageList)
				{
					String comment = Util.escapeHTML(d.comment);
					html.append ("<div class=\"page\"");
					if (!Util.nullOrEmpty(comment))
						html.append (" comment=\"" + comment + "\"");
					if (d.isLiked())
						html.append (" liked=\"true\"");
					html.append (" pageId=\"" + pageNum++ + "\"></div>\n");
				}

				html.append ("</div>"); // document
			}
			html.append ("</div>\n"); // section
		}
		
		DataSet dataset = new DataSet (datasetDocs, archive, datasetTitle, highlightTermsStemmed, highlightTermsUnstemmed, highlightAttachments);

		return new Pair<DataSet, String>(dataset, html.toString());
	}

	public static JSONArray formatAddressesAsJSON (Address addrs[]) throws JSONException
	{
		JSONArray result = new JSONArray();
		if (addrs == null)
			return result;
		int index = 0;
		for (int i = 0; i < addrs.length; i++)
		{			
			Address a = addrs[i];
			if (a instanceof InternetAddress)
			{
				InternetAddress ia = (InternetAddress) a;
				JSONObject o = new JSONObject();
				o.put ("email", Util.maskEmailDomain(ia.getAddress()));
				o.put ("name", ia.getPersonal());
				result.put (index++, o);
			}
		}
		return result;
	}
	
	/** format given addresses as comma separated html, linewrap after given number of chars 
	 * @param addressBook */
	public static String formatAddressesAsHTML (Address addrs[], AddressBook addressBook, int lineWrap)
	{
		StringBuilder sb = new StringBuilder();
		int outputLineLength = 0;
		for (int i = 0; i < addrs.length; i++)
		{
			String thisAddrStr;

			Address a = addrs[i];
			if (a instanceof InternetAddress)
			{
				InternetAddress ia = (InternetAddress) a;
				Pair<String,String> p = getNameAndURL((InternetAddress) a, addressBook);
				String url = p.getSecond();
				String str = ia.toString();
				thisAddrStr = ("<a href=\"" + url + "\">" + Util.escapeHTML(str) + "</a>");
				outputLineLength += str.length();
			}
			else
			{
				String str = a.toString();
				thisAddrStr = str;
				outputLineLength += str.length();
			}

			if (i+1 < addrs.length)
				outputLineLength += 2; // +2 for the comma that will follow...

			if (outputLineLength + 2 > lineWrap)
			{
				sb.append ("<br/>\n");
				outputLineLength = 0;
			}
			sb.append (thisAddrStr);
			if (i+1 < addrs.length)
				sb.append (", ");
		}

		return sb.toString();
	}

	public static Pair<String,String> getNameAndURL(InternetAddress a, AddressBook addressBook)
	{
		String s = a.getAddress();
		if (s == null)
			s = a.getPersonal();
		if (s == null)
			return new Pair<String,String>("","");

		// TODO (maybe after archive data structures re-org): below should pass archive ID to browse page
		if (addressBook == null) {
			return new Pair<String,String>(s, "browse?person=" + s);
		} else {
			Contact contact = addressBook.lookup(a);
			return new Pair<String,String>(s, "browse?contact=" + addressBook.getContactId(contact));
		}
	}

	public static String getURLForGroupMessages(int groupIdx)
	{
		return "browse?groupIdx=" + groupIdx;
	}

	public static String docControls(String messagesLink, String attachmentsLink, String linksLink)
	{
		String result = "";
		if (messagesLink != null)
			result += "<a target=\"#\" href=\"" + messagesLink + "\"><img title=\"Messages\" src=\"/muse/images/email.jpg\" width=\"24\"/></a>\n";
		if (!Config.isPublicMode()) {
			if (attachmentsLink != null)
				result += "<a target=\"#\"  href=\"" + attachmentsLink + "\"><img title=\"Attachments\" width=\"24\" src=\"/muse/images/paperclip.png\"/></a>\n";
			if (linksLink != null)
				result += "<a target=\"_links\" href=\"" + linksLink + "\"><img title=\"Links\" width=\"24\" src=\"/muse/images/link.png\"/></a>\n";
		}
		return result;
	}

	/** request has grouping alg params like disable move types and # of groups.
	 * session is used mainly to put status messages and legacy param unifiedGroupsAlg.
	 */
	public static GroupAssigner doGroups(HttpServletRequest request, HttpSession session, Collection<EmailDocument> allDocs, AddressBook addressBook) throws JSONException
	{
		try {
			GroupAssigner ga;
			
			GroupAlgorithmStats<String> groupAlgorithmStats = null;
	
			// session.setAttribute("statusProvider", new StaticStatusProvider("Finding groups...<br/>&nbsp;"));
			int minFreq = Util.getMinFreq(allDocs.size(), 0.5f);
			groupAlgorithmStats = new GroupAlgorithmStats<String>();

			// check which groups alg to run
			boolean unifiedGroupsAlg = true;
			if ("false".equals(getSessionAttribute(session, "unifiedGroupsAlg")))
				unifiedGroupsAlg = false;
			
			int DEFAULT_NUM_GROUPS = 20;
		    int nGroups = HTMLUtils.getIntParam(request, "numGroups", DEFAULT_NUM_GROUPS);
			GroupHierarchy<String> hierarchy = null;
			ga = new GroupAssigner();
			if (unifiedGroupsAlg)
			{
				Grouper<String> grouper = new Grouper<String>();
				session.setAttribute("statusProvider", grouper);
				if (request.getParameter("disableMergeMove") != null)
					grouper.setDisableMergeMove(true);
				if (request.getParameter("disableIntersectMove") != null)
					grouper.setDisableIntersectMove(true);
				if (request.getParameter("disableDominateMove") != null)
					grouper.setDisableDominateMove(true);
				if (request.getParameter("disableDropMove") != null)
					grouper.setDisableDropMove(true);
				
				// we'll ignore the one-sies
				int threshold = 1;
				Set<Contact> contactsToIgnore = addressBook.contactsAtOrBelowThreshold(allDocs, threshold);
				log.info (contactsToIgnore.size() + " contacts will be ignored because they are below threshold of " + threshold);
				Map<Group<String>, Float> weightedInputMap = addressBook.convertEmailsToGroupsWeighted(allDocs, contactsToIgnore);
				List<Pair<Group<String>, Float>> weightedInputList = Util.mapToListOfPairs(weightedInputMap);
				Util.sortPairsBySecondElement(weightedInputList);

				Map<String, Float> individualElementsValueMap = addressBook.getVIPsFromEmails(allDocs, contactsToIgnore);
				individualElementsValueMap = Util.reorderMapByValue(individualElementsValueMap);
				try {
					grouper.setAffinityMap(addressBook.computeAffinityMap());
					grouper.setIndividualElementsValueMap(individualElementsValueMap);
				} catch (Throwable t) { log.warn ("Exception trying to compute grouper affinity map " + t); Util.print_exception(t, log); }
				
				float errWeight = HTMLUtils.getFloatParam(request, "errWeight", 0.4f);
				hierarchy = grouper.findGroupsWeighted(weightedInputList, nGroups-1, errWeight); // err weight of 0.4 seems to work well.
				if (hierarchy != null)
				{
					List<SimilarGroup<String>> selectedGroups = SimilarGroupMethods.topGroups(hierarchy, nGroups-1);
					ga.setupGroups (allDocs, selectedGroups, addressBook, 0);
					// DON'T put grouper in session, it points to things like GrouperStats that are not serializable
				//    session.setAttribute("grouper", grouper);
				}
				session.removeAttribute("statusProvider");
			}
			else
			{
				// old groups algorithm in IUI-2011 "Groups without tears" paper, not used or maintained any more...
				List<Group<String>> input = addressBook.convertEmailsToGroups(allDocs);

				hierarchy = SimilarGroupMethods.findContactGroupsIUI(input, minFreq, 2, 1.0f, 0.35f, "linear", 1.4f, groupAlgorithmStats);
				if (hierarchy != null)
				{
					List<SimilarGroup<String>> selectedGroups = SimilarGroupMethods.topGroups(hierarchy, 15);
					ga.setupGroups (allDocs, selectedGroups, addressBook, 5);
				}	
			}

			if (hierarchy != null)
			{				
			    //Map<SimilarGroup<String>, List<SimilarGroup<String>>> parentToChildGroupMap = hierarchy.parentToChildrenMap;
			    List<SimilarGroup<String>> rootGroups = new ArrayList<SimilarGroup<String>>();
			    rootGroups.addAll(hierarchy.rootGroups);
			    AddressBook.sortByMass(allDocs, addressBook, rootGroups);
			}
			return ga;
		} catch (Exception e) {
			log.warn("Grouper failed!");
			Util.print_exception(e, log);
			// return with our tail between our legs.... but better than crashing.
		}
		return null;
	}

	/** only used by slant */
	public static List<LinkInfo> extractLinks(Archive archive, HttpSession session, Collection<Document> docsToIndex, AddressBook addressBook)
	{
		try {
			archive.setAddressBook(addressBook);
	        session.setAttribute("statusProvider", new StaticStatusProvider("Extracting links"));
	        archive.extractLinks(docsToIndex);
			return EmailUtils.getLinksForDocs(docsToIndex);
		} catch (Exception e)
		{
			Util.print_exception(e, log);
			session.setAttribute("errorMessage", "An exception occurred");
			session.setAttribute("exception", e);
			return null;
		}
	}

	/** Important method.
	 * handle query for term, sentiment, person, attachment, docNum, timeCluster etc
	 * note: date range selection is always ANDed
	 * if only_apply_to_filtered_docs, looks at emailDocs, i.e. ones selected by the current filter (if there is one)
	 * if !only_apply_to_filtered_docs, looks at all docs in archive
	 * note: only_apply_to_filtered_docs == true is not honored by lucene lookup by term (callers need to filter by themselves)
	 */
	public static List<Document> selectDocsAsList(HttpServletRequest request, HttpSession session, boolean only_apply_to_filtered_docs, boolean or_not_and) throws UnsupportedEncodingException
	{
		// below are all the controls for selecting docs 
		String term = request.getParameter("term"); // search term
		String[] contact_ids = request.getParameterValues("contact");
		String[] persons = request.getParameterValues("person");
		String[] attachments = request.getParameterValues("attachment");
		String[] attachment_types = request.getParameterValues("attachment_type");
	//	String[] docNumbers = request.getParameterValues("docNum");
		String datasetId = request.getParameter("datasetId");
		String[] docIds = request.getParameterValues("docId");
		String[] folders = request.getParameterValues("folder");
		String tag = request.getParameter("tag"); // only one tag supported right now, will revisit if needed 

		String[] directions = request.getParameterValues("direction");
		Set<String> directionsSet = new LinkedHashSet<String>();
		if (directions != null)
			for (String d: directions)
				directionsSet.add(d);
		boolean direction_in = directionsSet.contains("in");
		boolean direction_out = directionsSet.contains("out");
		
		int yy = HTMLUtils.getIntParam(request, "year", -1);
		int mm = HTMLUtils.getIntParam(request, "month", -1); // be careful: 1-based, NOT 0-based
		int end_yy = HTMLUtils.getIntParam(request, "endYear", -1);
		int end_mm = HTMLUtils.getIntParam(request, "endMonth", -1);

		String[] sentiments = request.getParameterValues("sentiment");
		int cluster = HTMLUtils.getIntParam(request, "timeCluster", -1); /** usually, there is 1 time cluster per month */

		Set<String> foldersSet = new LinkedHashSet<String>();
		if (folders != null)
			for (String f: folders)
				foldersSet.add(f);
		
		// a little bit of an asymmetry here, only one groupIdx is considered, can't be multiple
		int groupIdx = HTMLUtils.getIntParam(request, "groupIdx", Integer.MAX_VALUE);
		Archive archive = JSPHelper.getArchive(session);
		AddressBook addressBook = archive.addressBook;
		GroupAssigner groupAssigner = archive.groupAssigner;
		BlobStore attachmentsStore = archive.blobStore;

		Collection<Document> allDocs = getAllDocsAsSet(session, only_apply_to_filtered_docs);
		if (Util.nullOrEmpty(allDocs)) return new ArrayList<Document>();

		LuceneIndexer sentiIndexer = null, indexer = null;
		if (archive != null)
			indexer = sentiIndexer = (LuceneIndexer) archive.indexer;
	//	LuceneIndexer luceneIndexer = (LuceneIndexer) getSessionAttribute(session, "luceneIndexer");
	//	if (luceneIndexer != null)
	//		indexer = luceneIndexer; // override for docsWithPhrase only

		// the raw request param val is in 8859 encoding, interpret the bytes as utf instead

		/** there is a little overlap between datasetId and docForDocIds. probably datasetIds can be got rid of? */
		List<Document> docsForTerm = null, docsForGroup = null, docsForDateRange = null, docsForAttachments = null, 
				docsForAttachmentTypes = null, docsForNumbers = null, docsForFolder = null, docsForDirection = null, docsForCluster = null, docsForDocIds = null;
		Set<Document> docsForPersons = null, docsForSentiments = null, docsForTag = null;
		
		if (!Util.nullOrEmpty(term))
		{
			term = JSPHelper.convertRequestParamToUTF8(term);
			boolean unindexed = "on".equals(request.getParameter("unindexed"));
			if (unindexed) {
				docsForTerm = IndexUtils.selectDocsByRegex(archive, allDocs, term);
			} else {
				docsForTerm = new ArrayList<Document>(indexer.docsForQuery(term, cluster));
			}
		}

		if (foldersSet.size() > 0)
		{
			docsForFolder = new ArrayList<Document>();
			for (EmailDocument ed: ((Collection<EmailDocument>) (Collection) allDocs))
				if (foldersSet.contains(ed.folderName))
					docsForFolder.add(ed);
		}
		
		if ((direction_in || direction_out) && addressBook != null) 
		{
			docsForDirection = new ArrayList<Document>();
			for (EmailDocument ed: ((Collection<EmailDocument>) (Collection) allDocs))
			{
				int sent_or_received = ed.sentOrReceived(addressBook);
				if (direction_in && (sent_or_received & EmailDocument.RECEIVED_MASK) != 0)
					docsForDirection.add(ed);
				if (direction_out && (sent_or_received & EmailDocument.SENT_MASK) != 0)
					docsForDirection.add(ed);
			}
		}

		if (sentiments != null && sentiments.length > 0)
		{
			Lexicon lex = (Lexicon) getSessionAttribute(session, "lexicon");
			docsForSentiments = lex.getDocsWithSentiments(sentiments, indexer, allDocs, cluster, sentiments);
		}
		if (!Util.nullOrEmpty(tag))
		{
			docsForTag = Document.selectDocByTag(allDocs, tag, true);
		}
		if (cluster >= 0) {
			docsForCluster = new ArrayList<Document>(indexer.docsForQuery(null, cluster)); // null for term returns all docs in cluster
		}
		
		if (persons != null || contact_ids != null)
		{
			persons = JSPHelper.convertRequestParamsToUTF8(persons);
			docsForPersons = IndexUtils.selectDocsByPersons(addressBook, (Collection) allDocs, persons, Util.toIntArray(contact_ids), or_not_and);
		}

		if (end_yy >= 1970 && yy >= 1970) // date range
		{
			persons = JSPHelper.convertRequestParamsToUTF8(persons);
			docsForDateRange = IndexUtils.selectDocsByDateRange((Collection) allDocs, yy, mm, end_yy, end_mm);
		}
		else if (yy >= 1970) // single month or year
		{
			persons = JSPHelper.convertRequestParamsToUTF8(persons);
			docsForDateRange = IndexUtils.selectDocsByDateRange((Collection) allDocs, yy, mm);
		}
		
		if (groupIdx != Integer.MAX_VALUE)
		{
			if (groupIdx >= groupAssigner.getSelectedGroups().size())
				groupIdx = -1; // must be the "None" group
			docsForGroup = (List) IndexUtils.getDocsForGroupIdx((Collection) allDocs, addressBook, groupAssigner, groupIdx);
		}
		
		if (!Util.nullOrEmpty(attachments))
		{
			attachments = JSPHelper.convertRequestParamsToUTF8(attachments);
			docsForAttachments = (List) IndexUtils.getDocsForAttachments((Collection) allDocs, attachments, attachmentsStore);
		}
	
		if (!Util.nullOrEmpty(attachment_types))
		{
			attachment_types = JSPHelper.convertRequestParamsToUTF8(attachment_types);
			docsForAttachmentTypes = (List) IndexUtils.getDocsForAttachmentTypes((Collection) allDocs, attachment_types);
		}
		if (!Util.nullOrEmpty(docIds))
		{
			docsForDocIds = new ArrayList<Document>();
			for (String id: docIds)
			{
				Document d = indexer.docForId(id);
				if (d != null)
					docsForDocIds.add(d);
			}
		}

		if (datasetId != null)
		{
			DataSet dataset = (DataSet) getSessionAttribute(session, datasetId);
			if (dataset != null)
			{
				String[] docNumbers = request.getParameterValues("docNum");
				docsForNumbers = (List) IndexUtils.getDocNumbers(dataset.getDocs(), docNumbers);
			}
		}

		// apply the OR or AND of the filters
		boolean initialized = false;
		Set<Document> resultDocs;
		
		// if its an AND selection, and we are applying only to filtered docs, start with it and intersect with the docs for each facet.
		// otherwise, start with nothing as an optimization, since there's no need to intersect with it.
		// the docs for each facet will always be a subset of archive's docs.
		if (only_apply_to_filtered_docs && !or_not_and && allDocs != null)
		{
			initialized = true;
			resultDocs = new LinkedHashSet<Document>(allDocs);
		}
		else
			resultDocs = new LinkedHashSet<Document>();
		
		if (docsForTerm != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForTerm);
			}
			else
				resultDocs.retainAll(docsForTerm);
		}

		if (docsForSentiments != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForSentiments);
			}
			else
				resultDocs = Util.setIntersection(resultDocs, docsForSentiments);
		}
		if (docsForTag != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForTag);
			}
			else
				resultDocs = Util.setIntersection(resultDocs, docsForTag);
		}
		
		if (docsForCluster != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForCluster);
			}
			else
				resultDocs.retainAll(docsForCluster);
		}
		
		if (docsForDocIds != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForDocIds);
			}
			else
				resultDocs.retainAll(docsForDocIds);
		}

		if (docsForPersons != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForPersons);
			}
			else
				resultDocs = Util.setIntersection(resultDocs, docsForPersons);
		}
		
		if (docsForDateRange != null)
		{
			// if (!initialized || or_not_and)
			// note: date range selection is always ANDed, regardless of or_not_and
			if (!initialized)
			{
				initialized = true;
				resultDocs.addAll(docsForDateRange);
			}
			else
				resultDocs.retainAll(docsForDateRange);
		}
		if (docsForFolder != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForFolder);
			}
			else
				resultDocs.retainAll(docsForFolder);
		}
		
		if (docsForDirection != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForDirection);
			}
			else
				resultDocs.retainAll(docsForDirection);
		}

		if (docsForGroup != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForGroup);
			}
			else
				resultDocs.retainAll(docsForGroup);
		}
		
		if (docsForAttachments != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForAttachments);
			}
			else
				resultDocs.retainAll(docsForAttachments);
		}

		if (docsForAttachmentTypes != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForAttachmentTypes);
			}
			else
				resultDocs.retainAll(docsForAttachmentTypes);
		}

		if (docsForNumbers != null)
		{
			if (!initialized || or_not_and)
			{
				initialized = true;
				resultDocs.addAll(docsForNumbers);
			}
			else
				resultDocs.retainAll(docsForNumbers);
		}

		if (!initialized)
		{
			if (cluster >= 0)
				resultDocs = sentiIndexer.docsForQuery(null, cluster); // means all docs in cluster x
			else
			{
				resultDocs = new LinkedHashSet<Document>();
				resultDocs.addAll(allDocs); // if no filter, all docs are selected
			}
		}

		// convert set back to a list 
		List<Document> docList = new ArrayList<Document>(resultDocs);
		Collections.sort(docList);
		return docList;
	}

	// currently, only lookup by term and attachment url tails
	// note: only_apply_to_filtered_docs == true is not honored by lucene lookup by term (callers need to filter by themselves)
	public static Set<Blob> selectAttachments(HttpServletRequest request, HttpSession session, boolean only_apply_to_filtered_docs, boolean or_not_and) throws UnsupportedEncodingException
	{
		// below are all the controls for selecting docs 
		String term = request.getParameter("term"); // search term
		String[] attachments = request.getParameterValues("attachment");
		Archive archive = JSPHelper.getArchive(session);
		Collection<Document> allDocs = getAllDocsAsSet(session, only_apply_to_filtered_docs);
		if (Util.nullOrEmpty(allDocs))
			return new LinkedHashSet<Blob>();

		BlobStore attachmentsStore = archive.blobStore;
		
		Indexer sentiIndexer = null, indexer = null;
		if (archive != null)
			indexer = sentiIndexer = archive.indexer;
		
		// @Sit: please review: this probably won't work any more because we don't want to keep luceneIndexer in the session, archive.indexer should be the way to access it
		//LuceneIndexer luceneIndexer = (LuceneIndexer) getSessionAttribute(session, "luceneIndexer");
		//if (luceneIndexer != null)
		//	indexer = luceneIndexer; // override for docsWithPhrase only

		// the raw request param val is in 8859 encoding, interpret the bytes as utf instead

		/** there is a little overlap between datasetId and docForDocIds. probably datasetIds can be got rid of? */
		Set<Blob> blobsForTerm = null, blobsForAttachments = null;

		if (!Util.nullOrEmpty(term))
		{
			term = JSPHelper.convertRequestParamToUTF8(term);
			boolean unindexed = "on".equals(request.getParameter("unindexed"));
			if (unindexed) {
				// TODO: not implemented yet
				//assert(false);
				return null;
			} else {
				blobsForTerm = indexer.blobsForQuery(term);
			}
		}

		if (!Util.nullOrEmpty(attachments))
		{
			attachments = JSPHelper.convertRequestParamsToUTF8(attachments);
			blobsForAttachments = IndexUtils.getBlobsForAttachments((Collection) allDocs, attachments, attachmentsStore);
		}

		if (blobsForTerm == null) return blobsForAttachments;
		if (blobsForAttachments == null) return blobsForTerm;

		if (or_not_and) {
			return Sets.union(blobsForTerm, blobsForAttachments);
		} else {
			return Sets.intersection(blobsForTerm, blobsForAttachments);
		}
	}

	public static List<Document> selectDocsAsList(HttpServletRequest request, HttpSession session) throws UnsupportedEncodingException
	{
		return selectDocsAsList(request, session, true /* only select from currently filtered docs */, false /* and, not or */);
	}

	public static Pair<Set<Document>,Set<Blob>> selectDocsWithHighlightAttachments(HttpServletRequest request, HttpSession session, boolean only_apply_to_filtered_docs, boolean or_not_and) throws UnsupportedEncodingException
	{
		Set<Document> allDocs = getAllDocsAsSet(session, only_apply_to_filtered_docs);
		Set<Document> docs = new LinkedHashSet<Document>(selectDocsAsList(request, session, only_apply_to_filtered_docs, or_not_and));
		Set<Blob> blobs = selectAttachments(request, session, only_apply_to_filtered_docs, or_not_and);

		// here we also include emails with the attachment hits in the select result (in case it doesn't already hit in the emails)
		// TODO: should we want options to allow user to choose whether to search only in emails, only in attachments, or both?
		//       technically, it is just the matter of returning docs, docs2, or docs union docs2, but there will be work in UI.
		Set<Document> docs2 = (Set) EmailUtils.getDocsForAttachments((Collection) allDocs, blobs);
		docs = Sets.union(docs, docs2);

		docs = Sets.intersection(docs, allDocs); // ensure only_apply_to_filtered_docs == true case is honored
		// TODO?: only_apply_to_filtered_docs == true is still not honored by the returned blobs but it is currently ok since it is only used for highlighting
		return new Pair<Set<Document>,Set<Blob>>(docs, blobs);
	}

	private static Set<Document> getAllDocsAsSet(HttpSession session, boolean only_apply_to_filtered_docs)
	{
		Archive archive = JSPHelper.getArchive(session);

		if (!only_apply_to_filtered_docs)
			return archive.getAllDocsAsSet();

		Collection<Document> docs = (Collection<Document>) getSessionAttribute(session, "emailDocs");
		if (docs == null)
		{
			log.warn ("emaildocs in session is null... the session must have timed out");
			return new LinkedHashSet<Document>();
		}
		return new LinkedHashSet<Document>(docs);
	}

	public static Set<Document> selectDocs(HttpServletRequest request, HttpSession session, boolean only_apply_to_filtered_docs, boolean or_not_and) throws UnsupportedEncodingException
	{
		return selectDocsWithHighlightAttachments(request, session, only_apply_to_filtered_docs, or_not_and).first;
	}

	public static void setSessionConfigParam(HttpServletRequest request)
	{
		String key = request.getParameter("key");
		String value = request.getParameter("value");
		log.info ("setting session var: " + key + " to " + value);
		if (key == null)
			return;
		
		if (!runningOnLocalhost(request) && ("user".equalsIgnoreCase(key) || "userKey".equalsIgnoreCase(key) || "cacheDir".equalsIgnoreCase(key)))
		{
			log.warn ("Dropping attempt to set taboo session var: " + key + " = " + value + " -- this can be dangerous in a hosted environment.");
			return;
		}
		request.getSession().setAttribute(key, value);
	}

	/** serve up a file from the cache_dir */
 	public static void serveFile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
 		HttpSession session = request.getSession();
        String filename = request.getParameter("file");
        filename = convertRequestParamToUTF8(filename);
        String baseDir = (String) getSessionAttribute(session, "cacheDir");

 		if (filename.indexOf(".." + File.separator) >= 0) // avoid file injection!
 		{
 			log.warn("File traversal attack !? Disallowing serveFile for illegal filename: " + filename);
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
 		}

 		// could check if user is authorized here... or get the userKey directly from session

 		String filePath = baseDir + File.separator + "blobs" + File.separator + filename;
        // Decode the file name (might contain spaces and on) and prepare file object.
        File file = new File(filePath);

        // Check if file actually exists in filesystem.
        if (!file.exists())
        {
 			log.warn("Returing 404, serveFile can't find file: " + filePath);

            // Do your thing if the file appears to be non-existing.
            // Throw an exception, or send 404, or show default/warning page, or just ignore it.
            response.sendError(HttpServletResponse.SC_NOT_FOUND); // 404.
            return;
        }

        // Get content type by filename.
        String contentType = session.getServletContext().getMimeType(file.getName());

        // If content type is unknown, then set the default value.
        // For all content types, see: http://www.w3schools.com/media/media_mimeref.asp
        // To add new content types, add new mime-mapping entry in web.xml.
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        // Init servlet response.
        int DEFAULT_BUFFER_SIZE = 100000;
        response.reset();
        response.setBufferSize(DEFAULT_BUFFER_SIZE);
        response.setContentType(contentType);
        response.setHeader("Content-Length", String.valueOf(file.length()));
        response.setHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"");

        // Prepare streams.
        BufferedInputStream input = null;
        BufferedOutputStream output = null;

        try {
            // Open streams.
            input = new BufferedInputStream(new FileInputStream(file), DEFAULT_BUFFER_SIZE);
            output = new BufferedOutputStream(response.getOutputStream(), DEFAULT_BUFFER_SIZE);

            // Write file contents to response.
            byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
            int length;
            while ((length = input.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }
        } finally {
            // Gently close streams.
            Util.close(output);
            Util.close(input);
        }
    }

 	public static Collection<DatedDocument> filterByDate(Collection<DatedDocument> docs, String dateSpec)
 	{
 		List<DatedDocument> selectedDocs = new ArrayList<DatedDocument>();
 		if (Util.nullOrEmpty(dateSpec))
 			return docs;

 		List<DateRangeSpec> rangeSpecs = SloppyDates.parseDateSpec (dateSpec);
 		for (DatedDocument d: docs)
 		{
 			for (DateRangeSpec spec: rangeSpecs)
 				if (spec.satisfies(d.date))
 				{
 					selectedDocs.add(d);
 					break;
 				}
 		}
 		return selectedDocs;
 	}    
 	
 	public static Crossword createCrossword (HttpServletRequest request, HttpSession session) throws Exception
 	{
 		// print a count of the most popular names
 		AddressBook ab = null;
 		LuceneIndexer li = null;

 		String inputText = request.getParameter("text");
 		Map<String, Integer> map;
 		Map<String, Integer> thirdPartyCount = new LinkedHashMap<String, Integer>();
 		Set<String> filteredIds = null;
 		Archive archive = null;
 		
 		if (inputText != null)
 		{	
 			List<Pair<String, Float>> list = NER.namesFromText(inputText, false, new LinkedHashMap<String, Integer>());
 			map = new LinkedHashMap<String, Integer>();
 			for (Pair<String, Float> p: list)
 			{
 				float f = p.getSecond();
 				map.put(p.getFirst(), (int) f);	
 			}	
 			archive = Archive.createArchive();
 			archive.setup(getBaseDir(null, request), null); // no archive args, we're just going to index one doc
 			List<edu.stanford.muse.index.Document> docsToIndex = new ArrayList<edu.stanford.muse.index.Document>();
 			MemoryDocument dummyDoc = new MemoryDocument(inputText);
 			docsToIndex.add(dummyDoc);
 		//	archive.run((List) docsToIndex);
 		}
 		else
 		{
 			archive = JSPHelper.getArchive(session);
 			ab = archive.addressBook;
 			li = (LuceneIndexer) archive.indexer;

 			/* identify ids of docs (may be filtered, and a subset of all the docs in the indexer) */
 			Collection<edu.stanford.muse.index.Document> allDocs = (Collection) JSPHelper.getSessionAttribute(session, "emailDocs");
 			filteredIds = new LinkedHashSet<String>();
 			for (edu.stanford.muse.index.Document d : allDocs)
 				filteredIds.add(d.getUniqueId());

 			List<Set<String>> docs = li.getAllNames(filteredIds);
 			// docs is now the set of names in the filtered docs. count the names
 			map = new LinkedHashMap<String, Integer>();
 			for (Set<String> names : docs) {
 				if (names == null)
 					continue;
 				for (String name : names) {
 					name = name.toLowerCase();
 					Integer I = map.get(name);
 					map.put(name, (I == null) ? 1 : I + 1);
 				}
 			}

 			Map<String, EmailDocument> map1 = li.getDocMap();
 			for (EmailDocument ed : map1.values()) {
 				Set<String> names = li.getNames(ed);
 				if (names == null)
 					continue;
 				Set<String> seen = new LinkedHashSet<String>(); // names seen in this doc, canonicalized
 				for (String name : names) {
 					name = name.toLowerCase();
 					if (seen.contains(name))
 						continue;
 					seen.add(name);
 					if (ed.isThirdPartyName(ab, name)) {
 						Integer I = thirdPartyCount.get(name);
 						thirdPartyCount.put(name, (I == null) ? 1 : I + 1);
 					}
 				}
 			}
 		}
 		
 		// sort names by freq.
		List<Pair<String, Integer>> termFreqList = Util.sortMapByValue(map);
		List<Pair<String, Integer>> newTermFreqList = new ArrayList<Pair<String, Integer>>();
		for (Pair<String, Integer> p: termFreqList)
		{
			if (p.getSecond() == 1)
				break;
			newTermFreqList.add(p);
		}
		log.info("Candidate answer set reduced from: " + termFreqList.size() + " to: " + newTermFreqList.size() + " after dropping singletons");
		newTermFreqList = termFreqList;
		
 		/*
 		for (String name: possibleAnswers)
 		{
 			JSPHelper.log.info("Word candidate: " + name
 					//	+ " - occurs " + Util.pluralize(p.getSecond(), "time")
 					+ " (3rd party: "
 					+ thirdPartyCount.get(name.toLowerCase()) + ")");
 		}
 		*/

 		// don't generate a new crossword if it already exists and we just need answers
 		Lexicon lex = (Lexicon) JSPHelper.getSessionAttribute(session, "lexicon");
 		if (lex == null)
 		{
 			String baseDir = (String) JSPHelper.getSessionAttribute(session, "cacheDir");
 			String name = "default";
 			lex = new Lexicon(baseDir, name);
 			session.setAttribute("lexicon", lex);	
 		}

 		boolean doSymmetric = request.getParameter("symmetric") != null;
 		int size = HTMLUtils.getIntParam(request, "size", 15); 
 		Crossword c = Crossword.createCrossword(termFreqList, size, archive, lex, filteredIds, (Set) session.getAttribute("tabooWords"), doSymmetric);
 		return c;
 	}
}
