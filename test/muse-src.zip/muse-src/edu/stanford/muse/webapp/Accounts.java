/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.webapp;


import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import edu.stanford.muse.email.MuseEmailFetcher;
import edu.stanford.muse.exceptions.MboxFolderNotReadableException;
import edu.stanford.muse.util.Util;

/** class that extracts params from http post by the login page and sets up email stores in the MuseEmailFetcher in the session */
public class Accounts {

	public static Log log = LogFactory.getLog(Accounts.class);
	
	/* does account setup and login. return string is set to an error string if there was an error, otherwise "". accounts on the login page are numbered 0 upwards. */
	public static String login(HttpServletRequest request, int accountNum) throws IOException
	{
		HttpSession session = request.getSession();
		// allocate the fetcher if it doesn't already exist
		MuseEmailFetcher m = (MuseEmailFetcher) JSPHelper.getSessionAttribute(session, "museEmailFetcher");
		if (m == null)
		{
			m = new MuseEmailFetcher();
			session.setAttribute("museEmailFetcher", m);
		}
		
		if (accountNum == 0) // update alt addrs only for accountNum = 0 because the same param gets posted with every accountNum
			updateAlternateEmailAddrs(request);

		String accountType = request.getParameter("accountType" + accountNum);
		if (Util.nullOrEmpty(accountType))
		{
			return "No information for account #" + accountNum;
		}

		String loginName = request.getParameter("loginName" + accountNum); 
		String password = request.getParameter("password" + accountNum); 
		String protocol = request.getParameter("protocol" + accountNum); 
	//	String port = request.getParameter("protocol" + accountNum);  // we don't support pop/imap on custom ports currently. can support server.com:port syntax some day
		String server = request.getParameter("server" + accountNum); 
		String defaultFolder = request.getParameter("defaultFolder" + accountNum);

		if (server != null)
			server = server.trim();
		if (loginName != null) 
			loginName = loginName.trim();

		// for these ESPs, the user may have typed in the whole address or just his/her login name
		if (accountType.equals("gmail") && loginName.indexOf("@") < 0)
			loginName = loginName + "@gmail.com";
		if (accountType.equals("yahoo") && loginName.indexOf("@") < 0)
			loginName = loginName + "@yahoo.com";
		if (accountType.equals("live") && loginName.indexOf("@") < 0)
			loginName = loginName + "@live.com";
		if (accountType.equals("stanford") && loginName.indexOf("@") < 0)
			loginName = loginName + "@stanford.edu";
		if (accountType.equals("gapps"))
			server = "imap.gmail.com";

		// add imapdb stuff here.

		boolean isServerAccount = accountType.equals("gmail") || accountType.equals("yahoo") || accountType.equals("live") || 
				accountType.equals("stanford") || accountType.equals("gapps") || accountType.equals("imap") || accountType.equals("pop") || accountType.startsWith("Thunderbird");
		
		if (isServerAccount)
			return m.addServerAccount(server, protocol, defaultFolder, loginName, password);
		else if (accountType.equals("mbox") || accountType.equals("tbirdLocalFolders"))
		{
			try {
				String mboxDir = request.getParameter("mboxDir" + accountNum);
				// for non-std local folders dir, tbird prefs.js has a line like: user_pref("mail.server.server1.directory-rel", "[ProfD]../../../../../../tmp/tb");
				log.info("adding mbox account: " + mboxDir);
				return m.addMboxAccount(mboxDir, accountType.equals("tbirdLocalFolders"));
			} catch (MboxFolderNotReadableException e) { 
				return e.getMessage();
			}
		}
		else
			return "Internal error: unknown account type: " + accountType; // shouldn't happen
	}
	
	/** adds alternateEmailAddrs if specified in the request to the session. alternateEmailAddrs are simply appended to. */
	public static void updateAlternateEmailAddrs(HttpServletRequest request)
	{
		String alt = request.getParameter("alternateEmailAddrs");
		if (Util.nullOrEmpty(alt))
			return;

		HttpSession session = request.getSession();
		String sessionAlt = (String) JSPHelper.getSessionAttribute(session, "alternateEmailAddrs");
		if (Util.nullOrEmpty(sessionAlt))
			session.setAttribute("alternateEmailAddrs", alt); // this will be removed when we fetch and index email
		else
			session.setAttribute("alternateEmailAddrs", sessionAlt + " " + alt);
		// could also uniquify the emailAddrs here
	}
}
