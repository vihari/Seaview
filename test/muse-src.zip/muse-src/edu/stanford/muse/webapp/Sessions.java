/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.webapp;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.ref.SoftReference;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.store.LockObtainFailedException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import edu.stanford.muse.datacache.FileBlobStore;
import edu.stanford.muse.email.AddressBook;
import edu.stanford.muse.email.MuseEmailFetcher;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.Document;
import edu.stanford.muse.index.EmailDocument;
import edu.stanford.muse.index.Indexer;
import edu.stanford.muse.index.LuceneIndexer;
import edu.stanford.muse.util.EmailUtils;
import edu.stanford.muse.util.Util;

/** class to manage sessions. sessions are stored as .session files in the baseDir/sessions (which itself is stored in the session). */
public class Sessions {
    public static Log log = LogFactory.getLog(Sessions.class);
    public static final String SESSION_SUFFIX = ".session.v3"; // all session files end with .session	
    public  static String CACHE_BASE_DIR = null; // overruled (but not overwritten) by session's attribute "cacheDir"
    private static String CACHE_DIR = null; // overruled (but not overwritten) by session's attribute "cacheDir"
    private static String SESSIONS_DIR = null;

	private static final String ARCHIVE_NAME_STR = "ARCHIVE_NAME";
	private static Map< String, SoftReference< Map<String, Object> > > globalSessions = new LinkedHashMap< String, SoftReference< Map<String,Object> > >();
	private static Set<String> loadPendingSet = new LinkedHashSet<String>();
	
	public static Map< String, Map<String, String> > archivesMap = null;

	private static String getVarOrDefault(String prop_name, String default_val)
	{
		String val = System.getProperty(prop_name);
		if (!Util.nullOrEmpty(val))
			return val;
		else
			return default_val;
	}

	static {
		CACHE_BASE_DIR = getVarOrDefault("muse.dir.cache_base"  , System.getProperty("user.home") + File.separator + ".muse");
		CACHE_DIR      = getVarOrDefault("muse.dir.cache"  , CACHE_BASE_DIR + File.separator + "user"); // warning/todo: this "-D" not universally honored yet, e.g., user_key and fixedCacheDir in MuseEmailFetcher.java
		SESSIONS_DIR   = getVarOrDefault("muse.dir.sessions", CACHE_DIR + File.separator + "sessions"); // warning/todo: this "-D" not universally honored yet, e.g., it is hard-coded again in saveSession() (maybe saveSession should actually use getSessinoDir() rather than basing it on cacheDir)
	}

	public static String getArchivesIndexFilename()
	{
		//return getDefaultSessionDir() + File.separatorChar + "archives.xml";
		return getDefaultBaseDir() + File.separatorChar + "archives.xml";
	}

	private static void addXmlTagToMap(Map<String, String> map, Element e, String tag)
	{
		NodeList nl = e.getElementsByTagName(tag);
		assert(nl != null && nl.getLength() == 1);
		Node node = nl.item(0).getFirstChild();
		if (node == null) {
			// blank config => null
			map.put(tag, null);
		} else {
			map.put(tag, node.getNodeValue());
		}
	}

	public static boolean parseArchivesXml(String xmlFile)
	{
		if (!(new File(xmlFile)).exists())
			return false;
			
		if (archivesMap != null) // can't reload (any other) archives.xml
			return true;

		boolean result = true;

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		org.w3c.dom.Document dom;

		try {
			DocumentBuilder db = dbf.newDocumentBuilder();
			dom = db.parse(xmlFile);
			Element e_root = dom.getDocumentElement();

			// get a nodelist of <item> elements
			NodeList nl = e_root.getElementsByTagName("item");
			assert(nl != null);

			archivesMap = new LinkedHashMap<String, Map<String,String>>();

			for(int i = 0 ; i < nl.getLength();i++) {
				// get an <item> elemment
				Element e = (Element)nl.item(i);
				Map<String, String> map = new LinkedHashMap<String, String>();

				// extract following tags
				addXmlTagToMap(map, e, "name");
				addXmlTagToMap(map, e, "number");
				addXmlTagToMap(map, e, "description");
				addXmlTagToMap(map, e, "file");
				addXmlTagToMap(map, e, "lexicon");

				log.info("Added archive " + map);
				archivesMap.put(map.get("number"), map);
			}
		} catch(Exception e) {
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	public static Map<String, String> getArchiveInfoMap(String archiveNumber)
	{
		if (archivesMap == null) {
			parseArchivesXml(getArchivesIndexFilename());
		}
		if (archivesMap == null) {
			return new LinkedHashMap<String, String>();
		}
		return archivesMap.get(archiveNumber);
	}

	public static String getDefaultSessionDir()
    {
    	return SESSIONS_DIR;
    }

	public static String getDefaultCacheDir()
	{
		return CACHE_DIR;
	}

	public static String getDefaultBaseDir()
	{
		return CACHE_BASE_DIR;
	}

	public static String getSessionDir(HttpSession session)
    {
		return getSessionDir(session, null);
    }
	
	public static String getSessionDir(HttpSession session, String userKey)
    {
		if (!Util.nullOrEmpty(userKey))
			return getDefaultBaseDir() + File.separatorChar + userKey + File.separatorChar + "sessions";
    	// should probably decouple sessionDir and cacheDir?
    	if (JSPHelper.getSessionAttribute(session, "cacheDir") == null) {
    		session.setAttribute("cacheDir", CACHE_DIR);
    		session.setAttribute("userKey", "user");
    	}
    	return (String) JSPHelper.getSessionAttribute(session, "cacheDir") + File.separatorChar + "sessions";
    }
	
    public static Map<String, Object> loadSession(String filename, String baseDir) throws CorruptIndexException, LockObtainFailedException, IOException
    {
    	return loadSession(filename, baseDir, true /* readOnly */);
    }

    /** loads session from the given filename, and returns the map of loaded attributes.
     *  if readOnly is false, caller MUST make sure to call packIndex.
     *  baseDir is LuceneIndexer's baseDir (path before "indexes/")
     * @throws IOException 
     * @throws LockObtainFailedException 
     * @throws CorruptIndexException */
    private static Map<String, Object> loadSession(String filename, String baseDir, boolean readOnly) throws CorruptIndexException, LockObtainFailedException, IOException
	{
		log.info("Loading session from file " + filename + " size: "+ Util.commatize(new File(filename).length()/1024) + " KB");
	
		ObjectInputStream ois = null;
		
		// keep reading till eof exception
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		try {
			ois = new ObjectInputStream(new GZIPInputStream(new FileInputStream(filename)));

		    while (true)
		    {
	    		String key = (String) ois.readObject();
		    	log.info ("loading key: " + key);
		    	try {
		    		Object value = ois.readObject();
		    		result.put(key, value);
		    	} catch (InvalidClassException ice)
		    	{
		    		log.error("Bad version for value of key " + key + ": " + ice + "\nContinuing but this key is not set...");
		    	} catch (ClassNotFoundException cnfe)
		    	{
		    		log.error("Class not found for value of key " + key + ": " + cnfe + "\nContinuing but this key is not set...");
		    	}
		    }
		  } catch (EOFException eof) { log.info("end of session file reached");}
		  catch (Exception e) { log.warn("Warning unable to load session: " + Util.stackTrace(e)); result.clear(); }

		if (ois != null)
			try { ois.close(); } catch (Exception e) { }

		// need to set up sentiments explicitly -- now no need since lexicon is part of the session
		log.info ("Memory status: " + Util.getMemoryStats());

		Archive archive = (Archive) result.get("archive");

		// no groups in public mode
		if (archive != null)
		{
			if (Config.isPublicMode())
				archive.setGroupAssigner(null);
			result.put("emailDocs", archive.getAllDocs());
			Indexer indexer = archive.indexer;
			if (indexer != null)
				log.info(indexer.computeStats());
			if (indexer instanceof LuceneIndexer)
			{
				LuceneIndexer li = (LuceneIndexer) indexer;
				li.setBaseDir(baseDir);
				if (readOnly)
					li.setupForReadOnly();
				else
					li.setupForReadWrite();
			}
			if (archive.addressBook != null) {
				//archive.addressBook.reassignContactIds();
				archive.addressBook.organizeContacts(); // is this idempotent?
			}
		}

		//dumpNames((Collection) fullDocs, li);

		return result;
	}

	public static String getSessionFilename(HttpSession session, String title)
    {
		return getSessionFilename(session, title, null);
    }

	public static String getSessionFilename(HttpSession session, String title, String userKey)
    {
		String sessionDir = getSessionDir(session, userKey);
		String filename = sessionDir + File.separatorChar + title + SESSION_SUFFIX;
		return filename;
    }

    public static boolean loadGlobalSession(HttpSession session, String title) throws CorruptIndexException, LockObtainFailedException, IOException
    {
    	return loadGlobalSession(session, title, null);
    }

    /* userKey specifies sub-dir under the default base dir (unoverridable).
     * currently, userKey will be specified when operate in public web muse mode.
     */
    public static boolean loadGlobalSession(HttpSession session, String title, String userKey) throws CorruptIndexException, LockObtainFailedException, IOException
    {
    	String filename = getSessionFilename(session, title, userKey);
		if (!new File(filename).exists())
			return false;

		String baseDir;
		if (Util.nullOrEmpty(userKey))
			baseDir = (String) JSPHelper.getHttpSessionAttribute(session, "cacheDir");
		else
			baseDir = getDefaultBaseDir() + File.separatorChar + userKey;

		removeAllAttributes(session);

		// reuse getGlobalSession() to do the load.
		synchronized (globalSessions) {
			if (Config.isMultiUser() && globalSessions.containsKey(filename)) {
				// no need to reload existing session in multi-user mode = do nothing
			} else {
				// force reload in single-user mode or prepare for a fresh load in multi-user mode
				globalSessions.put(filename, new SoftReference<Map<String,Object>>(null));
			}
		}
		boolean success = !Util.nullOrEmpty(getGlobalSession(filename, baseDir));

		if (success) {
			session.setAttribute(ARCHIVE_NAME_STR, filename); // ARCHIVE_NAME should not be saved. this (per-user) session attribute is only used when server needs to reload the shared session
		}

		return success;
	}

	public static Collection<String> listSessions() throws FileNotFoundException, IOException, ClassNotFoundException
	{
		return listSessions(null);
	}
	
	/** returns a list of available session names */
	public static Collection<String> listSessions(String dir) throws FileNotFoundException, IOException, ClassNotFoundException
	{	
		if (dir == null)
			dir = SESSIONS_DIR;
		
		return Util.filesWithSuffix(dir, SESSION_SUFFIX);
	}

	/** cleans up session directory */
	public static void deleteAllSessions(String dir) throws FileNotFoundException, IOException, ClassNotFoundException
	{
		Util.deleteAllFilesWithSuffix(dir, SESSION_SUFFIX, log);
	}
	
	/** returns status of success */
	public static boolean deleteSession(String dir, String session) throws FileNotFoundException, IOException, ClassNotFoundException
	{
		if (dir == null)
			return false;
		String sessionsFile = dir + File.separator + "sessions" + File.separatorChar + session + SESSION_SUFFIX;
		File f = new File(sessionsFile);
		if (!f.exists())
			return false; // empty result
		return f.delete(); 
	}

	/** eventually, this should be the main method to write out an archive */
	public static boolean saveArchive(String archiveFile, Archive archive) throws IOException
	{
		if (archive != null)
		{
			Indexer i = archive.indexer;
			if (i != null && (i instanceof LuceneIndexer))
				((LuceneIndexer) i).prepareForSerialization();
		}

		ObjectOutputStream oos = new ObjectOutputStream(new GZIPOutputStream(new FileOutputStream(archiveFile)));
		oos.writeObject("archive");
		oos.writeObject(archive);
		oos.close();

		if (archive != null)
		{
			archive.initializeForRead();
		}

		log.info("Session saved to file " + archiveFile + " size: "+ new File(archiveFile).length()/1024 + " KB");
		return true;
	}
	
	public static boolean saveSession(String baseDir, Map<String, Object> sessionMap, String title) throws FileNotFoundException, IOException
	{
		if (Config.isPublicMode()) return false; // saving session should be disallowed in public mode

		String dir = baseDir + File.separatorChar + "sessions";
		new File(dir).mkdirs(); // just to be safe
		String filename = dir + File.separatorChar + title + SESSION_SUFFIX;
		log.info("Saving session to file " + filename);
		
		Archive archive = (Archive) sessionMap.get("archive");
		if (archive != null)
		{
			Indexer i = archive.indexer;
			if (i != null && (i instanceof LuceneIndexer))
				((LuceneIndexer) i).prepareForSerialization();
		}
		ObjectOutputStream oos = new ObjectOutputStream(new GZIPOutputStream(new FileOutputStream(filename)));
		for (String key: sessionMap.keySet())
		{
			Object value = sessionMap.get(key);
			if ("museEmailFetcher".equals(key))
				((MuseEmailFetcher) value).wipePasswords(); // ensure passwords aren't saved in the session
			
			if (key.startsWith("docset") || key.startsWith("docs-docset")) // docsets are temporary things we don't need to save in the session
				continue;

			if (ARCHIVE_NAME_STR.equals(key)) // ARCHIVE_NAME should not be saved. this (per-user) session attribute is only used when server needs to reload the shared session
				continue;

			if ("grouper".equals(key)) // TODO: dropping grouper because it is triggering a serialization problem. should investigate further.
				continue;
			
			// we don't want emailstore to be stored, only read fresh during each session.it also has sensitive password info
			if ("emailStores".equals(key))
				continue;

			if (value instanceof Serializable)
	    	{
				try { 
					log.info ("saving key: " + key);
		    		oos.writeObject(key);
		    		oos.writeObject(value);
				} catch (Exception e1) {
					log.warn ("Failed to serialize key " + key + ": " + e1);
				}
	    	}
			else
				log.warn ("Session var " + key + " is not serializable");
		}
		oos.close();
		log.info("Session saved to file " + filename + " size: "+ new File(filename).length()/1024 + " KB");

		synchronized (globalSessions) {
			globalSessions.remove(filename); // uncache the shared session corresponding to this "filename" as its content may have now completely changed by this save (e.g., overwritten by info from a different archive). this should not be needed if save is only allowed in admin mode.
		}
		
		if (archive != null)
		{
			archive.initializeForRead();
		}

		return true;
	}
	
	/** writes out all serializable objects in the current session to a file */
	public static boolean saveSession(HttpSession session, String title) throws FileNotFoundException, IOException
	{
		String baseDir = (String) JSPHelper.getSessionAttribute(session, "cacheDir");
		if (baseDir == null)
			return false;
		Map<String, Object> map = getGlobalSession(session);
		if (map == null) {
			map = new LinkedHashMap<String, Object>();
		} else {
			map = new LinkedHashMap<String, Object>(map); // make a local copy since we will append something to this map
		}

		// append client-side session vars to the server-side session map
		java.util.Enumeration keys = session.getAttributeNames();
	    while (keys.hasMoreElements())
	    {
	    	String key = (String) keys.nextElement();
	    	Object value = JSPHelper.getHttpSessionAttribute(session, key);
	    	map.put(key, value);
	    }
	    return saveSession (baseDir, map, title);
	}

	/** gets the shared/global/server-side session map that correspond to the specified session file.
	 *  if the session map has never been loaded or its loaded soft reference has been released, will (re)load the file.
	 * @throws IOException 
	 * @throws LockObtainFailedException 
	 * @throws CorruptIndexException 
	 */
	private static Map<String, Object> getGlobalSession(String session_filename, String baseDir) throws CorruptIndexException, LockObtainFailedException, IOException
	{
		Map<String, Object> map = null;
		synchronized (globalSessions) {
			try {
				map = globalSessions.get(session_filename).get();
			} catch (NullPointerException e) {
				// globalSessions.get(session_filename) is null
				log.warn("Archive " + session_filename + " may be inappropriately loaded/cleaned up previously");
				// be lenient and create a place holder for it.
				globalSessions.put(session_filename, new SoftReference<Map<String,Object>>(null));
			}
		}

		if (map == null) {
			// GCed, reload and it will be temporarily pinned by normal ref
			synchronized (loadPendingSet) {
				if (loadPendingSet.contains(session_filename)) {
					try {
						do {
							log.info("Waiting for pending load of " + session_filename);
							loadPendingSet.wait();
						} while (loadPendingSet.contains(session_filename));
					} catch (InterruptedException e) {
						log.info("Exception: " + e + " : " + Util.stackTrace());
					}
					log.info("Pending load of " + session_filename + " finished. Using its result without duplicated loading.");
					return getGlobalSession(session_filename, baseDir); // retry
				} else {
					loadPendingSet.add(session_filename);
				}
			}

			map = loadSession(session_filename, baseDir, true /* readOnly */); // not done in synchronized(globalSessions) for performance

			synchronized (globalSessions) {
				Map<String, Object> map_global = globalSessions.get(session_filename).get(); // should not throw NullPointerException again
				if (map_global == null) {
					log.info("Loaded/reloaded " + session_filename + " into global session");
					globalSessions.put(session_filename, new SoftReference<Map<String,Object>>(map));
				} else {
					// may be concurrently put in by other user loading the same archive
					log.info("Redundant load discarded");
					map = map_global;
				}
			}

			synchronized (loadPendingSet) {
				loadPendingSet.remove(session_filename);
				loadPendingSet.notifyAll();
			}
		}
	
		return map;
	}

	/** gets the shared/global/server-side session map whose
	 * session name (archive name) is given by attribute ARCHIVE_NAME_STR of the client-side session.
	 * @throws IOException 
	 * @throws LockObtainFailedException 
	 * @throws CorruptIndexException 
	 */
	public static Map<String, Object> getGlobalSession(HttpSession session) throws CorruptIndexException, LockObtainFailedException, IOException
	{
		if (session == null)
			return null;
	
		String session_filename = (String) JSPHelper.getHttpSessionAttribute(session, ARCHIVE_NAME_STR);
		String baseDir = (String) JSPHelper.getHttpSessionAttribute(session, "cacheDir");

		if (Util.nullOrEmpty(session_filename))
			return null;

		return getGlobalSession(session_filename, baseDir);
	}

	// todo: this should detach the shared session from the per-user session rather than blindly/selectively remove all attributes
	private static void removeAllAttributes(HttpSession session)
	{
		java.util.Enumeration keys = session.getAttributeNames();
	    while (keys.hasMoreElements())
	    {
	    	String key = (String) keys.nextElement();
	    	if ("cacheDir".equals(key)) // do not remove "cacheDir" attribute which may be user-provided.
	    		continue;
			session.removeAttribute(key);
	    }
	}



	// modify session to prepare for public mode.
	public static boolean modifySession(HttpServletRequest request) throws Exception
	{
		String sessionName = request.getParameter("session");
		String[] fields = request.getParameterValues("remove-field");
		String tag = request.getParameter("remove-tagged");
		String out_dir = request.getParameter("out-dir");
		boolean mask_email = request.getParameter("mask-email") != null;
		boolean index_attachment = request.getParameter("index-attachment") != null;

		boolean result = true;

		if (Util.nullOrEmpty(out_dir))
			return false;
		File dir = new File(out_dir);
		if (!dir.mkdirs()) {
			log.info("Unable to create directory '" + out_dir + "' (it may already exist)");
			return false;
		}

		HttpSession session = request.getSession();
		if (!loadGlobalSession(session, sessionName)) {
			return false;
		}
		Map<String, Object> map = getGlobalSession(session);
		if (Util.nullOrEmpty(map)) {
			return false;
		}
		
		Archive archive = (Archive) map.get("archive");

		LuceneIndexer li = (LuceneIndexer) archive.indexer;
		li.removeFieldsFromDirectory(fields);
		// TODO: for file-based directory, above step will modify the original copy. need to preserve original while creating the result under out-dir.

		List<Document> allDocs = (List) map.get("emailDocs"); // not fullEmailDocs (so will look only at the current/saved filter result)
		assert(!Util.hasRedundantElements(allDocs));

		if (!Util.nullOrEmpty(tag)) {
			// find messages with the "tag"
			Set<Document> taggedDocs = EmailDocument.selectDocByTag(allDocs, tag, true); // contain=true
			log.info("Session " + sessionName + " has " + taggedDocs.size() + " tagged docs from " + allDocs.size() + " docs");
	
			allDocs = Util.getRemoveAll(allDocs, taggedDocs);
	
			// remove the tagged docs from the index.
			li.removeEmailDocs(taggedDocs);
	
			// update the .contents file (remove the tagged docs from .contents and replace text with names)
//			updateContentsFile(allDocs, li, dir, replace_text_with_names);
		}

		if (mask_email) {
			AddressBook ab = (AddressBook) map.get("addressBook");
			EmailUtils.maskEmailDomain((Collection) allDocs, ab);
		}

		if (Util.hasRedundantElements(allDocs)) {
			log.warn("Some messages become redundant after processing and will be discarded.");
			allDocs = Util.removeDups(allDocs);
			assert(!Util.hasRedundantElements(allDocs));
		}
		map.put("emailDocs", allDocs); // allDocs may have been reassigned.
		archive.setAllDocs(allDocs);

		if (index_attachment) {
			FileBlobStore blobStore = (FileBlobStore) archive.blobStore;
			result &= li.indexAttachments((Collection) allDocs, blobStore);
		}

		result &= saveSession(dir.getAbsolutePath(), map, sessionName);

		return result;
	}


    private static void dumpNames(Collection<Document> docs, LuceneIndexer li)
    {
    	Map<String,Integer> name_count = new LinkedHashMap<String, Integer>();
		for (Document d : docs) {
			Set<String> names = li.getNames(d);
			log.info("Names = " + Util.joinSort(names, "|"));
			for (String n : names) {
				if (name_count.containsKey(n))
					name_count.put(n, name_count.get(n)+1);
				else
					name_count.put(n, 1);
			}
		}

		for (Map.Entry<String, Integer> e : name_count.entrySet()) {
			log.info("NameCount:" + e.getKey() + "|" + e.getValue());
		}
	}

    public static void prepareSessionForArchive(HttpSession session, String archiveId) throws CorruptIndexException, LockObtainFailedException, IOException
    {
    	if (Util.nullOrEmpty(archiveId)) return;
    	String archive_file = getArchiveInfoMap(archiveId).get("file");
    	String archive_full_filename = getSessionFilename(session, "default", archive_file);
    	if (!archive_full_filename.equals(JSPHelper.getSessionAttribute(session, ARCHIVE_NAME_STR)) // mismatching archive
    		||
    		getGlobalSession(session) == null // session timed out or invalidated
    		) {
    		// be forgiving and reload the archive on-demand
    		loadGlobalSession(session, "default", archive_file);
    	}
    }

}
