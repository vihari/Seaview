package edu.stanford.muse.ie;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import edu.stanford.muse.index.IndexUtils;
import edu.stanford.muse.util.Util;

public class Anagrams {
	
	private static Map<String, List<String>> sortedLettersMap = new LinkedHashMap<String, List<String>>(); 	/** stores entries like aet -> [tea, ate, eat] */
	static { setup(); }
	public static void setup()
	{
		for (String w: IndexUtils.fullDictWords)
		{
			String sortedW = sortLetters(w);
			List<String> list = sortedLettersMap.get(sortedW);
			if (list == null)
			{
				list = new ArrayList<String>();
				sortedLettersMap.put (sortedW, list);
			}
			list.add(w);
		}
	}
	
	public static String sortLetters(String s)
	{
		char[] chars = s.toCharArray();
		List<Character> list = new ArrayList<Character>();
		for (char c: chars)
			list.add(c);
		Collections.sort(list);
		StringBuilder sb = new StringBuilder();
		for (char c: list)
			sb.append(c);
		return sb.toString();
	}
	
	public int score(Collection<String> words) 
	{
		int score = 0;
		for (String word: words)
			if (IndexUtils.fullDictWords.contains(word))
				score++;
		return score;
	}
	
	/** get best 2 word anagram, if any */
	public static String getBestTwoWordAnagram(String s)
	{
		String sortedS = sortLetters(s);
		int len = s.length();
		for (int i = 0; i < (1 << len); i++)
		{
			String w1 = "", w2 = "";			
			for (int j = 0; j < len; j++)
			{
				if ((i & (1 << j)) == 0)
					w1 += sortedS.charAt(j);
				else
					w2 += sortedS.charAt(j);
			}

			if (w1.length() == 0 || w2.length() == 0)
				continue;
			Util.ASSERT (w1.length() + w2.length() == len);
			
			List<String> anagrams1 = sortedLettersMap.get(w1);
			if (anagrams1 == null)
				continue;
			List<String> anagrams2 = sortedLettersMap.get(w2);
			if (anagrams2 == null)
				continue;
			String selectedWord1 = null, selectedWord2 = null;
			for (String a1: anagrams1)
			{
				if (s.contains(a1))
					continue;
				selectedWord1 = a1;
				break;
			}

			for (String a2: anagrams2)
			{
				if (s.contains(a2))
					continue;
				selectedWord2 = a2;
				break;
			}

			if (selectedWord1 != null && selectedWord2 != null)
			{
				return selectedWord1 + " " + selectedWord2;
			}
		}
		return null;
	}
	
	public static String bestAnagram(String s, Random r)
	{
		String result = "";
		s = s.toLowerCase();
		
		String sortedW = sortLetters(s);
		
		// 1 word anagrams
		List<String> anagrams = sortedLettersMap.get(sortedW);
		if (anagrams != null)
		{
			for (String a : anagrams)
			{
				if (!a.equals(s))
					return a;
			}
		}
		
		// 2 word
		String twoWordAnagram = getBestTwoWordAnagram(s);
		if (!Util.nullOrEmpty(twoWordAnagram))
			return twoWordAnagram;
		return Util.permuteString(s, r);
	}
}
