/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.util;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.net.QuotedPrintableCodec;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import edu.stanford.muse.datacache.Blob;
import edu.stanford.muse.datacache.BlobStore;
import edu.stanford.muse.email.AddressBook;
import edu.stanford.muse.email.CalendarUtil;
import edu.stanford.muse.email.Contact;
import edu.stanford.muse.email.EmailThread;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.DatedDocument;
import edu.stanford.muse.index.Document;
import edu.stanford.muse.index.EmailDocument;
import edu.stanford.muse.index.IndexUtils;
import edu.stanford.muse.index.Indexer;
import edu.stanford.muse.index.LinkInfo;
import edu.stanford.muse.index.NER;
import edu.stanford.muse.index.NERTokenizer;

public class EmailUtils {
    public static Log log = LogFactory.getLog(EmailUtils.class);

    public static long MILLIS_PER_DAY = 1000L * 3600 * 24;
    
    /** best effort to print something about the given message. 
     *  use only for diagnostics, not for user-visible messages.
     *  treads defensively, this can be called to report on a badly formatted message.
     */
	public static String formatMessageHeader(MimeMessage m) throws MessagingException, AddressException
	{
		StringBuilder sb = new StringBuilder();
		sb.append ("To: ");
		try {
			Address[] tos = m.getAllRecipients();
			for (Address a: tos)
				sb.append (a.toString() + " ");
			sb.append ("\n");
		} catch (Exception e) { }
		
		sb.append ("From: ");
		try {
			Address[] froms = m.getFrom();
			for (Address a: froms)
				sb.append (a.toString() + " ");
		} catch (Exception e) { }

		try {
			sb.append("Subject: " + m.getSubject());
			sb.append("Message-ID: " + m.getMessageID());
		} catch (Exception e) { }
		return sb.toString();
	}

	// clean the dates
	public static void cleanDates(Collection<? extends Document> docs)
	{
		Date now = new Date();
		long time = now.getTime() + 1000 * 24 * 60 * 60L; // allow 1 day after current time 
		Date cutoff = new Date(time);
		
		Date earliestDate = new Date();
		Date latestDate = null;

		// compute earliest and latest dates. ignore dates after cutoff
		for (Document d: docs)
		{
			if (d instanceof DatedDocument)
			{
				DatedDocument dd = (DatedDocument) d;
				if (dd.date == null || dd.date.after(cutoff))
					continue;

				if (dd.date.before(earliestDate))
					earliestDate = dd.date;
				
				if (latestDate == null)
					latestDate = dd.date;
				else if (dd.date.after(latestDate))
					latestDate = dd.date;
			}
		}

		for (Document d: docs)
		{
			if (d instanceof DatedDocument)
			{
				DatedDocument dd = (DatedDocument) d;
				if (dd.date == null)
					dd.date = earliestDate;
				if (dd.date.after(cutoff))
				{
					log.warn ("Warning: date is beyond current time " + CalendarUtil.formatDateForDisplay(dd.date) + ", changing to last reasonable date, " + CalendarUtil.formatDateForDisplay(latestDate));
					dd.date = latestDate;
				}
			}
		}		
	}

	// strips the Re: of subjects
	public static String normalizedSubject(String subject)
	{
		String originalSubject = subject.toLowerCase();
		String result = originalSubject;
		// Strip all variations of re: Re: RE: etc... by converting subject to lowercase
		// but don't lose case on original subject
		subject = subject.toLowerCase();

		if (subject.startsWith ("re ") && subject.length() > "re ".length())
			result = originalSubject.substring("re ".length());
		if (subject.startsWith ("re: ") && subject.length() > "re: ".length())
			result = originalSubject.substring("re: ".length());
		return result;
	}

	// read all the headers
	public static List<EmailDocument> findAllDocs(String prefix) throws ClassNotFoundException
	{
		List<EmailDocument> allDocs = new ArrayList<EmailDocument>();
		int docCount = 0;
		while (true)
		{
			EmailDocument ed = null;
			String filename = prefix + "." + docCount + ".header";
			try {
				ObjectInputStream headerOIS = new ObjectInputStream(new FileInputStream(filename));
				ed = (EmailDocument) headerOIS.readObject();
				headerOIS.close();

		//		String contents = ed.getContents(); // Util.getFileContents(inputPrefix + "." + ed.docNum);
			} catch (IOException ioe) {
				break;
			}

			docCount++;
			allDocs.add(ed);
		}
		System.out.println (allDocs.size() + " documents found with prefix " + prefix);
		return allDocs;
	}

	public static List<EmailDocument> findAllDocs(List<String> prefixes) throws ClassNotFoundException
	{
		List<EmailDocument> allDocs = new ArrayList<EmailDocument>();
		for (String prefix: prefixes)
			allDocs.addAll (findAllDocs(prefix));

		return allDocs;
	}

	public static String[] getSharers(MimeMessage m) throws MessagingException
	{
		Set<String> result = new LinkedHashSet<String>();
		Address[] to =  m.getAllRecipients();
		Address[] from = m.getFrom();
		if (to != null) // to can sometimes be null e.g. for mbox files have a "IMAP server data -- DO NOT DELETE" as the first message
			for (Address a: to)
				if (a instanceof InternetAddress)
					result.add(((InternetAddress) a).getAddress().toLowerCase());
		if (from != null)
			for (Address a: from)
				if (a instanceof InternetAddress)
					result.add(((InternetAddress) a).getAddress().toLowerCase());

		String[] sharers = new String[result.size()];
		result.toArray(sharers);
		return sharers;
	}

	public static String emailAddrsToString(String[] addrs)
	{
		StringBuilder sb = new StringBuilder(addrs.length + " addresses: ");
		for (String s: addrs)
			sb.append(s + " ");
		return sb.toString();
	}

	// removes re: fwd etc from a subject line
	public static String cleanupSubjectLine(String subject)
	{
		if (subject == null)
			return null;
		// first strip mailing list name if any, at the beginning of the subject,
		// otherwise terms like [prpl-devel] appear very frequently
		StringTokenizer st = new StringTokenizer(subject);
		String firstToken = "";

		// firstToken is empty or the first non [mailing-list] first token
		while (st.hasMoreTokens())
		{
			firstToken = st.nextToken();
			String f = firstToken.toLowerCase();
			// these are the common patterns i've seen in subject lines
			if ("re".equals(f) || "re:".equals(f) || "fwd".equals(f) || "fwd:".equals(f) || "[fwd".equals(f) || "[fwd:".equals(f))
				 continue;
			// strip mailing list stuff as well
			if (f.startsWith("[") && f.endsWith("]") && f.length() < Indexer.MAX_MAILING_LIST_NAME_LENGTH)
				continue;

			break;
		}

		// firstToken is empty or the first non [mailing-list], non re/fwd/etc token
		String result = firstToken + " ";
		while (st.hasMoreTokens())
			result += st.nextToken() + " ";

		return result;
	}

	/** returns just the first message for each thread */
	public static List<EmailDocument> threadHeaders(List<EmailDocument> emails)
	{
		// map maps normalized subject to a list of threads that all have that thread
		Map<String,List<EmailThread>> map = new LinkedHashMap<String,List<EmailThread>>();

		for (EmailDocument email: emails)
		{
			String normalizedSubject = normalizedSubject(email.getSubjectWithoutTitle());
			if (normalizedSubject.indexOf("enigma card") >= 0)
				System.out.println ("ENIGMA");

			List<EmailThread> threads = map.get(normalizedSubject);
			if (threads == null)
			{
				threads = new ArrayList<EmailThread>();
				map.put (normalizedSubject, threads);
			}

			EmailThread existingThread = null;
			for (EmailThread thread: threads)
			{
				if (thread.belongsToThisThread(email))
				{
					existingThread = thread;
					break;
				}
			}

			if (existingThread != null)
				existingThread.addMessage(email);
			else
				threads.add(new EmailThread(email)); // new emailthread based on this message
		}

		System.out.println(map.keySet().size() + " unique subjects");

		List<EmailDocument> result = new ArrayList<EmailDocument>();

		for (String normalizedSubject: map.keySet())
		{
			List<EmailThread> threads = map.get(normalizedSubject);
			System.out.print ("Subject: " + normalizedSubject.replaceAll("\n", "") + ": ");
			System.out.print (threads.size() + " thread(s), : " );
			for (EmailThread et: threads)
			{
				System.out.print (et.size() + " ");
				result.add(et.emails.get(0));
			}
			System.out.println();
		}

		System.out.println(emails.size() + " emails reduced to " + result.size() + " threads");

		return result;
	}

    //	From - Tue Sep 29 11:38:30 2009
	static SimpleDateFormat sdf1 = new SimpleDateFormat("EEE MMM dd hh:mm:ss yyyy");
	// Date: Wed, 2 Apr 2003 11:53:17 -0800 (PST)
	static SimpleDateFormat sdf2 = new SimpleDateFormat("EEE, dd MMM yyyy hh:mm:ss");
	static Base64 base64encoder;
	public static Random rng = new Random(0);
	private static Set<String> bannedWordsInPeopleNames, bannedStringsInPeopleNames; // bannedWords => discrete word; bannedStrings => occurs anywhere in the name

	static {
		// if file separator is /, then newline must be \n, otherwise \r\n
		byte b[] = "/".equals(File.separator) ? new byte[]{(byte)10} : new byte[]{(byte)13, (byte)10};
		base64encoder = new Base64(76, b);
	}

	public static void printHeaderToMbox (EmailDocument ed, PrintWriter mbox) throws IOException, GeneralSecurityException
	{	
		/* http://www.ietf.org/rfc/rfc1521.txt is the official ref. */
		Date d = ed.date != null ? ed.date: new Date();
		String s = sdf1.format(d);
		mbox.println ("From - " + s);
		mbox.println ("Date: " + sdf2.format(d) + " +0000 GMT"); // watch out, this might not be the right date format
		mbox.println ("From: " + ed.getFromString());
		mbox.println ("To: " + ed.getToString());
		String cc = ed.getCcString();
		if (!Util.nullOrEmpty(cc))
			mbox.println ("Cc: " + cc);
		String bcc = ed.getBccString();
		if (!Util.nullOrEmpty(bcc))
			mbox.println ("Bcc: " + bcc);
			
		mbox.println ("Subject: " + ed.description);
		mbox.println ("Message-ID: " + ed.messageID);
		mbox.println ("X-Muse-Folder: " + ed.folderName);
		if (!Util.nullOrEmpty(ed.comment))
		{
			String comment = ed.comment;
			comment = comment.replaceAll("\n", " ");
			comment = comment.replaceAll("\r", " ");
			mbox.println ("X-Muse-Comment: " + comment);
		}
		if (ed.isLiked())
			mbox.println ("X-Muse-Liked: 1");			
	}
	
	public static void dumpMessagesToDir (Archive archive, Collection<EmailDocument> docs, String dir) throws IOException, GeneralSecurityException, ClassCastException, ClassNotFoundException
	{
		File f = new File(dir);
		f.mkdirs();
		int i = 0;
		NER.initialize();
		for (EmailDocument ed: docs)
		{
			try {
				PrintWriter pw = new PrintWriter (new FileOutputStream (dir + File.separatorChar + i + ".full"));
				String m = ed.description + "\n\n" + archive.getContents(ed, false /* full message */);
				pw.println (m);
				pw.close();
				
				pw = new PrintWriter (new FileOutputStream (dir + File.separatorChar + i + ".names"));
				
				NERTokenizer t = (NERTokenizer) NER.parse(m, false, false, null);
				String s = "";
				while (t.hasMoreTokens())			
				{
					Pair<String, String> tokenAndType = t.nextTokenAndType();
					String token = tokenAndType.getFirst().trim().toLowerCase();
					// drop dictionary words
					if (IndexUtils.fullDictWords.contains(token))
						continue;
					// drop "terms" with | -- often used as a separator on the web, and totally confuses our indexer's phrase lookup
					if (token.indexOf("|") >= 0)
						continue;
					s += token.replaceAll(" ", "_") + " ";
				}
				pw.println(s);
				pw.close();
			} catch (Exception e)
			{
				log.warn ("Unable to save contents of message: " + ed);
				Util.print_exception(e, log);				
			}
			i++;
		}
	}

	/* header is printed in mbox format, then each of the given contents sequentially
	 * if blobStore is null, attachments are not printed. could make this better by allowing text/html attachments.
	 */
	public static void printToMbox (Archive archive, EmailDocument ed, PrintWriter mbox, BlobStore blobStore)
	{
		String contents = "";
		try { 
			printHeaderToMbox(ed, mbox);		
			contents = archive.getContents(ed, false /* full message */); 
			printBodyAndAttachmentsToMbox(contents, ed, mbox, blobStore);
		} catch (Exception e) { Util.print_exception (e, log); }
	}
	
	public static void printBodyAndAttachmentsToMbox (String contents, EmailDocument ed, PrintWriter mbox, BlobStore blobStore) throws IOException, GeneralSecurityException
	{
		String frontier = "----=_Part_";
		List<Blob> attachments = null;
		if (ed != null)
			attachments = ed.attachments;
		boolean hasAttachments = !Util.nullOrEmpty(attachments) && blobStore != null;
		boolean isI18N = Util.isI18N(contents);

		if (!hasAttachments && !isI18N)
		{
			mbox.println ();
			mbox.println (contents);
			mbox.println ();
		}
		else
		{
			/*
			This is a multi-part message in MIME format.

			------=_Part_
			Content-Type: text/plain;
			        charset="iso-8859-1"
			Content-Transfer-Encoding: 7bit
			*/

			mbox.println ("Content-Type: multipart/mixed; boundary=\"" + frontier + "\"\n"); // blank line

			mbox.println ("This is a multi-part message in MIME format.\n"); // blank line

			mbox.println (frontier);
			mbox.println ("Content-Type: text/plain; charset=\"UTF-8\"");
			mbox.println ("Content-Encoding: quoted-printable\n"); // need blank line after this
			try {
				byte encodedBytes[] = QuotedPrintableCodec.decodeQuotedPrintable(contents.getBytes());
				for (byte by : encodedBytes)
					mbox.print((char) by);
				mbox.println();
			}
			catch (DecoderException de) {
				log.warn ("Exception trying to print contents!" + de);
				mbox.println(contents);
				mbox.println();
			}

			// probably need to fix: other types of charset, encodings
			if (blobStore != null)
			{
				for (Blob b: attachments)
				{
					mbox.println ("--" + frontier);
					mbox.println ("Content-type: " + b.contentType);
					mbox.println ("Content-transfer-encoding: base64");
					mbox.println ("Content-Disposition: attachment;filename=\"" + b.filename + "\"\n");
	
					byte bytes[] = blobStore.getDataBytes(b);
					byte encodedBytes[] = Base64.encodeBase64(bytes, true);
					for (byte by : encodedBytes)
						mbox.print((char) by);
					mbox.println ("--" + frontier + "--\n");
				}
			}
		}
	}

	/** gets the part before @ in the address */
	public static String getLoginFromEmailAddress(String emailAddress)
	{
		if (emailAddress == null)
			return null;
		int idx = emailAddress.indexOf("@");
		if (idx < 0)
			return emailAddress;
		return emailAddress.substring (0, idx);
	}


	// set of words that occur in non-real names.
	// if any of the tokens matches any of these words, we assume its not a real time.
	// hopefully there is no real person with a last name like postmaster...
	static {
		// IMPORTANT: these lists should be in lower case
		bannedWordsInPeopleNames = new LinkedHashSet<String>(); 
		bannedWordsInPeopleNames.add("return");
		bannedWordsInPeopleNames.add("request");
		bannedWordsInPeopleNames.add("requested");
		bannedWordsInPeopleNames.add("postmaster");
		bannedWordsInPeopleNames.add("administrator"); // sometimes we get "system administrator"
		bannedWordsInPeopleNames.add("project");
		bannedWordsInPeopleNames.add("user");
		bannedWordsInPeopleNames.add("workshop");
		bannedWordsInPeopleNames.add("subscriber");
		bannedWordsInPeopleNames.add("panel");
		bannedWordsInPeopleNames.add("committee");
		bannedWordsInPeopleNames.add("news");
		bannedWordsInPeopleNames.add("lab");
		bannedWordsInPeopleNames.add("list");
		bannedWordsInPeopleNames.add("recipient"); // usually generic list recipient
		bannedWordsInPeopleNames.add("unknown");
		bannedWordsInPeopleNames.add("pbwiki");

		// to get rid of various versions of "undisclosed-recipients" or "recipient-list"
		bannedStringsInPeopleNames = new LinkedHashSet<String>(); 
		bannedStringsInPeopleNames.add("undisclosed");
		bannedStringsInPeopleNames.add("recipient");
	}

	private static Pattern parensPattern = Pattern.compile ("\\(.*\\)");
	private static Pattern sqBracketsPattern = Pattern.compile ("\\[.*\\]");
	// hopefully people don't have any of these words in their names... note, should be lowercase
	
	/** normalizes the given person name.
		strips whitespace at either end
		returns null if not a valid name
	 */
	public static String cleanPersonName(String name)
	{
		if (name == null)
			return null;
		if (name.indexOf("@") >= 0) // an email addr, not a real name -- we dunno what's happening, just return it as is
			return name.toLowerCase();
		if ("user".equals(name))
			return null;
		
		// a surprising number of names in email headers start and end with a single quote
		// if so, strip it.
		if (name.startsWith("'") && name.endsWith ("'"))
			name = name.substring (1, name.length()-1);
	
		// Strip stuff inside parens, e.g. sometimes names are like:
		// foo bar (at home) - or -
		// foo bar [some Dept]
		Matcher m1 = parensPattern.matcher(name);
		name = m1.replaceAll ("");
		Matcher m2 = sqBracketsPattern.matcher(name);
		name = m2.replaceAll ("");
		name = name.trim();
	
		// normalize spaces
		// return null if name has banned words - e.g. ben shneiderman's email has different people with the "name" (IPM Return requested)
		String s = "";
		StringTokenizer st = new StringTokenizer(name);
		while (st.hasMoreTokens())
		{
			String t = st.nextToken();
			if (EmailUtils.bannedWordsInPeopleNames.contains(t.toLowerCase()))
				return null; 
			s += t + " ";
		}

		for (String bannedString: bannedStringsInPeopleNames)
			if (name.toLowerCase().indexOf(bannedString) >= 0)
				return null;
		
		return s;
	}

	// removes dups from the input list
	public static List<String> removeMailingLists(List<String> in)
	{
		List<String> result = new ArrayList<String>();
		for (String s: in)
		{
			s = s.toLowerCase();
			if (s.indexOf("@yahoogroups") >= 0 || s.indexOf("@googlegroups") >= 0 || s.indexOf("@lists.") >= 0 || s.indexOf("@mailman") >= 0 || s.indexOf("no-reply") >= 0 || s.indexOf("do-not-reply") >= 0)
			{
				log.debug ("Dropping mailing list or junk address: " + s);
				continue;
			}
			result.add(s);
		}
		return result;
	}

	// removes obviously bad names from the input list
	public static List<String> removeIncorrectNames(List<String> in)
	{
		List<String> result = new ArrayList<String>();
		for (String s: in)
		{
			if (s.toLowerCase().startsWith("undisclosed-recipients"))
			{
				log.info ("Dropping undisclosed recipients: " + s);
				continue;
			}
			if (s.toLowerCase().equals("user"))
			{
				log.info ("Dropping bad name: " + s);
				continue;
			}
			result.add(s);
		}
		return result;
	}
	
	/** try to get the last name */
	public static String getLastName(String fullName)
	{
		StringTokenizer st = new StringTokenizer(fullName);
		String lastToken = null;
		int nRealTokens = 0;
		while (st.hasMoreTokens())
		{
			String token = st.nextToken();
			if ("jr".equalsIgnoreCase(token))
				continue;
			// i don't actually know anyone with these suffixes, but in honor william gates III
			if ("i".equalsIgnoreCase(token) || "ii".equalsIgnoreCase(token) || "iii".equalsIgnoreCase(token) || "iv".equalsIgnoreCase(token) || "v".equalsIgnoreCase(token))
				continue;
			lastToken = token;
			nRealTokens++;
		}

		if (nRealTokens < 2)
			return null; // not two names
		if (lastToken.length() < 2)
			return null; // don't know what is happening
		return lastToken;
	}
	
	private final static Set<String> secondLevelDomains = new LinkedHashSet<String>();
	private final static String[] secondLevelDomainsArray = new String[]{"ac", "co"};
	private final static String[] serviceProvidersArray = new String[]{"hotmail", "gmail", "yahoo", "live", "msn", "pacbell", "vsnl", "comcast", "rediffmail"};
	private final static Set<String> serviceProviders = new LinkedHashSet<String>();
	static {
		for (String s: secondLevelDomainsArray)
			secondLevelDomains.add(s);
		for (String s: serviceProvidersArray)
			serviceProviders.add(s);
	}
	
	/** try to get the last name */
	public static String getOrg(String email)
	{
		if (!email.contains("@"))
			return null;
		
		StringTokenizer st = new StringTokenizer(email, "@. !");
		List<String> tokens = new ArrayList<String>();
		
		while (st.hasMoreTokens())
			tokens.add(st.nextToken());
		if (tokens.size() < 3)
			return null; // must have at least 3 tokens : a@b.org
		String org = tokens.get(tokens.size()-2).toLowerCase();
		if (secondLevelDomains.contains(org))
			org = tokens.get(tokens.size()-3);
		if (serviceProviders.contains(org))
			return null;

		return org;
	}
	
	public static void main (String args[])
	{
		String test[] = new String[]{"a@abc.com", "b@b@b.com", "c@cambridge.ac.uk", "d@hotmail.com", "e#live.com", "e@live.com"};
		for (String s: test)
			System.out.println (s + " org is: " + getOrg(s));
		String test1[] = new String[]{"bill gates iii", "Bill gates", "William H. Gates", "Ian Vo", "Ian V"};
		for (String s: test1)
			System.out.println (s + " lastname is: " + getLastName(s));
	}

	// compute the begin and end date of the corpus
	public static Pair<Date, Date> getFirstLast(Collection<? extends DatedDocument> allDocs)
	{
		// compute the begin and end date of the corpus
		Date first = null;
		Date last = null;
	
		if (allDocs == null)
			return null;
		
		for (DatedDocument ed: allDocs)
		{
			Date d = ed.date;
			if (d == null)
			{	// drop this ed
				EmailUtils.log.warn ("Warning: null date on email: " + ed.getHeader());
				continue;
			}
			if (first == null || d.before(first))
				first = d;
			if (last == null || d.after(last))
				last = d;
		}
	
		return new Pair<Date, Date>(first, last);
	}

	public static<T extends Comparable<? super T>> List<T> removeDupsAndSort(List<T> docs)
	{
		log.info("-----------------------Detecting duplicates-------------------");
			Set<T> set = new LinkedHashSet<T>();
			set.addAll(docs);
	
			// maintain a map so when we find a duplicate, we can print both the dup and the original
			Map<T, T> map = new LinkedHashMap<T, T>();
			for (T ed: docs)
			{
				if (map.get (ed) != null)
					log.info ("Duplicate messages:\n\t" + ed + "\n\t" + map.get(ed));
				map.put(ed, ed);
			}
	
			List<T> result = new ArrayList<T>();
			result.addAll(set);
			Collections.sort(result);
	//		for (EmailDocument ed: result)
	//			System.out.println ("doc: " + ed);
	
			log.info("Removed duplicates from " + docs.size() + " messages: " + (docs.size() - result.size()) + " removed, " + result.size() + " left");
	
			return result;
		}

	public static boolean allDocsAreDatedDocs(Collection<? extends Document> ds)
	{
		for (Document d: ds)
			if (!(d instanceof DatedDocument))
				return false;
		return true;
	}

	public static List<LinkInfo> getLinksForDocs(Collection<? extends Document> ds)
	{
		// extract links from the given docs
		List<LinkInfo> links = new ArrayList<LinkInfo>();
		if (ds == null)
			return links;
	
		for (Document d: ds)
			if (d.links != null)
				links.addAll(d.links);
		return links;
	}

	public static int countAttachmentsInDocs(Collection<EmailDocument> docs)
	{
		int count = 0;
		if (docs == null)
			return 0;
		for (EmailDocument ed: docs)
			if (ed.attachments != null)
				count += ed.attachments.size();
		return count;
	}
	
	public static int countImageAttachmentsInDocs(Collection<EmailDocument> docs)
	{
		int count = 0;
		if (docs == null)
			return 0;
		for (EmailDocument ed: docs)
			if (ed.attachments != null)
				for (Blob b: ed.attachments)
					if (Util.is_image_filename(b.filename)) // consider looking at b.contentType as well
						count++;
		return count;
	}

	public static int getMessageCount(List<Pair<String, Integer>> foldersAndCounts)
	{
		int totalMessageCount = 0;
		for (Pair<String,Integer> p : foldersAndCounts)
			if (! "[Gmail]/All Mail".equals(p.getFirst())) // don't count special case of gmail/all mail
				totalMessageCount += p.getSecond();
		return totalMessageCount;
	}

	public static List<Date> datesForDocs(Collection<? extends DatedDocument> c)
	{
		List<Date> result = new ArrayList<Date>();
		for (DatedDocument d: c)
			result.add(d.date);
		return result;
	}

	public static void maskEmailDomain(Collection<EmailDocument> docs, AddressBook ab)
	{
		ab.maskEmailDomain();
		for (EmailDocument e : docs) {
			e.maskEmailDomain(ab);
		}
	}

	/** returns set of all messages that have one of these attachments */
	public static Set<? super EmailDocument> getDocsForAttachments(Collection<EmailDocument> docs, Set<Blob> blobs)
	{
		Set<EmailDocument> result = new LinkedHashSet<EmailDocument>();
		if (docs == null || blobs == null) return result;

		for (EmailDocument ed: docs)
		{
			if (ed.attachments == null)
				continue;
			for (Blob b: ed.attachments)
			{
				if (blobs.contains(b)) {
					result.add(ed);
					break; // no need to check its other attachments
				}
			}
		}
		return result;
	}

	/** little util method get an array of all own addrs, given 1 addr and some alternate ones.
	 * alternateaddrs could have multiple addrs, separated by whitespace or commas
	 * either of the inputs could be null */
	public static Set<String> parseAlternateEmailAddrs(String alternateAddrs)
	{
		Set<String> result = new LinkedHashSet<String>();
		if (Util.nullOrEmpty(alternateAddrs))
			return result;
					
		StringTokenizer st = new StringTokenizer(alternateAddrs, "\t ,");
		while (st.hasMoreTokens())
			result.add(st.nextToken().toLowerCase());
	
		// log own addrs
		StringBuilder sb = new StringBuilder();
		for (String s : result)
			sb.append (s  + " ");
		AddressBook.log.info (result.size() + " own email addresses: " + sb);
		return result;
	}

	/** returns contact -> {in_dates, out_dates} map.
	 * not responsible for dups, i.e. dedup should have been done before.
	 * we can consider caching this on contacts directly if it becomes a performance problem.
	 */
	public static Map<Contact, Pair<List<Date>, List<Date>>> computeContactToDatesMap(AddressBook ab, Collection<EmailDocument> list)
	{
		Map<Contact, Pair<List<Date>, List<Date>>> result = new LinkedHashMap<Contact, Pair<List<Date>, List<Date>>>();
		
		// note that we'll add the same date twice if the same contact has 2 different email addresses present on the message.
		// consider changing this if needed.
		for (EmailDocument ed: list)
		{
			String senderEmail = ed.getFromEmailAddress();
			if (Util.nullOrEmpty(senderEmail))
				senderEmail = "------ <NONE> -------"; // dummy, we want to process the other addresses even if sender is not available
				
			List<String> allEmails = ed.getAllAddrs();
			for (String email: allEmails)
			{
				if (ed.date == null)
					continue; // no date, no point processing
				
				Contact c = ab.lookupByEmail(email);
				if (c == null)
					continue; // shouldn't happen, but defensive
				
				Pair<List<Date>, List<Date>> p = result.get(c);
				if (p == null)
				{
					p = new Pair<List<Date>, List<Date>>(new ArrayList<Date>(), new ArrayList<Date>()); // not seen this contact before
					result.put(c, p);
				}
				
				if (senderEmail.equals(email))
					p.getSecond().add(ed.date);
				else
					p.getFirst().add(ed.date);
			}
		}
		return result;
	}

	public static String getOriginalContent(String text) throws IOException
	{
		StringBuilder result = new StringBuilder();
		BufferedReader br = new BufferedReader(new StringReader(text));
	
		// stopper for the tokenizer when we meet a line that needs to be ignored
		String stopper = " . ";
		
		// we'll maintain line nad nextLine for lookahead. needed for the "on .... wrote:" detection below
		String line = null;
		String nextLine =  br.readLine();
	
		while (true)
		{
			line = nextLine;
			if (line == null)
				break;			
			line = line.trim();
			nextLine = br.readLine();

			/* Yahoo replies look like this. they don't use the quote character.
				--
				This is another test. Another president's name is Barack Obama.
				________________________________
				 From: Sudheendra Hangal <hangal@cs.stanford.edu>
				To: sd sdd <s_hangal@yahoo.com> 
				etc.
				--
			    so lets eliminate everything after a line that goes ________________________________
			    i.e. at least 20 '_' chars, and the following line has a colon
			*/
			if (line.length() > 20 && Util.hasOnlyOneChar(line, '_') && nextLine != null && nextLine.indexOf(":") > 0) {
				break; 
			}
			
			// eliminate everything after the line "On Wed, Jul 3, 2013 at 2:06 PM, Sudheendra Hangal <hangal@gmail.com> wrote:"
			// however, sometimes this line has wrapped around on two lines, so we use the nextLine lookahead if it's present
			if ((line.startsWith("On ") && line.endsWith("wrote:")) || 
				(line.startsWith("On ") && line.length() < 80 && (nextLine != null && nextLine.trim().endsWith("wrote:"))))
			{
				break;
			}
			
			// look for forward separator
			String lowercaseLine = line.toLowerCase();
			if (lowercaseLine.startsWith("Begin forwarded message:"))
				break;
			if (line.startsWith("---") && line.endsWith("---") && lowercaseLine.contains("forwarded message"))
				break;
			
			// we can eliminate all text starting with a single > , or all text starting with 2 > (2 > might be able to capture text that is coming in to the user, that the user has replied to)
//			line = line.replaceAll("^\\s*>\\s*>.*$", stopper); // nuke lines beginning with 2 or more > (this assumes we're looking at sent mail only)
			line = line.replaceAll("^\\s*>.*$", stopper); // nuke lines beginning with 2 or more > (this assumes we're looking at sent mail only)
			result.append(line);
			result.append("\n");
		}
		
		result.append ("\n");
		return result.toString();
	}

	// text is an email message, returns a sanitized version of it
	// after stripping away signatures etc.
	public static String cleanupEmailMessage (String text) throws IOException
	{
		StringBuilder result = new StringBuilder();
		BufferedReader br = new BufferedReader(new StringReader(text));
		while (true)
		{
			String line = br.readLine();
			if (line == null)
				break;
			line = line.trim();
			if (line.equals("--")) // strip all lines including and after signature
				break;
	
			if (line.contains("Original message") || line.contains("Forwarded message"))
			{
				int idx1 = line.indexOf("-----");
				int idx2 = line.lastIndexOf("-----");
				if (idx1 >= 0 && idx2 >= 0 && idx1 != idx2)
					break;
			}
	
			if (line.startsWith("On ") && line.endsWith("wrote:"))
				break;
	
			result.append (line + "\n");
		}
	
		return result.toString();
	}	
	
	private static List<String> emailAddrs(Address[] as) {
		List<String> result = new ArrayList<String>();
		if (as == null)
			return result;

		for (Address a: as)
		{
			String email = ((InternetAddress) a).getAddress();
			if (email != null)
				result.add(email.toLowerCase());
		}
		return result;
	}
	
	/** thread a collection of emails */
	public static Collection<Collection<EmailDocument>> threadEmails(Collection<EmailDocument> docs)
	{
		Map<String, Collection<EmailDocument>> map = new LinkedHashMap<String, Collection<EmailDocument>>();
		for (EmailDocument ed: docs)
		{
			// compute a canonical thread id, based on the cleaned up subject line (removing re: fwd: etc) and the description.
			// in the future, could consider date ranges too, e.g. don't consider messages more than N days apart as the same thread
			// even if they have the same subject and recipients
			// for gmail only -- there is a thread id directly in gmail which can potentially be used 
			String canonicalSubject = cleanupSubjectLine(ed.description);
			// we prob. don't care about canonical case for subject
			
			List<String> addrs = emailAddrs(ed.to);
			addrs.addAll(emailAddrs(ed.cc));
			addrs.addAll(emailAddrs(ed.from));
			Collections.sort(addrs);
			String threadId = canonicalSubject + " " + Util.join(addrs, ",");
			// canonical id for the thread.
			Collection<EmailDocument> messagesForThisThread = map.get(threadId);
			if (messagesForThisThread == null)
			{
				messagesForThisThread = new ArrayList<EmailDocument>();
				map.put(threadId, messagesForThisThread);
			}
			messagesForThisThread.add(ed);
		}
		return map.values();
	}

	/** returns a histogram of the dates, bucketed in quantum of quantum, going backwards from endTime */
	public static List<Integer> histogram(List<Date> dates, long endTime, long quantumMillis)
	{
		ArrayList<Integer> result = new ArrayList<Integer>();
	
		// input dates may not be sorted, but doesn't matter
		for (Date d: dates)
		{
			int slot = (int) ((endTime - d.getTime())/quantumMillis);
	
			// ensure list has enough capacity because there may be gaps
		    while (result.size() <= slot)
		        result.add(0);
		    
		    // result.size() is at least slot+1    
			Integer I = result.get(slot);
			result.set(slot, I+1);
		}
		
		return result;
	}
}
