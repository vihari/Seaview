package edu.stanford.muse.util;
public class Version {  public static final String num = "0.9.73"; 
public static final String buildInfo = "Built by hangal, Tue 20 Aug 2013 3:54 PM";} 
