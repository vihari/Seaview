/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.webapp;

public class Config {
	public static Mode mode = Mode.READING_ROOM_MODE;

	// default: reading_room_mode
	// admin_mode: shows advanced options
	// public_mode: provides limited view
	public enum Mode { ADMIN_MODE, SERVER_MODE, READING_ROOM_MODE, PUBLIC_MODE };
	// TODO: probably need more dimensions. e.g., read-only vs. read-write, full archive vs. restricted archive, server-hosted vs desktop
	
	static {
		if (System.getProperty("muse.mode.public") != null) // in public mode if this property is set (highest precedence)
			mode = Mode.PUBLIC_MODE;
		else if (System.getProperty("muse.mode.server") != null) // in server mode (hosted mode) if this property is set
			mode = Mode.SERVER_MODE;
		else if (System.getProperty("muse.mode.admin") != null) // in admin mode if this property is set
			mode = Mode.ADMIN_MODE;
	}

	/** 
	 * @return true if Muse is configured to run in admin mode.
	 */
	public static boolean isAdminMode()
	{
		return mode == Mode.ADMIN_MODE;
	}

	/** 
	 * @return true if Muse is configured to run in public mode (read-only and restricted archives).
	 */
	public static boolean isPublicMode()
	{
		return mode == Mode.PUBLIC_MODE;
	}

	/** 
	 * @return true if Muse is configured to run in server mode (fixed root dir and multi-user with full access to their respective userKey).
	 */
	public static boolean isServerMode()
	{
		return mode == Mode.SERVER_MODE;
	}

	/*
	 * @return true if Muse is running in a mode that accepts connections from multiple users concurrently (public mode, reading-room mode, or hosted mode).
	 */
	public static boolean isMultiUser()
	{
		return isPublicMode() || isServerMode();
	}
};