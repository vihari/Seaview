package edu.stanford.muse.webapp;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.store.LockObtainFailedException;

import edu.stanford.muse.email.MuseEmailFetcher;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.Document;
import edu.stanford.muse.util.Util;

public class SimpleSessions {
    public static Log log = LogFactory.getLog(Sessions.class);

    /** loads session from the given filename, and returns the map of loaded attributes.
     *  if readOnly is false, caller MUST make sure to call packIndex.
     *  baseDir is LuceneIndexer's baseDir (path before "indexes/")
     * @throws IOException 
     * @throws LockObtainFailedException 
     * @throws CorruptIndexException */
    public static Map<String, Object> loadSessionAsMap(String filename, String baseDir, boolean readOnly) throws CorruptIndexException, LockObtainFailedException, IOException
	{
		log.info("Loading session from file " + filename + " size: "+ Util.commatize(new File(filename).length()/1024) + " KB");
	
		ObjectInputStream ois = null;
		
		// keep reading till eof exception
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		try {
			ois = new ObjectInputStream(new GZIPInputStream(new FileInputStream(filename)));

		    while (true)
		    {
	    		String key = (String) ois.readObject();
		    	log.info ("loading key: " + key);
		    	try {
		    		Object value = ois.readObject();
		    		result.put(key, value);
		    	} catch (InvalidClassException ice)
		    	{
		    		log.error("Bad version for value of key " + key + ": " + ice + "\nContinuing but this key is not set...");
		    	} catch (ClassNotFoundException cnfe)
		    	{
		    		log.error("Class not found for value of key " + key + ": " + cnfe + "\nContinuing but this key is not set...");
		    	}
		    }
		  } catch (EOFException eof) { log.info("end of session file reached");}
		  catch (Exception e) { log.warn("Warning unable to load session: " + Util.stackTrace(e)); result.clear(); }

		if (ois != null)
			try { ois.close(); } catch (Exception e) { }

		// need to set up sentiments explicitly -- now no need since lexicon is part of the session
		log.info ("Memory status: " + Util.getMemoryStats());

		Archive archive = (Archive) result.get("archive");

		// no groups in public mode
		if (archive != null)
		{
			// most of this code should probably move inside Archive, maybe a function called "postDeserialized()"
			archive.postDeserialized(baseDir, readOnly);
			result.put("emailDocs", archive.getAllDocs());
		}

		return result;
	}
    
	/** saves the archive in the current session to the cachedir */
	public static boolean saveArchive(HttpSession session) throws FileNotFoundException, IOException
	{
		Archive archive = (Archive) session.getAttribute("archive");
		String baseDir = (String) session.getAttribute("cacheDir");
		return saveArchive(baseDir, "default", archive);
	}

	/** saves the archive in the current session to the cachedir */
	public static boolean saveArchive(String baseDir, String name, Archive archive) throws FileNotFoundException, IOException
	{
		String dir = baseDir + File.separatorChar + "sessions";
		new File(dir).mkdirs(); // just to be safe
		String filename = dir + File.separatorChar + name + Sessions.SESSION_SUFFIX;
		log.info("Saving archive to (session) file " + filename);

		archive.close();

		ObjectOutputStream oos = new ObjectOutputStream(new GZIPOutputStream(new FileOutputStream(filename)));
		try { 
    		oos.writeObject("archive");
    		oos.writeObject(archive);
		} catch (Exception e1) {
			log.warn ("Failed to write archive: " + e1);
			oos.close();
			return false;
		}
		oos.close();

		archive.openForRead();

		return true;
	}

    /** loads an archive from the given directory. return false if it exists */
    public static Archive readArchiveIfPresent(String baseDir) throws CorruptIndexException, LockObtainFailedException, IOException
    {
    	String archiveFile = baseDir + File.separator + "sessions" + File.separator + "default" + Sessions.SESSION_SUFFIX;
    	if (!new File(archiveFile).exists())
    		return null;
    	
    	Map<String, Object> map = loadSessionAsMap(archiveFile, baseDir, /* read only */ true);
    	// read the session map, but only use archive
    	Archive a = (Archive) map.get("archive");
    	// could do more health checks on archive here
    	return a;
    }
    
    /** reads from default dir (usually ~/.muse/user) */
    public static void prepareAndLoadDefaultArchive(HttpServletRequest request) throws CorruptIndexException, LockObtainFailedException, IOException
    {
    	HttpSession session = request.getSession();

    	// allow cacheDir parameter to override default location
		String dir = request.getParameter("cacheDir");
		if (Util.nullOrEmpty(dir))
			dir = Sessions.CACHE_DIR;
			
		Archive archive = SimpleSessions.readArchiveIfPresent(dir);
		if (archive != null)
		{
			JSPHelper.log.info ("Good, default session found");
	
			// always set these three together
			session.setAttribute("userKey", "user");
			session.setAttribute("cacheDir", dir);
			session.setAttribute("archive", archive);
			Archive.prepareBaseDir(dir); // prepare default lexicon files etc.
		}
    }

    public static void prepareAndLoadArchive(MuseEmailFetcher m, HttpServletRequest request) throws CorruptIndexException, LockObtainFailedException, IOException
    {
    	HttpSession session = request.getSession();
    	
        // here's where we create a fresh archive
    	String userKey = "user";
        if (Config.isServerMode())
        {
        	// use existing key, or if not available, ask the fetcher which has the login email addresses for a key
    		userKey = (String) session.getAttribute("userKey");
    		if (Util.nullOrEmpty(userKey))
    			userKey = m.getEffectiveUserKey();
    		Util.ASSERT(!Util.nullOrEmpty(userKey)); // disaster if we got here without a valid user key
        }
        
    	String archiveDir = Sessions.CACHE_BASE_DIR + File.separator + userKey;
    	Archive archive = SimpleSessions.readArchiveIfPresent(archiveDir);
    	
    	if (archive != null) {
    		JSPHelper.log.info ("Good, existing archive found");
    	} else {
    		JSPHelper.log.info("Creating a new archive in " + archiveDir);
    		archive = JSPHelper.preparedArchive(request, archiveDir, new ArrayList<String>());
    	}
    	// always set these three together
    	session.setAttribute("userKey", userKey);
    	session.setAttribute("cacheDir", archiveDir);
    	session.setAttribute("archive", archive);
    }
    
	public static void main (String args[]) throws CorruptIndexException, LockObtainFailedException, IOException
	{
		// just use as <basedir> <string to find>
		Archive a = readArchiveIfPresent(args[0]);
		for (Document d: a.getAllDocs())
		{
			String c = a.getContents(d, false);
			if (c.indexOf(args[1]) >= 0)
			{
				System.out.println ("\n______________________________" + d + "\n\n" + c + "\n___________________________\n\n\n");
			}
		}
		
	}

}
