package edu.stanford.muse.webapp;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.mail.internet.InternetAddress;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.CorruptIndexException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import edu.stanford.muse.email.AddressBook;
import edu.stanford.muse.ie.Anagrams;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.EmailDocument;
import edu.stanford.muse.index.Lexicon;
import edu.stanford.muse.index.LuceneIndexer;
import edu.stanford.muse.index.NER;
import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.Util;
import edu.stanford.muse.util.Util.MyFilenameFilter;
import edu.stanford.muse.xword.Clue;
import edu.stanford.muse.xword.Crossword;
import edu.stanford.muse.xword.Word;

public class CrosswordHelper {

	public static Log log = LogFactory.getLog(CrosswordHelper.class);
 	static Random r = new Random();
	private static final int DEFAULT_TIMEOUT_MILLIS = 5000; // default timeout

	public static Crossword createCrossword (HttpServletRequest request) throws Exception
	{
		Map<String, String> map = HTMLUtils.getRequestParamMap(request);
		return createCrossword(map, request.getSession());
	}
	
	public static Crossword createCrossword (Map<String, String> params, HttpSession session) throws Exception
	{
		// print a count of the most popular names

		String inputText = params.get("text"); // we extract names and create clues from the text
		String inputTable = params.get("table"); // we are given pre-defined answers and clues
		int timeoutMillis = DEFAULT_TIMEOUT_MILLIS;
		String millisStr = params.get("millis");
		if (millisStr != null)
		{
			try {
					timeoutMillis = Integer.parseInt(millisStr);
			} catch (Exception e) { log.warn ("Bad timeout millis: " + millisStr); }
		}
		
		inputTable = JSPHelper.convertRequestParamToUTF8(inputTable);
		Map<String, Clue> fixedClues = null;

		Map<String, Integer> map = new LinkedHashMap<String, Integer>();

		Map<String, Integer> thirdPartyCount = new LinkedHashMap<String, Integer>();
		Set<String> filteredIds = null;
		Archive archive = null;

		boolean usingStructuredText = !Util.nullOrEmpty(inputTable);
		
		boolean haveMessages = false;
		if (!Util.nullOrEmpty(inputText))
		{	
			haveMessages = false;
			archive = Archive.createArchive();
			archive.setup("/tmp/xword." + Integer.toString(r.nextInt()), null); // no archive args, we're just going to index one doc
			if (session != null)
				session.setAttribute("archive", archive);
			filteredIds = parseRawText(params, inputText, map, archive);
		}
		else if (usingStructuredText)
		{
			haveMessages = false;
			fixedClues = new LinkedHashMap<String, Clue>();
			parseStructuredText(inputTable, fixedClues);
			for (String s: fixedClues.keySet())
				map.put(s, 2); // dummy weight, to avoid getting filtered out
		}
		else
		{
			// xword input from current session
			haveMessages = true;
			archive = JSPHelper.getArchive(session);
			Collection<edu.stanford.muse.index.Document> allDocs = (Collection) session.getAttribute("emailDocs");
			if (allDocs == null)
				allDocs = archive.getAllDocs();
			
			/* identify ids of docs (may be filtered, and a subset of all the docs in the indexer) */

			filteredIds = new LinkedHashSet<String>();
			for (edu.stanford.muse.index.Document d : allDocs)
				filteredIds.add(d.getUniqueId());

			map = scoreNames((LuceneIndexer) archive.indexer, thirdPartyCount, filteredIds, archive);
		}

		int minAnswerLen, maxAnswerLen;

		// if using structured text, default min/max word lens don't apply
		if (usingStructuredText)
		{
			// essentially no limit if using structured text
			minAnswerLen = HTMLUtils.getIntParam(params, "minwordlen", 1); 
			maxAnswerLen = HTMLUtils.getIntParam(params, "maxwordlen", Integer.MAX_VALUE); 			
		}
		else
		{
			// if not specified, they end up as -1, which means it will use xword's default
			minAnswerLen = HTMLUtils.getIntParam(params, "minwordlen", -1); 
			maxAnswerLen = HTMLUtils.getIntParam(params, "maxwordlen", -1); 			
		}
		
		// sort names by freq.
		List<Pair<String, Integer>> termFreqList = Util.sortMapByValue(map);
		List<Pair<String, Integer>> newTermFreqList = new ArrayList<Pair<String, Integer>>();
		for (Pair<String, Integer> p: termFreqList)
		{
			if (p.getSecond() == 1)
				break;
			newTermFreqList.add(p);
		}
		JSPHelper.log.info("Candidate answer set reduced from: " + termFreqList.size() + " to: " + newTermFreqList.size() + " after dropping singletons");
		//		termFreqList = newTermFreqList;

		/*
	 		for (String name: possibleAnswers)
	 		{
	 			JSPHelper.log.info("Word candidate: " + name
	 					//	+ " - occurs " + Util.pluralize(p.getSecond(), "time")
	 					+ " (3rd party: "
	 					+ thirdPartyCount.get(name.toLowerCase()) + ")");
	 		}
		 */

		// don't generate a new crossword if it already exists and we just need answers
		Lexicon lex = (session != null) ? (Lexicon) session.getAttribute("lexicon") : null;
		if (session != null && lex == null)
		{
			String baseDir = (String) session.getAttribute("cacheDir");
			String name = "default";
			lex = new Lexicon(baseDir, name);
			session.setAttribute("lexicon", lex);	
		}

		boolean doSymmetric = params.get("symmetric") != null;
		int size = HTMLUtils.getIntParam(params, "size", 15); 

		if (params.get("noclues") != null)
			archive = null;
		if (params.get("noclues") != null)
			archive = null;

		if (params.get("clearTabooWords") != null)
			if (session != null)
				session.removeAttribute("tabooWords");

		Set<String> tabooWords = (session != null) ? (Set<String>) session.getAttribute("tabooWords") : null;
		Crossword c = null;

		if (size == -1)
		{
			// start from #words / 3. e.g. we can't fit 45 words in less than a 15x15 grid
			int maxLen = 0;
			for (Pair<String, Integer> p: termFreqList)
			{
				String s = p.getFirst();
				if (s.length() > maxLen)
					maxLen = s.length();
			}

			int minSize = Math.max(termFreqList.size()/3, maxLen);
			
			for (size = minSize; size < 35; size += 2)
			{
				int w = size, h = size;
				try {
					c = Crossword.createCrossword(termFreqList, w, h, archive, lex, filteredIds, tabooWords, doSymmetric, fixedClues, minAnswerLen, maxAnswerLen, timeoutMillis);
				} catch (Exception e) {
					log.warn ("Error trying to create xword with size: " + w + ", " + h);
					Util.print_exception(e, log);
					// ignore the error, try with the next size
				}
				JSPHelper.log.info ("RESULT " + c.placedWords.size() + " words placed for size: " + size);
				Set<String> set1 = new LinkedHashSet<String>();
				if (c != null && c.placedWords.size() == termFreqList.size())
					break;

				// debug info
				StringBuilder sb = new StringBuilder("Not placed: ");
				for (Pair<String, Integer> s: termFreqList)
					set1.add(s.getFirst());
				Set<String> set2 = new LinkedHashSet<String>();
				if (c != null)
					for (Word W: c.placedWords)
						set2.add(W.originalTerm.toLowerCase());
				set1.removeAll(set2);
				for (String s: set1)
					sb.append(s + " ");
				log.info(sb);
				
				/*
				termFreqList = new ArrayList<Pair<String, Integer>>();
				// put the unplaced words on top now
				for (String s: set1)
					termFreqList.add(new Pair<String, Integer>(s, 2));
				for (String s: set2)
					termFreqList.add(new Pair<String, Integer>(s, 2));
				 */					
			}
		}
		else
		{
			int w = HTMLUtils.getIntParam(params, "w", size); 
			int h = HTMLUtils.getIntParam(params, "h", size); 
			c = Crossword.createCrossword(termFreqList, w, h, archive, lex, filteredIds, tabooWords, doSymmetric, fixedClues, minAnswerLen, maxAnswerLen, timeoutMillis);
		}

		String title = params.get("title");
		if (!Util.nullOrEmpty(title))
			c.title = title;
		String author = params.get("author");
		if (!Util.nullOrEmpty(author))
			c.author = author;
		String help = params.get("help");
		if (!Util.nullOrEmpty(help))
			c.help = help;

		if (tabooWords == null)
			tabooWords = new LinkedHashSet<String>();
		else
			JSPHelper.log.info ("adding words to already existing taboo set of " + tabooWords.size() + " words");

		//add all the words in this xword to the taboowords set
		for (Word W: c.placedWords)
			tabooWords.add(W.word);
		if (session != null)
		{
			session.setAttribute("tabooWords", tabooWords);
			session.setAttribute("crossword", c);
		}
		c.haveMessages = haveMessages;
		
		String tn_url = params.get("tn");
		if (!Util.nullOrEmpty(tn_url))
		{
			try {
				byte ba[] = Util.getBytesFromStream (new URL(tn_url).openStream());
				ba = Base64.encodeBase64(ba);
				StringBuilder sb = new StringBuilder();
				for (byte b: ba)
					sb.append((char) b);
				c.tn = sb.toString();
				c.tn_url = tn_url;
			} catch (Exception e) {
				Util.print_exception(e, log);
			}
		}
		
		if (!Util.nullOrEmpty(inputText))
		{
			c.refURL = params.get("refURL");
			// the full message is really a dummy
			// give the original url instead
			
			for (Word W: c.placedWords)
			{
				Clue C = W.getClue();
				if (C == null)
					continue;
				W.getClue().clearFullMessage();
				W.getClue().setUrl(c.refURL);
			}
		}
		return c;
	}
	
	private static Map<String, Integer> scoreNames(LuceneIndexer li,
			Map<String, Integer> thirdPartyCount, Set<String> filteredIds,
			Archive archive) throws CorruptIndexException, IOException 
	{
		AddressBook ab;
		Map<String, Integer> map;
		ab = archive.addressBook;
		archive.openForRead();

		List<Set<String>> docs = li.getAllNames(filteredIds, true /* original names only */);
		// docs is now the set of names in the filtered docs. count the names
		map = new LinkedHashMap<String, Integer>();
		for (Set<String> names : docs) {
			if (names == null)
				continue;
			for (String name : names) {
				name = name.toLowerCase();
				Integer I = map.get(name);
				map.put(name, (I == null) ? 1 : I + 1);
			}
		}

		if (thirdPartyCount != null) {
			// this is simply for 3rd party count, not very important.
			Map<String, EmailDocument> map1 = li.getDocMap();
			for (EmailDocument ed : map1.values()) {
				Set<String> names = li.getNames(ed, true /* original names only */);
				if (names == null)
					continue;
				Set<String> seen = new LinkedHashSet<String>(); // names seen in this doc, canonicalized
				for (String name : names) {
					name = name.toLowerCase();
					if (seen.contains(name))
						continue;
					seen.add(name);
					if (ed.isThirdPartyName(ab, name)) {
						Integer I = thirdPartyCount.get(name);
						thirdPartyCount.put(name, (I == null) ? 1 : I + 1);
					}
				}
			}
		}
		return map;
	}

	/** extracts URLs from text and returns a pair <updated text with urls removed, list of urls extracted> */
	private static Pair<String, List<String>> extractURLs (String text)
	{
		List<String> urls = new ArrayList<String>();
		
		String regex = "http://[^\\s]*(\\s|$)|https://[^\\s]*(\\s|$)";
		Pattern linkPattern = Pattern.compile(regex);
		Matcher linkMatcher = linkPattern.matcher(text);
		while (linkMatcher.find())
		{
			// from start of link, go back to the closest delimiter.
			int linkstartIndex = linkMatcher.start();
			int linkendIndex = linkMatcher.end();
			String link = text.substring(linkstartIndex, linkendIndex);
			urls.add(link);
		}
		String cleanText = text.replaceAll(regex, ""); // nuke the urls
		return new Pair<String, List<String>>(cleanText, urls);
	}

	/** reads formatted input text, and sets up the fixedClues structure */
	private static void parseStructuredText(String inputTable, Map<String, Clue> fixedClues) throws IOException 
	{
		log.info ("Parsing structured text: \n" + inputTable);
		Random r = new Random(0);
		char FIELD_SEPARATOR = '|';
		
		List<String> lines = Util.getLinesFromReader(new StringReader(inputTable), false);
		for (String line: lines)
		{
			try { 
				line = line.trim();
				if (line.length() == 0 || line.startsWith("# "))
					continue; // ignore blank lines and lines starting with # - note the space after #. hashtags can't have space immediately after the #

				// field has up to 4 inputs
				String answer = null, clueText = null, clueHint = null, refURL = null;			

				if (line.indexOf(FIELD_SEPARATOR) >= 0)
				{
					// look for separator
					// replace 2 consecutive separators with a space in between 
					// so a || b => a | | b
					// this is important because people may enter ...||... if they want to leave the field blank.
					// note: "|||".replaceAll("\\|\\|", "| |"); only gives us "| ||" not "| | |", so we iterative till we get rid of the consective "||"
					// stringtokenizer always skips over consecutive delimiters, so a || b is just 2 tokens, not 3
					while (line.contains("||"))
						line = line.replaceAll("\\|\\|", "| |"); // | is a regex special char, so need to escape it by providing a \

					// what if fieldsep is at the beginning of the line... nonsense, there is no answer then.
					StringTokenizer st = new StringTokenizer(line, Character.toString(FIELD_SEPARATOR));
					int nTokens = st.countTokens();
					answer = st.nextToken();
					if (nTokens > 1)
						clueText = st.nextToken();
					if (nTokens > 2)
						clueHint = st.nextToken().trim();
					if (nTokens > 3)
						refURL = st.nextToken().trim();
				}
				else
				{
					// just use space tokenization. 
					List<String> tokens = Util.tokenize(line);
					if (tokens.size() == 0)
						continue;

					//answer is the first token, but overruled by the first hashtag if there is one
					answer = tokens.get(0);
					for (String t: tokens)
						if (t.startsWith("#") && t.length() >= 2)
						{
							answer = t.substring(1);
							break;
						}

					answer = answer.toLowerCase();

					if (tokens.size() == 1) // generate a scrambled answer...
						clueText = Anagrams.bestAnagram(answer.toUpperCase(), r).toUpperCase();
					else
						clueText = line; // the answer in the cluetext will be blanked out later
				}

				// ok, now we have answer and cluetext
				answer = answer.trim().toLowerCase();
				if (Util.nullOrEmpty(answer))
					continue;

				if (clueText != null)
					clueText = clueText.trim();

				// _, # not allowed as part of the real sentence
				answer = answer.replace("\\.", ""); // remove any dot's, e.g. t.j.purtell
				answer = answer.replace("_", " ");
				if (answer.length() <= 1)
					continue;

				// we may have any of these urls in the clue text
				String audioURL = null, picURL = null, fullPicURL = null;

				// extract audio clues if present
				if (clueText.endsWith(".mp3") || clueText.endsWith(".ogg") || clueText.endsWith(".m4a") || clueText.endsWith(".wav") || clueText.endsWith(".wma")) 
				{
					// currently accept audio urls only at the end, clue may also have associated text, e.g. "identify the artist"
					int audioURLStartIdx = clueText.lastIndexOf(" ");
					if (audioURLStartIdx < 0)
						audioURLStartIdx = -1;
					audioURL = clueText.substring(audioURLStartIdx+1);
					if (audioURLStartIdx >= 0)
						clueText = clueText.substring(0, audioURLStartIdx);
					else
						clueText = "";
				}

				// look for fb pic clues in the form <tn url> <fullpic url>
				if (clueText.startsWith("http://graph.facebook.com") && clueText.contains("/picture")) 
				{
					StringTokenizer st = new StringTokenizer(clueText);
					int tokens = st.countTokens();
					picURL = st.nextToken();
					if (tokens > 1)
						fullPicURL = st.nextToken();
					if (tokens > 2)
						refURL = st.nextToken();
					clueText = ""; // no clue text allowed if pic as it affects layout
				}

				Pair<String, List<String>> p = extractURLs(clueText);
				clueText = p.getFirst();
				List<String> clueUrls = p.getSecond();

				clueText = clueText.replace("#", " "); // remove any hashtags that were inserted only to indicate the answer

				Clue c = fixedClues.get(answer);
				if (c == null)
				{
					if (Util.nullOrEmpty(clueHint))
						clueHint = null; // explicitly forcing cluehint to null if its empty
					c = new Clue(clueText, clueHint);
				}
				else
					if (!Util.nullOrEmpty(clueText)) // already had some text? add on to it;
						c.clue += " or " + clueText;

				if (!Util.nullOrEmpty(audioURL))
					c.setAudioURL(audioURL);
				if (!Util.nullOrEmpty(picURL))
					c.setPicURL(picURL);
				if (!Util.nullOrEmpty(fullPicURL))
					c.setFullPicURL(fullPicURL);
				if (!Util.nullOrEmpty(clueUrls))
					c.setURLs(clueUrls);
				if (!Util.nullOrEmpty(refURL))
					c.setUrl(refURL);

				// no matter what, do not allow answer to be seen in the clue!
				if (!Util.nullOrEmpty(c.clue))
					c.clue = Util.blankout(c.clue, answer);

				fixedClues.put(answer, c);
			} catch (Exception e) {
				log.warn ("Error parsing input line: " + line);
			}
		}
	}

	private static Set<String> parseRawText(Map<String, String> params, String inputText, Map<String, Integer> map, Archive archive) throws IOException, ClassNotFoundException 
	{
		Set<String> filteredIds;
		List<edu.stanford.muse.index.Document> docsToIndex = new ArrayList<edu.stanford.muse.index.Document>();

		InternetAddress[] ias = new InternetAddress[0];
		EmailDocument dummyDoc = new EmailDocument("dummy", "dummy", ias, ias, ias, ias, "dummy", "dummy", new Date());

		docsToIndex.add(dummyDoc);
		archive.addDoc(dummyDoc, inputText);
		archive.close();
		archive.openForRead();
	
		// now get the entities, either directly supplied or through NER
		// could further boost based on 
		String entities = params.get("entities");
		List<String> entityList = Util.tokenize(entities);
		
		// reorder entitylist so all everything starting with upper case is ordered before everything starting with lower case
		List<String> caps = new ArrayList<String>(), lowers = new ArrayList<String>();
		
		for (String e: entityList)
			if (e.length() > 0 && Character.isUpperCase(e.charAt(0)))
				caps.add(e);
		for (String e: entityList)
			if (e.length() > 0 && Character.isLowerCase(e.charAt(0)))
				lowers.add(e);
		
		entityList.clear();
		entityList.addAll(caps);
		entityList.addAll(lowers);
		
		// format is space separated, with multi word entities converted to single word using / /_/g
		// give weights in the map such that earlier words are preferred
		{
			int count = entityList.size() + 5;
			outer:
			for (String entity: entityList)
			{ 
				entity = entity.replaceAll("_", " "); // input has blanks converted to
				if (entity.startsWith("a "))
					continue;
				if (Util.allUppercase(entity) && inputText.indexOf("(" + entity + ")") >= 0)
					continue; // weed out terms from sentences like: ... New york city (NYC) ... because that's just an expository abbrev. tends to be an easy clue
				for (char c: entity.toCharArray())
					if (!Character.isLetter(c) && !Character.isWhitespace(c))
						continue outer;
				entity = entity.toLowerCase();

				Integer I = map.get(entity);
				int newScore = 0;
				if (I == null)
					newScore = 0;
				else 
					newScore = I;
				newScore += (count--);
				map.put (entity, newScore);
			}
		}
			
		// boost terms that are also recog. by NER
		List<Pair<String, Float>> list1 = NER.namesFromText(inputText);
		int count = list1.size()+2;
		for (Pair<String, Float> p: list1)
		{
			String name = p.getFirst();
			if (Util.allUppercase(name) && inputText.indexOf("(" + name + ")") >= 0)
				continue; // weed out terms from sentences like: ... New york city (NYC) ... because that's just an expository abbrev. tends to be an easy clue

			name = name.toLowerCase();
			Integer I = map.get(name);
			int newScore = 0;
			if (I == null)
				newScore = 0;
			else 
				newScore = I;

			newScore += (count--);
			map.put(name, newScore);
		}

		filteredIds = new LinkedHashSet<String>();
		filteredIds.add(dummyDoc.getUniqueId());
		return filteredIds;
	}

	private static final String saveDir = System.getProperty("user.home") + File.separator + ".muse";
	private static final String suffix = ".xword.json";
	public static Crossword load(String set, String name)
	{
		try {
			new File(saveDir).mkdirs();
			String file;
			if (Util.nullOrEmpty(set))
				file = saveDir + File.separator + name + suffix;
			else
				file = saveDir + File.separator + set + File.separator + name + suffix;
			List<String> lines = Util.getLinesFromFile(file, false);
			String json = Util.join(lines,  " ");
			Crossword c = (Crossword) new Gson().fromJson(json, Crossword.class);
			return c;
		} catch (Exception e) { Util.print_exception(e); return null; }
	}
	
	/** saves save_json if not empty, otherwise serializes c */
	public static String save(String set, Crossword c, String save_json)
	{
		String dir = saveDir;
		if (!Util.nullOrEmpty(set))
			dir = saveDir + File.separator + set;
		
		try {
			new File(dir).mkdirs();
			if (Util.nullOrEmpty(save_json))
			{
				if (c == null)
					return null;

				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				save_json = gson.toJson(c);
			}
			
			String name = String.format ("%08x", r.nextInt());
			
			PrintWriter pw = new PrintWriter (new OutputStreamWriter(new FileOutputStream(dir + File.separator + name + suffix, false), "utf-8"));
			pw.println(save_json);
			pw.close();
			return name;
		} catch (Exception e) { Util.print_exception(e); return null; }
	}

	public static byte[] saveImage(Crossword c, String id) { return saveImage(c, id, true, true); }

	public static byte[] saveImage(Crossword c, String id, boolean printAnswers, boolean printClues)
	{		
		CrosswordPainter cp = new CrosswordPainter(c, printAnswers, printClues);

		BufferedImage b = new BufferedImage(cp.width(), cp.height(), BufferedImage.TYPE_INT_ARGB);
		Graphics2D g1 = b.createGraphics();
		
		// thanks stackoverflow, without these hints, the text looks horrible!
		// http://stackoverflow.com/questions/7992281/java2d-swing-rendering-a-component-with-text-anti-aliasing-to-a-bufferedimage
		g1.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g1.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
		g1.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g1.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
		
		cp.print(g1);

		String baseDir = System.getProperty("user.home") + java.io.File.separator + ".muse";
		String filename = baseDir + java.io.File.separator + id + ".xword.png";
		try { 
			ImageIO.write (b, "png", new File(filename));
			return Util.getBytesFromFile(filename);
		} catch (Exception e) { Util.print_exception(e, log); }		
		return null;
	}
	
	public static class CrosswordPainter extends Component {		
		public static final long serialVersionUID = 1L;

		private static final int BOX_SIZE = 30, LETTER_SIZE = 20, CLUENUM_SIZE = 10;
		public static final int MARGIN_X = 40, MARGIN_Y = 40, CLUE_COL_MARGIN = 50, PIC_MARGIN_X = 25, PIC_MARGIN_Y = 25;
		private static final int PIC_SIZE = 80;
		private static final int COL_TITLE_HT = 50;

		private static final Font letterFont = new Font("Courier", Font.PLAIN, LETTER_SIZE);
		private static final Font clueNumFont = new Font("Courier", Font.PLAIN, CLUENUM_SIZE);
		private static final Font titleFont = new Font("Arial", Font.ITALIC, 20);
		private static final Font clueColHeaderFont = new Font("Arial", Font.BOLD, 12);
		private static final Font creditFont = new Font("Helvetica", Font.PLAIN, 12);
		private static final Color creditColor = Color.GRAY;
		private static final Font clueFont = new Font("Helvetica", Font.PLAIN, 16);
		private static final Color letterColor = new Color(0x41, 0x69, 0xE1);
		private static final Color titleColor = new Color(0, 0, 0);
		
		private static final Color clueNumColor = Color.BLACK;
		private static final Color emptyColor = new Color(0x11, 0x11, 0x11);
		private static final Color stopColor = new Color(0x44, 0x44, 0x44);

		Crossword c;
		boolean printAnswers, printClues;
		private int CLUE_COL_WIDTH = 300;

		public CrosswordPainter(Crossword c, boolean printAnswers, boolean printClues) 
		{ 
			this.c = c; 
			this.printAnswers = printAnswers; 
			this.printClues = printClues;
			
			// currently we only know how to print pic clues
			if (printClues)
			{
				for (Word W: c.placedWords)
					if (Util.nullOrEmpty(W.getClue().getPicURL()))
					{
						this.printClues = false;
						break;
					}
			}
			if (!printClues) CLUE_COL_WIDTH = 0;
		}

		private int gridWidth() { return + c.w * BOX_SIZE; }
		private int gridHeight() { return + c.h * BOX_SIZE; }
		
		public int width() {
			return 2 * CrosswordPainter.MARGIN_X + gridWidth() + 10 + (printClues ? 2*(CLUE_COL_MARGIN + CLUE_COL_WIDTH):0);
		} 
		
		public int height() { 
			return 2 * CrosswordPainter.MARGIN_Y + Math.max(gridHeight() + 10, maxClueColHeight());
		}
		
	
		public Dimension getPreferredSize() {
			return new Dimension(MARGIN_X + c.w * BOX_SIZE+10 + CLUE_COL_WIDTH * 2, MARGIN_Y + c.h * BOX_SIZE+10);
		}
		  
		private void drawHeader(Graphics g, int x, int y)
		{
			int TOTAL_X = c.w * BOX_SIZE + MARGIN_X * 2 + CLUE_COL_WIDTH * 2;
			FontMetrics fm = g.getFontMetrics();
			int titleWidth = fm.stringWidth(c.title);
			g.setFont(titleFont);
			g.setColor(titleColor); 
			int titleX = (TOTAL_X - titleWidth)/2;
			if (titleX + titleWidth > TOTAL_X - 100) // overruns, left align instead of center align
				titleX = 10;
	
			titleX = MARGIN_X; // fixing for now
	        g.drawString(c.title, titleX, MARGIN_Y -5);
	        
	    	// print credit only if printing clues, otherwise we typically don't have enough width if its just the grid 
	        if (printClues)
	        {
		    	g.setFont(creditFont);
				g.setColor(creditColor); 
		    	g.setFont(creditFont);

		        g.drawString("HTTP://BIT.LY/FBPUZZLE", width()-200, MARGIN_Y - 10); // fixed offset from right
	        }
			
	//		g.setFont(creditFont);
	//        g.drawString("By Muse", (TOTAL_X - 80), OFFSET_Y-10);
	        
			g.setColor(new Color (0, 0, 0, 0.4f));
			g.drawLine(MARGIN_X, MARGIN_Y,  MARGIN_X + c.w * BOX_SIZE + (printClues? 2*(CLUE_COL_WIDTH+CLUE_COL_MARGIN):0),  MARGIN_Y);
		}
		
		@Override
		public void paint(Graphics g) {
			Graphics2D g2 = (Graphics2D) g;
			Dimension size = getSize();
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, width(), height());
			
			System.out.println(size);
			int M = 1;

			drawHeader(g, 0, 0);
			
			//draw grid
			g.setColor(new Color (0, 0, 0, 0.2f));
			g2.setStroke(new BasicStroke(1));
			int startX = MARGIN_X, startY = MARGIN_Y + COL_TITLE_HT; // so we align horiz to the clue start
			
			for (int x = 0; x < c.w+1; x++)
				g.drawLine(startX + x * BOX_SIZE, startY + 0,  startX + x * BOX_SIZE,  startY + c.h * BOX_SIZE);
			for (int y = 0; y < c.h+1; y++)
				g.drawLine(startX + 0, startY + y * BOX_SIZE, startX + c.w * BOX_SIZE,  startY + y * BOX_SIZE);
			g2.setStroke(new BasicStroke(0));

			// draw boxes
			for (int x = 0; x < c.w; x++)
				for (int y = 0; y < c.h; y++)
				{
					Color boxBGColor;
					if (c.box[x][y] == Crossword.EMPTY)
						boxBGColor = emptyColor;
					else if (c.box[x][y] == Crossword.STOP)
						boxBGColor = stopColor;
					else
						boxBGColor = Color.WHITE;
					g.setColor(boxBGColor);
					g.fillRect(startX + x * BOX_SIZE + M, startY + y * BOX_SIZE + M, BOX_SIZE - M, BOX_SIZE - M);
					
					// fill in letter and clue num
					if (printAnswers && !Crossword.stopOrEmpty(c.box[x][y])) 
					{
						g.setFont(letterFont);
						g.setColor(letterColor); 
				        g.drawString(Character.toString(Character.toUpperCase(c.box[x][y])), startX + x * BOX_SIZE + (BOX_SIZE-LETTER_SIZE),  startY + (y+1) * BOX_SIZE - (BOX_SIZE-LETTER_SIZE)/2);
					}
					
			        if (c.clueNums[x][y] > 0)
			        {
			        	g.setFont(clueNumFont);
						g.setColor(clueNumColor); 
				        g.drawString(Integer.toString(c.clueNums[x][y]), startX + x * BOX_SIZE + 1,  startY + (y) * BOX_SIZE + CLUENUM_SIZE);
			        }
				}
			
			if (!printClues)
				return;

//        	g.setFont(clueFont);
//			g.drawString("ABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABCABC\nDEF", c.w * BOX_SIZE + OFFSET_X * 2, 100);
			drawClueCol(c, g2, true, CrosswordPainter.MARGIN_X + gridWidth() + CLUE_COL_MARGIN, CrosswordPainter.MARGIN_Y);
			drawClueCol(c, g2, false, CrosswordPainter.MARGIN_X + gridWidth() + 2*CLUE_COL_MARGIN + CLUE_COL_WIDTH, CrosswordPainter.MARGIN_Y);
		}
		
		/** return height of the taller clue col (down or across) */
		private int maxClueColHeight()
		{
			if (!printClues)
				return 0;
			
			// find which one has more clues, down or across
			int acrossCount = 0, downCount = 0;
			for (Word W: c.placedWords)
				if (W.acrossNotDown)
					acrossCount++;
				else
					downCount++;
			int maxCount = Math.max(acrossCount, downCount);
			
			// how many rows will these # of clues need?
			int maxRows = maxCount/3;
			if (maxCount % 3 != 0)
				maxRows++;
			return (maxRows) * (PIC_SIZE+PIC_MARGIN_Y);
		}
		
		private static void drawClueCol (Crossword c, Graphics2D g2, boolean acrossNotDown, int colX, int colY)
		{
			int count = 0;
			String title = acrossNotDown ? "ACROSS" : "DOWN";
			g2.setFont(clueColHeaderFont);
			g2.drawString (title, colX, colY + COL_TITLE_HT-20);
			
			g2.setFont(clueNumFont);

			colY += COL_TITLE_HT;
			for (Word W: c.placedWords)
			{
				if (W.acrossNotDown != acrossNotDown)
					continue;

				BufferedImage img = null;
				try {
					img = ImageIO.read(new URL(W.getClue().getPicURL()));
				} catch (Exception e) {
					continue;
				}
	
				int x = colX + (count %3) * (PIC_SIZE + PIC_MARGIN_X);
				int y = colY + (count/3) * (PIC_SIZE + PIC_MARGIN_Y);
				g2.drawString (Integer.toString(W.getClueNum()), x - CLUENUM_SIZE - (W.getClueNum() >= 10 ? (CLUENUM_SIZE-4):0), y + PIC_SIZE);
				g2.drawImage(img, x, y, PIC_SIZE, PIC_SIZE, null);
				count++;
			}
		}

	}
	
	/** returns an array of puzzles */
	public static String oldUpdatesSince(String set, long time)
	{
		List<Crossword> result = new ArrayList<Crossword>();
		
		if (saveDir == null)
			return result.toString();

		String dir = saveDir;
		
		if (!Util.nullOrEmpty(set))
			dir = dir + File.separator + set;
		
		if (!new File(dir).exists())
			return result.toString();

		File files[] = new File(dir).listFiles(new MyFilenameFilter(null, suffix));
		if (files != null)
			for (File f: files)
			{
				if (f.lastModified() <= time)
					continue;
				String name = f.getAbsolutePath();
				try {
					String json = Util.readFile(name);
					Crossword c = (Crossword) new Gson().fromJson(json, Crossword.class);
					result.add(c);
				} catch (Exception e) {
					log.warn ("Bad! exception reading " + name);
				}
			}
		String resultStr = new Gson().toJson(result);
		log.info("pushing updates: " + result.size() + " since: " + time + " result length: " + resultStr.length() + " chars");
		return resultStr;
	}
	
	/** returns an object indicate app time and updated puzzles */
	public static String updatesSince(String set, long time, String app, long appTime)
	{
		String xwords = oldUpdatesSince(set, time);
		
		if (saveDir == null)
			return "";

		String updateJson = "";
		try {
			List<String> updateTimes = Util.getLinesFromFile(saveDir + File.separator + "appTimes", true);
			for (String updateTime : updateTimes) 
			{
				StringTokenizer st = new StringTokenizer(updateTime); // first token is app name, second is time
				if (st.countTokens() < 2)
					continue;
				if (st.nextToken().equalsIgnoreCase(app))
				{
					String modTimeStr = st.nextToken();
					long modTime = Long.MAX_VALUE;
					try { modTime = Long.parseLong(modTimeStr);	} catch (NumberFormatException e) { Util.print_exception("Error parsing app time str: " + appTime, e, log); continue; }
					updateJson = (modTime > appTime) ? "\"app_needs_update\":\"true\"" : "\"app_needs_update\":\"false\"";
				}
			}
		} catch (Exception e) { Util.print_exception ("Error in app times", e, log); }
		
		if (Util.nullOrEmpty(updateJson))
			return "{\"xwords\":" + xwords + "}";
		else
			return "{" + updateJson +", \"xwords\":" + xwords + "}";
	}
	
	public static<T> List<T> permuteList(List<T> in, int seed)
	{
		// create a copy of the input
		List<T> result = new ArrayList<T>();
		result.addAll(in);
		
		Random R = new Random(seed);
		for (int permuteSize = in.size(); permuteSize > 1; permuteSize--)
		{
			int pos = Math.abs(R.nextInt()) % permuteSize;
			// pos is in teh range 0..permuteSize-1
			// interchange elements permuteSize-1 and pos
			T tmp = result.get(permuteSize-1);
			result.set(permuteSize-1, result.get(pos));
			result.set (pos, tmp);			
		}
		return result;
	}
	
	public static void main(String args[]) throws Exception
	{
		/*
		List<String> names = Util.getLinesFromFile("/tmp/2", false);
		StringBuilder sb = new StringBuilder();
		for (String n: names)
			sb.append (n + ":X\n");
		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("table", sb.toString());
		Crossword c = createCrossword(params, null);
		System.out.println(c);
		*/
		/*
		String s = updatesSince(0L);
		System.out.println (s);
		s = updatesSince(new Date().getTime());
		System.out.println (s);
		*/
		/*
		List<String> list = Util.getLinesFromReader(new FileReader("/tmp/eagles"), true);
		Random r = new Random();
		for (int i = 0; i < 1000; i++)
		{
			int seed = r.nextInt();
			
			List<String> tmpList = Util.permuteList(list, seed);
			Map<String, String> params = new LinkedHashMap<String, String>();
			String inputTable = Util.join(tmpList,  "\n");
			params.put("table", inputTable);
			params.put("w",  "15");
			params.put("h",  "15");
			
			Crossword c = createCrossword(params, null);
			System.out.println ("-------------------\n-------------------\n");
			System.out.println ("seed " + seed + " input: " + inputTable);
			System.out.println ("seed " + seed + " final stats: " + c.stats());
		}
		*/
//		Crossword c = load(null, "2c376d7e");
//		saveImage(c, "abc", true, true);
		
		System.out.println (updatesSince("ragas", 0L, "pmg", 12041241));
	}
}
