package edu.stanford.muse.email;

public class FetchConfig {
	public boolean downloadMessages;
	public boolean downloadAttachments;
	public Filter filter;
	
	public String toString()
	{
		return "downloadMessages: " + downloadMessages + " downloadAttachments: " + downloadAttachments + " filter: " + filter;
	}
}