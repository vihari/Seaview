package edu.stanford.muse.xword;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import edu.stanford.muse.util.Util;

public class CrosswordThread extends Thread {
    public static Log log = LogFactory.getLog(Crossword.class);

	CrosswordManager cm;
	int level;
	HttpSession session;
	
	public CrosswordThread(HttpSession session, CrosswordManager cm, int level) {
		// TODO Auto-generated constructor stub
		this.session = session;
		this.cm = cm;
		this.level = level;
	}
	
	public void run()
	{
		log.info ("Starting crossword read ahead thread");
		synchronized(cm) {
			try {
				cm.setupDocsForLevel(session, level);
			} catch (Exception ce) {
				Util.print_exception(ce);
			}
		}
		log.info ("Finished crossword read ahead thread");

	}
}
