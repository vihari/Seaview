package edu.stanford.muse.xword;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;

import edu.stanford.muse.email.CalendarUtil;
import edu.stanford.muse.email.FetchConfig;
import edu.stanford.muse.email.Filter;
import edu.stanford.muse.email.MuseEmailFetcher;
import edu.stanford.muse.exceptions.CancelledException;
import edu.stanford.muse.exceptions.NoDefaultFolderException;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.DatedDocument;
import edu.stanford.muse.util.Util;
import edu.stanford.muse.webapp.SimpleSessions;

public class CrosswordManager implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
    public static Log log = LogFactory.getLog(CrosswordManager.class);

	public static int MIN_MESSAGES_PER_LEVEL = 250;
	Filter filter;
	
	transient MuseEmailFetcher fetcher;
	Date earliestFetched; // content from this date onwards is already in archive
	public Archive archive;
	private boolean exhausted = false;
	private int currentLevel = 0;
	private String searchTerms;
	
	class LevelInfo implements java.io.Serializable {
		private static final long serialVersionUID = 1L;
		Date startDate, endDate;
		int nMessages;
		public LevelInfo(Date sd, Date ed, int nMessages)
		{
			this.startDate = sd;
			this.endDate = ed;
			this.nMessages = nMessages;
		}

		public String toString() 
		{
			return Util.pluralize(nMessages, "sent message") + " from " + CalendarUtil.formatDateForDisplay(startDate) + " to " + CalendarUtil.formatDateForDisplay(endDate);
		}
	}
	
	List<LevelInfo> levels = new ArrayList<LevelInfo>();
	
	public CrosswordManager (Archive archive, MuseEmailFetcher mef, String searchTerms)
	{
		this.archive = archive;
		this.fetcher = mef;
		this.searchTerms = searchTerms;
	}
	
	public boolean isExhausted() { return exhausted; }
	
	public boolean canSupportLevel(int level) { 
		if (exhausted && level >= levels.size())
			return false;
		return true;
	}

	public void setupDocsForNextLevel(HttpSession session) throws UnsupportedEncodingException, MessagingException, InterruptedException, IOException, JSONException, NoDefaultFolderException, CancelledException
	{
		setupDocsForLevel(session, levels.size());
	}
	
	public int nLevels() { return levels.size(); }
	public int getCurrentLevel()	{ return currentLevel; }
	private int totalMessagesInAllLevels() {
		int n = 0;
		for (LevelInfo level: levels)
			n += level.nMessages;
		return n;
	}
	
	public String getCurrentLevelDescription()
	{
		if (currentLevel >= levels.size())
			return "No level " + currentLevel;
		
		LevelInfo li = levels.get(currentLevel);
		return li.toString();
	}
	
	public void setLevel(HttpSession session, int level)
	{
		currentLevel = level;
		LevelInfo li = levels.get(level);
		log.info("setting level to: " + li);

		Collection<DatedDocument> messagesInThisWindow = archive.docsInDateRange(li.startDate, li.endDate);
		
		if (!Util.nullOrEmpty(messagesInThisWindow))
			session.setAttribute("emailDocs",  messagesInThisWindow);
	}
	
	public CrosswordManager(Archive archive) throws UnsupportedEncodingException, MessagingException, InterruptedException, IOException, JSONException, NoDefaultFolderException, CancelledException
	{
		// level better be = levelDates.size
		int level = 0;
		Date currentEnd, currentStart;
		Collection<DatedDocument> messagesInThisWindow;
		
		while (true)
		{
			if (level == 0)
			{
				currentEnd = new Date();
				currentStart = CalendarUtil.quarterBeginning(currentEnd);
			}
			else
			{
				LevelInfo lastLevel = levels.get(levels.size()-1);
				currentStart = lastLevel.startDate;
				currentEnd = new Date(currentStart.getTime()-1L);
				currentStart = CalendarUtil.quarterBeginning(currentEnd);
			}
	
			// go back quarter by quarter
			while (true)
			{
				messagesInThisWindow = archive.docsInDateRange(currentStart, currentEnd);
				if (messagesInThisWindow.size() >= MIN_MESSAGES_PER_LEVEL)
					break;
				// bummer... not enough messages, go back another quarter
				currentStart = CalendarUtil.quarterBeginning(new Date(currentStart.getTime()-1L));
			}
			levels.add(new LevelInfo(currentStart, currentEnd, messagesInThisWindow.size()));
		}
	}
	
	/** returns error message if any */
	public void setupDocsForLevel(HttpSession session, int level) throws UnsupportedEncodingException, MessagingException, InterruptedException, IOException, JSONException, NoDefaultFolderException, CancelledException
	{
		Collection<DatedDocument> messagesInThisWindow = null;

		log.info("Setting up docs for xword level " + level);
		
		// can only ask for the next level
		if (level > levels.size()) 
		{
			log.warn ("Can't ask for level " + level + " levels.size = " + levels.size());
			return;
		}
		
		if (level < levels.size())
		{
			// we already have the level
//			currentStart = levels.get(level).startDate;
//			currentEnd = levels.get(level).endDate;
		}
		else 
		{
			// level better be = levelDates.size
			int MAX_QUARTERS_TO_GO_BACK = 40;
			Date levelEnd; // end date for this level
			if (level == 0)
				levelEnd = new Date();
			else
			{
				LevelInfo lastLevel = levels.get(levels.size()-1);
				levelEnd = new Date(lastLevel.startDate.getTime()-1L);
			}
			
			Date currentStart = CalendarUtil.quarterBeginning(levelEnd);
			Date currentEnd = levelEnd;
			for (int nQuarters = 0; nQuarters < MAX_QUARTERS_TO_GO_BACK; nQuarters++)
			{
				// go back quarter by quarter... [currentStart..currentEnd] sets the range for the current fetch op
				// [currentStart..levelEnd] will set the range for the entire level
				if (earliestFetched == null || currentStart.before(earliestFetched))
				{
					int messageCount = totalMessagesInAllLevels();
					if (level == 0 || messageCount < fetcher.totalMessagesInSelectedFolders()) // if level = 0, first time, always go in cos fetcher.totalMessagesInSelectedFolders() isn't correctly set up yet (fetcher doesn't know its folders)
					{
						Filter filter = new Filter(true /* sentOnly */, currentStart, currentEnd, this.searchTerms);
						FetchConfig fc = new FetchConfig();
						fc.filter = filter;
						fc.downloadMessages = true;
						fc.downloadAttachments = false;
						fetcher.fetchAndIndexEmails(archive, null, true, fc, session);
						earliestFetched = currentStart;
					}
					else
					{
						log.info ("No more messages, all fetched: " + messageCount);
						break;
					}
				}
				messagesInThisWindow = archive.docsInDateRange(currentStart, levelEnd);
				if (messagesInThisWindow.size() >= MIN_MESSAGES_PER_LEVEL)
					break;
				currentEnd = currentStart;
				currentStart = CalendarUtil.quarterBeginning(new Date(currentStart.getTime()-1L));
			}
			levels.add(new LevelInfo(currentStart, levelEnd, messagesInThisWindow.size()));
			archive.postProcess();
			SimpleSessions.saveArchive(session);
			
			level = levels.size()-1;
			archive.openForRead();
			if (messagesInThisWindow.size() < MIN_MESSAGES_PER_LEVEL)
				exhausted = true;
		}
		
		setLevel(session, level);		
	}
}
