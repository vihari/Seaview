package edu.stanford.muse.xword;

/** tiny nested class to hold info about places that a word can be placed */
public class PlaceInfo implements Comparable<PlaceInfo> { 
	int x, y; boolean acrossNotDown; int nIntersects;
	String word;
	public PlaceInfo(String word, int x, int y, boolean acrossNotDown, int nIntersects) {
		this.word = word; this.x = x; this.y = y; this.acrossNotDown = acrossNotDown; this.nIntersects = nIntersects; 
	}
	public int hashcode() { return x ^ y ^ (acrossNotDown ? 1:0)^ nIntersects;}
	public boolean equals(Object o)
	{
		if (!(o instanceof PlaceInfo))
			return false;
		PlaceInfo pi = (PlaceInfo) o;
		return pi.word.equals(this.word) && pi.x == this.x && pi.y == this.y && pi.acrossNotDown == this.acrossNotDown; //  && pi.nIntersects == this.nIntersects;
	}
	
	// note; compareTo not consistent with equals
	public int compareTo(PlaceInfo pi)
	{
		// more interesects preferred.
		// lower end X preferred
		// lower end Y preferred 
		
		// if this has more intersects than pi, this should come before pi, pi.nIntersects - this.nIntersects will return a -ve number
		if (pi.nIntersects != this.nIntersects)
			return pi.nIntersects - this.nIntersects;
		int thisEndX = this.x + (this.acrossNotDown ? 1:0) * this.word.length();
		int thisEndY = this.y + (this.acrossNotDown ? 0:1) * this.word.length();
		
		int otherEndX = pi.x + (pi.acrossNotDown ? 1:0) * pi.word.length();
		int otherEndY = pi.y + (pi.acrossNotDown ? 0:1) * pi.word.length();
		
		// if this' end is before pi's, this should come before pi, thisEndX - otherEndX will return a -ve number
		if (otherEndX != thisEndX)
			return thisEndX - otherEndX;
		if (otherEndY != thisEndY)
			return thisEndY - otherEndY;
		return 0;
	}
	
	public String toString() { return word + "@" + x + "," + y + (acrossNotDown ? " across" : " down") + " xing:" + nIntersects; }
}