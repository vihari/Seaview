/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package edu.stanford.muse.xword;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.store.LockObtainFailedException;

import edu.stanford.muse.exceptions.ReadContentsException;
import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.Util;

public class BacktrackingPlacer extends Placer {
	private static Log log = LogFactory.getLog(BacktrackingPlacer.class);

	private int wordCount[][]; // # of words the square is involved in. also counted for stops! stop count for a box can be as high as 4! also update when word is committed and uncommitted
	private int wordsCommitted;
	private long startTime;

	GridQuality bestGrid;
	/** simple class to keep track of grid quality */
	class GridQuality implements Comparable<GridQuality> { 
		int maxX, maxY; // max x(y) idx of any placed letter
		private List<Word> placedWords;
		GridQuality(List<Word> bestPlacedWords)
		{
			this.placedWords = new ArrayList<Word>(bestPlacedWords);
			
			// compute maxX, maxY
			maxX = 0; maxY = 0;
			for (Word W: bestPlacedWords)
			{
				int thisWordEndX = W.x + (W.acrossNotDown ? W.word.length()-1 : 0);
				int thisWordEndY = W.y + (W.acrossNotDown ? 0 : W.word.length()-1);
				maxX = Math.max(maxX, thisWordEndX);
				maxY = Math.max(maxY, thisWordEndY);
			}
		}
		
		/** returns > 0 if gq is better than this in terms of quality */
		public int compareTo(GridQuality gq) {
			// compute balance between x and y... lower balance is better
			if (this.maxX <= gq.maxX && this.maxY <= gq.maxY)
				return -1; // this is clearly better
			if (gq.maxX <= this.maxX && gq.maxY <= this.maxY)
				return 1; // gq is clearly better 
			
			// look at the aspect ratio of this vs gq
			int thisBalance = Math.abs(this.maxX - this.maxY);
			int gqBalance = Math.abs(this.maxY - gq.maxY);
			return thisBalance - gqBalance;
		}
	}
	
	private int MIN_WORD_COMMITS = 100000; // to ensure that we don't fail for really small inputs
	private int MAX_OPTIONS_PER_LEVEL = 2;
	int MAX_PER_WORD_OPTIONS = 10000;
	int MAX_TOTAL_OPTIONS = 10000000;

	private boolean timedOut;
	private int timeoutMillis;
	
	public BacktrackingPlacer(Crossword c, int timeoutMillis) 
	{ 
		super(c);
		this.timeoutMillis = timeoutMillis;
		reset();
	}

	private void reset() 
	{
		wordCount = new int[c.w][c.h];
		wordsCommitted = 0;
	}
	
	/** checks if word can be placed at x, y, and returns the # of intersects */
	private Pair<Boolean, Integer> isLegalAndIntersects(String word, int x, int y, boolean acrossNotDown)
	{
		if (!isLegalSquare(x, y))
			return new Pair<Boolean, Integer>(false, 0);
		
		if (c.box[x][y] == Crossword.STOP)
			return new Pair<Boolean, Integer>(false, 0);
		if (!willWordFitOnGrid(word, x, y, acrossNotDown))
			return new Pair<Boolean, Integer>(false, 0);
	
		int incrX = acrossNotDown ? 1 : 0;
		int incrY = acrossNotDown ? 0 : 1;
		int ix = x, iy = y;
		
		int sqBeforeX = ix-incrX, sqBeforeY = iy-incrY;
		if (isLegalSquare(sqBeforeX, sqBeforeY) && this.c.box[sqBeforeX][sqBeforeY] != Crossword.EMPTY && this.c.box[sqBeforeX][sqBeforeY] != Crossword.STOP)
			return new Pair<Boolean, Integer>(false, 0);
		
		int intersects = 0; // #intersects with existing chars
		for (int i = 0; i < word.length(); i++)
		{
			char c = word.charAt(i);
			// bail out if its not empty and not the same as the existing char
			if (this.c.box[ix][iy] != Crossword.EMPTY && this.c.box[ix][iy] != c)
				return new Pair<Boolean, Integer>(false, 0);

			if (this.c.box[ix][iy] == c && wordCount[ix][iy] > 0)
			{
//				meetsAnyNonIntersectingWord |= isSolitaryWord(ix, iy, c, !acrossNotDown); // || because it might be meeting more than one word
				intersects++;
			}
			else
			{
				// if its empty, check whether neighboring squares in orthogonal direction are also empty
				if (!neighboringSquaresEmpty(ix, iy, c, !acrossNotDown))
					return new Pair<Boolean, Integer>(false, 0);
			}
			ix += incrX;
			iy += incrY;
		}		
		
		// check if the sq after (where ix, iy are pointing now) is free ... it shouldn't be a letter
		if (isLegalSquare(ix, iy) && this.c.box[ix][iy] != Crossword.EMPTY && this.c.box[ix][iy] != Crossword.STOP)
			return new Pair<Boolean, Integer>(false, 0);

		return new Pair<Boolean, Integer>(true, intersects);
	}

	/** make a copy of the placed words if this is the best grid we've seen. currently, "best grid" is defined simply as the one with the most # words.
	 * but we may have other criteria in the future */
	int bestGridUpdates = 0;
	private boolean updateBestGridSoFar()
	{
		// check if we currently have more than the # of words placed than in bestGrid
		if (bestGrid == null)
		{
			bestGrid = new GridQuality(c.placedWords);
			bestGridUpdates++;		
			return true;
		}
		
		if (bestGrid.placedWords.size() < c.placedWords.size())
		{
			bestGrid = new GridQuality(c.placedWords);
			bestGridUpdates++;				
			return true;
		}
		
		if (bestGrid.placedWords.size() == c.placedWords.size()) 
		{
			// same # of placed words. check other metrics using compareTo()
			GridQuality newGrid = new GridQuality(c.placedWords);
			if (bestGrid.compareTo(newGrid) > 0)
			{
				bestGrid = newGrid;
				bestGridUpdates++;
				return true;
			}
		}
		return false;
	}
	
	@Override
	protected void commitWordToGrid(Word W)
	{
		super.commitWordToGrid(W);
		
		int ix = W.x, iy = W.y;
		boolean acrossNotDown = W.acrossNotDown;
		int incrX = acrossNotDown ? 1 : 0;
		int incrY = acrossNotDown ? 0 : 1;
		int sqBeforeX = ix-incrX;
		int sqBeforeY = iy-incrY;
		String word = W.word;
		for (int i = 0; i < word.length(); i++) 
		{
			wordCount[ix][iy]++;
			ix += incrX;
			iy += incrY;
		}
		int sqAfterX = ix, sqAfterY = iy;
		
		// super.commitWordToGrid(W) will insert stops before and after
		// we keep word counts for stops as well
		if (isLegalSquare(sqBeforeX, sqBeforeY))
			wordCount[sqBeforeX][sqBeforeY]++;
		if (isLegalSquare(sqAfterX, sqAfterY))
			wordCount[sqAfterX][sqAfterY]++;
		wordsCommitted++;
		if (wordsCommitted % 100 == 0)
			log.info (wordsCommitted + " words committed"); // just to indicate progress
	}
	
	private void uncommitWordToGrid(Word W)
	{
	//	log.info ("Uncommitting word: " + W);

		int ix = W.x, iy = W.y;
		boolean acrossNotDown = W.acrossNotDown;
		int incrX = acrossNotDown ? 1 : 0;
		int incrY = acrossNotDown ? 0 : 1;
		String word = W.word;
		
		int sqBeforeX = ix-incrX;
		int sqBeforeY = iy-incrY;

		c.markStop(ix-incrX, iy-incrY); // put a stop before this word 
		
		for (int i = 0; i < word.length(); i++) 
		{
			Util.ASSERT (c.box[ix][iy] == word.charAt(i));
			
			wordCount[ix][iy]--;
			if (wordCount[ix][iy] == 0)
				c.box[ix][iy] = Crossword.EMPTY;

			ix += incrX;
			iy += incrY;
		}

		// decrement stop counts due to this words
		
		int sqAfterX = ix, sqAfterY = iy;
		
		// super.commitWordToGrid(W) will insert stops before and after
		// we keep word counts for stops as well
		if (isLegalSquare(sqBeforeX, sqBeforeY))
		{
			wordCount[sqBeforeX][sqBeforeY]--;
			if (wordCount[sqBeforeX][sqBeforeY] == 0)
				c.box[sqBeforeX][sqBeforeY] = Crossword.EMPTY;
		}
		
		if (isLegalSquare(sqAfterX, sqAfterY)) {
			wordCount[sqAfterX][sqAfterY]--;
			if (wordCount[sqAfterX][sqAfterY] == 0)
				c.box[sqAfterX][sqAfterY] = Crossword.EMPTY;
		}
	//	log.info ("unplacing " +  W + " at (" + W.x + "," + W.y + ") " + (acrossNotDown ? "across":"down"));
	}
	
	/** generate legal options for placing words */
	private List<PlaceInfo> sweepGridToComputePlacementOptions()
	{
		List<PlaceInfo> result = new ArrayList<PlaceInfo>();
		
		// we'll generate up to 10 options per word, and up to 100 options total... more than this doesn't really make sense
		
		word_loop:
		for (String word: c.candidateWords)
		{
			int thisWordOptions = 0;
			boolean canBePlaced = false; // can be placed will be set to true if this word can be placed, regardless of intersections
			for (int x = 0; x < c.w; x++)
				for (int y = 0; y < c.h; y++)
				{
					
					// see if word can be placed at (x, y). must intersect, except for the first word
					boolean firstWord = c.placedWords.size() == 0;
					// check across direction
					Pair<Boolean, Integer> p = isLegalAndIntersects(word, x, y, true);
					// p = <is legal, # intersections>
					if (p.getFirst())
					{
						if (firstWord || p.getSecond() > 0)
						{
							result.add(new PlaceInfo(word, x, y, true, p.getSecond()));
							thisWordOptions++;
						}
						canBePlaced = true;
					}
					
					// check down direction
					Pair<Boolean, Integer> p1 = isLegalAndIntersects(word, x, y, false);
					if (p1.getFirst())
					{
						if (firstWord || p1.getSecond() > 0)
						{
							result.add(new PlaceInfo(word, x, y, false, p1.getSecond()));
							thisWordOptions++;
						}
						canBePlaced = true;
					}
					
					if (thisWordOptions >= MAX_PER_WORD_OPTIONS)
						continue word_loop;
					if (result.size() >= MAX_TOTAL_OPTIONS)
						break word_loop;
				}

			if (!canBePlaced)
			{
				// this word simply can't be placed on the grid (regardless of intersections), simply bail out, signaling no legal options left along this search path!
				result.clear();
				return result;
			}		
		}
	//	Collections.sort(result);
		return result;
	}
	
	/** computes new options (sorted by preference) given that placeInfos were the options before placing newlyPlaced */
	private List<PlaceInfo> updatedOptions(Collection<PlaceInfo> previousOptions, PlaceInfo newlyPlaced)
	{
		// any new option must be in currentOptions and still valid, OR
		// created newly by intersecting with the just placed word
		
		Set<PlaceInfo> set = new LinkedHashSet<PlaceInfo>();
		if (previousOptions != null)
			for (PlaceInfo pi: previousOptions)
			{
				if (pi.word.equals(newlyPlaced.word))
					continue; // we're not placing this word any more
				
				Pair<Boolean, Integer> p = isLegalAndIntersects(pi.word, pi.x, pi.y, pi.acrossNotDown);
				if (p.getFirst())
					set.add(new PlaceInfo(pi.word, pi.x, pi.y, pi.acrossNotDown, p.getSecond()));
			}

		// see if we can place any of the candidate words so it intersects the newly placed word
		// we are looking for placeinfo's orthogonal to intersectingPlacement
		int incrX = newlyPlaced.acrossNotDown ? 1 : 0;
		int incrY = newlyPlaced.acrossNotDown ? 0 : 1;
		int ix = newlyPlaced.x, iy = newlyPlaced.y;
		
		for (int i = 0; i < newlyPlaced.word.length(); i++)
		{
			for (String word: c.candidateWords)
			{
				if (word.equals(newlyPlaced.word))
					continue; // shouldn't happen, but safe to do it in case newlyPlaced word has not been removed from the candidates list
				
				// where can word start from if it has to intersect target?
				// note: it has to be orthogonal to target's orientation, so incrY used to compute x offset, and vice versa
				// rangeStart and end are both inclusive
				int rangeXStart = ix - ((word.length() - 1) * incrY);  
				int rangeXEnd = ix; 
				int rangeYStart = iy - ((word.length() - 1) * incrX); 
				int rangeYEnd = iy; 
				for  (int x = rangeXStart; x <= rangeXEnd; x++)
					for  (int y = rangeYStart; y <= rangeYEnd; y++)
					{
						Pair<Boolean, Integer> p = isLegalAndIntersects(word, x, y, !newlyPlaced.acrossNotDown);
						if (p.getFirst()) 
							set.add(new PlaceInfo(word, x, y, !newlyPlaced.acrossNotDown, p.getSecond()));
					}
			}
			
			ix += incrX;
			iy += incrY;
		}
		List<PlaceInfo> result = new ArrayList<PlaceInfo>(set);
		// note: placeinfo sort uses # intersects and lower x and y coordinates
	//	Collections.sort(result);
		return result;
	}

	/** returns whether it was successful in placing all the words in c.candidateWords */
	private boolean placeWordsRecursive (Cluer cluer, Collection<PlaceInfo> currentOptions, PlaceInfo justPlaced) throws CorruptIndexException, LockObtainFailedException, IOException, ParseException, GeneralSecurityException, ClassNotFoundException, ReadContentsException 
	{
		// check if we've hit timeout
		if (timedOut)
			return true;
		
		long elapsedMillis = System.currentTimeMillis() - startTime;
		if (wordsCommitted > MIN_WORD_COMMITS && elapsedMillis > timeoutMillis)
		{
			timedOut = true;
			log.info("placer halted due to timeout after " + elapsedMillis + " ms");
			
			// now reset the grid, and rebuild the crossword from bestPlacedWords
			c.reset();
			reset();
			if (!Util.nullOrEmpty(bestGrid.placedWords)) 
				for (Word W: bestGrid.placedWords)
				{
					c.commitWord(W, false);
					commitWordToGrid(W);
				}
			return true;
		}
		
		if (c.candidateWords.size() == 0) // everything placed, nothing to do
			return true;
		
		// what are our placement options at this point?
		// if we don't have existing options, sweep the whole grid.
		// otherwise, for efficiency, just update using our existing options
		List<PlaceInfo> placementOptions;
		if (currentOptions == null)
			placementOptions = sweepGridToComputePlacementOptions();
		else
		{
			// if we already had some options, we can update our options more efficiently.
			// when placedWords.size() == 1, no point looking at existing options, all new options must intersect justPlaced
			Collection<PlaceInfo> referenceOptions = c.placedWords.size() == 1 ? null : currentOptions;
			placementOptions = updatedOptions(referenceOptions, justPlaced);	
		}
		
		if (Util.nullOrEmpty(placementOptions))
			return false;
				
		// place options one by one. they are sorted by # intersections, and then by their ending x, y coords
		int count = 0;
		for (PlaceInfo placementOption: placementOptions)
		{
			// to avoid blowup, only consider MAX_OPTIONS_PER_LEVEL options considered per level... can tune, but 2 seems to work fine
			// Exception: we love n_intersects >= 2 because they densify the grid, so keep going even if we have crossed MAX_OPTIONS_PER_LEVEL
			if (placementOption.nIntersects <= 1 && ++count > MAX_OPTIONS_PER_LEVEL) 
				return false;
			
			// prepare word W
			String word = placementOption.word;
			c.candidateWords.remove(word);

			String originalAnswer = c.getOriginalAnswer(word);			
			Word W = new Word(word, originalAnswer, placementOption.x, placementOption.y, placementOption.acrossNotDown, false);
			Pair<String, List<Integer>> p1 = Crossword.convertToWord(originalAnswer);
			W.setWordLens(p1.getSecond());											
			
			// commit W (if we can find a valid clue for it). 
			/// in the BT placer, we should always find the clue, so the null check is overly defensive.
			Clue clue = null;
			try { clue = cluer.bestClueFor(word, c.sentencesUsedAsClues); } catch (Exception e) { Util.print_exception(e, log); }
			if (clue == null)
				continue;
			W.setClue(clue);
			c.commitWord(W, false);
			commitWordToGrid(W);
			
			boolean bestGridUpdated = updateBestGridSoFar(); // capture this grid if its the best one so far
			if (log.isDebugEnabled())
				log.debug ("{\"x\":" + W.x + ",\"y\":" + W.y + ",\"acrossNotDown\":" + (W.acrossNotDown) + ",\"level\":"+ c.placedWords.size() + ",\"best\":" + bestGridUpdated + ",\"word\":\"" + W.word + "\"},");

			justPlaced = placementOption;
			// try to place the remaining words
			if (placeWordsRecursive(cluer, placementOptions, justPlaced))
				return true;
			
			// else we hit a wall... let's undo the placement and add the word back to the candidates pool
			// waitasec, what about the sequence in c.candwords? it doesnt matter since place infos are sorted anyway
			if (log.isDebugEnabled())
				log.debug ("{\"x\":" + W.x + ",\"y\":" + W.y + ",\"acrossNotDown\":" + (W.acrossNotDown) + ",\"level\":"+ c.placedWords.size() + ",\"best\":" + bestGridUpdated + ",\"word\":\"" + W.word.replaceAll(".", " ") + "\"}, // undo " + W.word);
			uncommitWordToGrid(W);
			c.candidateWords.add(word);
			c.placedWords.remove(W);
		}
		return false;
	}

	/** dosymmetric is currently ignored */
	@Override
	void placeWordsAndCreateClues (boolean doSymmetric, Cluer cluer) throws CorruptIndexException, LockObtainFailedException, IOException, ParseException, GeneralSecurityException, ClassNotFoundException, ReadContentsException 
	{
		startTime = System.currentTimeMillis();
		wordsCommitted = 0;
		
		if (c.candidateWords.size() > 1)
			MAX_OPTIONS_PER_LEVEL = (int) (Math.log(MIN_WORD_COMMITS)/Math.log(c.candidateWords.size()));
		if (MAX_OPTIONS_PER_LEVEL < 2)
			MAX_OPTIONS_PER_LEVEL = 2;
			
		/*
		Collections.sort(c.candidateWords, new Comparator<String>() {
			public int compare (String s1, String s2)
			{
				return s2.length() - s1.length();
			}
		});
		*/
		boolean status = placeWordsRecursive(cluer, null, null);
		
		if (c.placedWords.size() < c.candidateWords.size())
		{
			// we didn't place everything already.
			// try again, if we have time, with unlimited options per level
			// for very small puzzles, exhaustive search is more important than speed
			MAX_OPTIONS_PER_LEVEL = Integer.MAX_VALUE;
			status |= placeWordsRecursive(cluer, null, null);
		}		
		log.info ("Final crossword status: " + wordsCommitted + " commits, " + c.placedWords.size() + " placed words, " + bestGridUpdates + " best grid updates, time taken: " + (System.currentTimeMillis() - startTime));
		
		Set<String> s1 = new LinkedHashSet<String>(c.candidateWords);
		Set<String> s2 = new LinkedHashSet<String>();
		for (Word W: c.placedWords)
			s2.add(W.word);
		
		s1.removeAll(s2);
		log.info ("unplaced: " + s1);
		
		log.info (c);
		if (status)
			c.recomputeBoxToPlacedWordIdxs();
		else
			log.warn ("Placer returning without placing all words: " + c.placedWords.size() + " words placed");
	}	
}
