package edu.stanford.muse.xword;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.store.LockObtainFailedException;

import edu.stanford.muse.exceptions.ReadContentsException;
import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.Util;

public class FixedPlacer extends Placer {
	private static Log log = LogFactory.getLog(FixedPlacer.class);

	Map<String, Set<PlaceInfo>> options = new LinkedHashMap<String, Set<PlaceInfo>>();
	public FixedPlacer(Crossword c) 
	{ 
		super(c); 
	}

	/* returns word with the fewest options for placement */
	private String getWordWithFewestOptions()
	{
		int min = Integer.MAX_VALUE;
		String bestWord = "";
		for (String word: c.candidateWords)
		{
			Set<PlaceInfo> locs = options.get(word);
			if (locs == null)
				continue;
			int nOptions = locs.size();
			if (nOptions > 0 && nOptions < min)
			{
				bestWord = word;
				min = nOptions;
			}
		}
		if (min == 0)
			log.info ("Removing " + bestWord + " because it has no options");
		else
			log.info ("Selecting " + bestWord + " because it has " + min + " options");
		return bestWord;
	}
	
	// do any of the given words cross the square x, y?
	private boolean wordsCrossSquare(Set<String> intersectingWords, int x, int y)
	{
		if (Util.nullOrEmpty(intersectingWords))
			return true;
		
		List<Integer> wordsAtSquareIdxs = c.boxToPlacedWordsIdxs[x][y];
		Set<String> wordsAtSquare = new LinkedHashSet<String>();

		// identify words at this square
		if (!Util.nullOrEmpty(wordsAtSquareIdxs))
			for (Integer idx: wordsAtSquareIdxs)
				wordsAtSquare.add(c.placedWords.get(idx).word);
		
		// check for intersections
		try {
		wordsAtSquare.retainAll(intersectingWords);
		} catch (Exception e) {
			Util.breakpoint();
		}
		return (wordsAtSquare.size() > 0);
	}
	
	/** checks if word can be placed at x, y. if wordsAtSquare is non null, also checks if it intersects ANY one of them */
	Pair<Boolean, Integer> isLegalAndIntersects(String word, int x, int y, boolean acrossNotDown, Set<String> wordsToIntersect)
	{
		if (c.box[x][y] == Crossword.STOP)
			return new Pair<Boolean, Integer>(false, 0);
		int b = acrossNotDown ? 0 : 1;
		if (!canStartFrom(x, y, b))
			return new Pair<Boolean, Integer>(false, 0);
		if (!willWordFitOnGrid(word, x, y, acrossNotDown))
			return new Pair<Boolean, Integer>(false, 0);
	
		int incrX = acrossNotDown ? 1 : 0;
		int incrY = acrossNotDown ? 0 : 1;
		int ix = x, iy = y;
	
		int intersects = 0; // #intersects with existing chars
		for (int i = 0; i < word.length(); i++)
		{
			char c = word.charAt(i);
			// bail out if its not empty and not the same as the existing char
			if (this.c.box[ix][iy] != Crossword.EMPTY && this.c.box[ix][iy] != c)
				return new Pair<Boolean, Integer>(false, 0);

			if (this.c.box[ix][iy] == c && wordsCrossSquare(wordsToIntersect, ix, iy))
			{
//				meetsAnyNonIntersectingWord |= isSolitaryWord(ix, iy, c, !acrossNotDown); // || because it might be meeting more than one word
				intersects++;
			}
			else
			{
				// if its empty, check whether neighboring squares in orthogonal direction are also empty
				if (!neighboringSquaresEmpty(ix, iy, c, !acrossNotDown))
					return new Pair<Boolean, Integer>(false, 0);
			}
			ix += incrX;
			iy += incrY;
		}		
		return new Pair<Boolean, Integer>(true, intersects);
	}
	
	protected void recomputeOptionsMap()
	{
		options.clear();
		
		// compute wordsToIntersect = the list of disconnected words if any, otherwise null
		Set<Word> disconnected = c.getDisconnectedWords();
		Set<String> wordsToIntersect = new LinkedHashSet<String>();
		for (Word W: disconnected)
			wordsToIntersect.add(W.word);
		if (wordsToIntersect.size() == 0)
			wordsToIntersect = null;
		else
			log.info("Looking to intersect: " + wordsToIntersect);
		
		boolean haveOptions = false, urgency = false;
		
		for (int i = 0; i < 2; i++)
		{
			for (String cand: c.candidateWords)
			{
				Set<PlaceInfo> set = new LinkedHashSet<PlaceInfo>();
				for (int x = 0; x < c.w; x++)
					for (int y = 0; y < c.h; y++)
					{
	//					if (y %2 == 0 && canStartFrom(x, y, 0))
						if (canStartFrom(x, y, 0))
						{
							Pair<Boolean, Integer> p = isLegalAndIntersects(cand, x, y, true, wordsToIntersect);
							if (p.getFirst())
								if (Util.nullOrEmpty(wordsToIntersect) || p.getSecond() > 0)
								{
									set.add(new PlaceInfo(cand, x, y, true, p.getSecond()));
								}
						}
	//					if (x %2 == 0 && canStartFrom(x, y, 1))
						if (canStartFrom(x, y, 1))
						{
							Pair<Boolean, Integer> p = isLegalAndIntersects(cand, x, y, false, wordsToIntersect);
							if (p.getFirst())
								if (Util.nullOrEmpty(wordsToIntersect) || p.getSecond() > 0)
									set.add(new PlaceInfo(cand, x, y, false, p.getSecond()));
						}
					}
				if (set.size() > 0)
					haveOptions = true;
				if (set.size() > 0 && set.size() < 20)
					urgency = true;
				options.put(cand, set);
			}
	
			if (wordsToIntersect == null && !urgency)  // we don't have disconnected words, but no urgency in placing any word, so just look for max intersections
			{ 
				wordsToIntersect = new LinkedHashSet<String>();
				for (Word W: c.placedWords)
					wordsToIntersect.add(W.word);
			}
			else if (haveOptions) // we have disconnected words that we could connect up, so we should just do that right away
				return;
			else
				wordsToIntersect = null; // try 2nd iteration without wordsToIntersect
		}
	}
	

	
	@Override
	void placeWordsAndCreateClues (boolean doSymmetric, Cluer cluer) throws CorruptIndexException, LockObtainFailedException, IOException, ParseException, GeneralSecurityException, ClassNotFoundException, ReadContentsException 
	{
		boolean preferredDir = true;
		
		Set<String> unplacable = new LinkedHashSet<String>();
		log.info ("Starting an iteration with no intersections");
		while (c.candidateWords.size() > 0)
		{
			recomputeOptionsMap();
			String word = getWordWithFewestOptions();
			if (Util.nullOrEmpty(word))
				break;
			Collection<PlaceInfo> locs = options.get(word);
			if (locs.size() > 0)
			{
				c.candidateWords.remove(word);
				List<PlaceInfo> locsList = new ArrayList<PlaceInfo>();
				Collections.sort(locsList);
				PlaceInfo loc = null;
				for (PlaceInfo l: locs)
				{
					if (l.acrossNotDown == preferredDir)
					{
						loc = l;
						break;
					}
				}
				if (loc == null)
					loc = locs.iterator().next();
				
				String originalAnswer = c.getOriginalAnswer(word);
				Word W = new Word(word, originalAnswer, loc.x, loc.y, loc.acrossNotDown, false);
				Pair<String, List<Integer>> p1 = Crossword.convertToWord(originalAnswer);
				W.setWordLens(p1.getSecond());											
				Clue clue = null;
				try { clue = cluer.bestClueFor(word, c.sentencesUsedAsClues); } catch (Exception e) { Util.print_exception(e, log); }
				if (clue != null)
				{
					W.setClue(clue);
					commitWordToGrid(W);
					c.commitWord(W, false);
					preferredDir = !preferredDir;
					log.info(c);
				}
			}
			else
				unplacable.add(word);
			
			if (unplacable.size() == c.candidateWords.size())
				break;
		}		
	}
}
