/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.index;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.MapFieldSelector;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexReader.FieldOption;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.ComplexExplanation;
import org.apache.lucene.search.Explanation;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.WildcardQuery;
import org.apache.lucene.search.regex.RegexQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.LockObtainFailedException;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.store.SingleInstanceLockFactory;
import org.apache.lucene.util.Version;

import edu.stanford.muse.datacache.Blob;
import edu.stanford.muse.datacache.BlobStore;
import edu.stanford.muse.lang.Languages;
import edu.stanford.muse.util.EmailUtils;
import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.Util;
import edu.stanford.muse.webapp.Config;
import edu.stanford.nlp.util.Triple;

public class LuceneIndexer extends Indexer {
	private static final long serialVersionUID = -6554496806619154004L; // for compat, should have been 1
	private static final String LANGUAGE_FIELD_DELIMITER = "|"; // warning: make sure this is a single char, not a string because StringTokenizer constructor with "AB" will split on A or B
	public static final String NAMES_FIELD_DELIMITER = "\n";
	public static final Version MUSE_LUCENE_VERSION = Version.LUCENE_34;
	private static final String INDEX_BASE_DIR_NAME = "indexes";
	private static final String INDEX_NAME_EMAILS = "emails";
	private static final String INDEX_NAME_ATTACHMENTS = "attachments";

	public static interface FilterFunctor {
		boolean filter(Document doc); // can modify doc and return whether the result should be included
	}

    static Log log = LogFactory.getLog(LuceneIndexer.class);

	private Map<String, EmailDocument> docMap = new LinkedHashMap<String, EmailDocument>(); // docId -> EmailDoc
	private Map<String, Blob> blobMap = new LinkedHashMap<String, Blob>(); // attachment's docnum -> Blob
	private HashMap<String, HashMap<Integer,String>> dirNameToDocNumMap = new LinkedHashMap<String, HashMap<Integer,String>>(); // just stores 2 maps, one for content and one for attachment Lucene doc ID -> docNum

    transient private Directory directory;
    transient private Directory directory_blob; // for attachments
	transient private Analyzer analyzer;
	transient private IndexSearcher isearcher;
	transient private IndexSearcher isearcher_blob;
	transient private QueryParser parser, parserOriginal; // parserOriginal searches the original content (non quoted parts) of a message
	transient private IndexWriter iwriter;
	transient private IndexWriter iwriter_blob;
	transient private String[] blobDocNums, contentDocNums; // these are fieldCaches of ldoc -> docNum for the docNums (for performance)
	
	transient private String baseDir = null; // where the file-based directories should be stored (under "indexes" dir)

	public static final Set<?> MUSE_STOP_WORDS_SET;

	static {
		// Warning: changes in this list requires re-indexing of all existing archives.
		final List<String> stopWords = Arrays.asList(
	      "a", "an", "and", "are", "as", "at", "be", "but", "by",
	      "for", "if", "in", "into", "is", "it",
	      "no", /*"not",*/ "of", "on", "or", "such",
	      "that", "the", "their", "then", "there", "these",
	      "they", "this", "to", "was", "will", "with"
	    );
	    final CharArraySet stopSet = new CharArraySet(MUSE_LUCENE_VERSION, stopWords.size(), false);
	    stopSet.addAll(stopWords);
	    MUSE_STOP_WORDS_SET = CharArraySet.unmodifiableSet(stopSet);
	}

	// Below two routines are for dropping fields from index on the given directory.
	// (Adapted from http://www.flax.co.uk/blog/2011/06/24/how-to-remove-a-stored-field-in-lucene/)

	// report on whether some of these fields exist in the given directory, and return result
	private static boolean indexHasFields(Directory dir, String... fields) throws CorruptIndexException, IOException
	{
		if (Util.nullOrEmpty(fields))
			return false;

		IndexReader reader = IndexReader.open(dir, true); // read-only=true
		Collection<String> fieldNames = reader.getFieldNames(FieldOption.ALL);
		reader.close();
		for (String field : fields) {
			if (fieldNames.contains(field)) {
				return true;
			}
		}
		return false;
	}

	// since we may need to rebuild the index in a new directory, the analyzer needs to have been initialized apriori 
	public synchronized Directory copyDirectoryExcludeFields(Directory dir, String out_basedir, String out_name, String... fields_to_be_removed) throws CorruptIndexException, IOException
	{
		IndexReader reader = IndexReader.open(dir, true); // read-only=true

		Directory newDir = createDirectory(out_basedir, out_name);
		IndexWriter writer = openIndexWriter(newDir);
		//log.info("Removing field(s) " + Util.join(fields_to_be_removed, ", ") + " from index.");

		for (int i = 0; i < reader.numDocs(); i++) {
			Document doc = reader.document(i);
			for (String field : fields_to_be_removed)
				doc.removeFields(field);
			writer.addDocument(doc);
		}

		writer.close();
		reader.close();

		return newDir;
	}

	// since we may need to rebuild the index in a new directory, the analyzer needs to have been initialized apriori 
	public synchronized Directory copyDirectoryWithDocFilter(Directory dir, String out_basedir, String out_name, FilterFunctor filter_func) throws CorruptIndexException, IOException
	{
		IndexReader reader = IndexReader.open(dir, true); // read-only=true

		Directory newDir = createDirectory(out_basedir, out_name);
		IndexWriter writer = openIndexWriter(newDir);
		//log.info("Removing field(s) " + Util.join(fields_to_be_removed, ", ") + " from index.");

		for (int i = 0; i < reader.numDocs(); i++) {
			Document doc = reader.document(i);
			if (filter_func == null || filter_func.filter(doc))
				writer.addDocument(doc);
		}

		writer.close();
		reader.close();

		return newDir;
	}

	private synchronized Directory removeFieldsFromDirectory(Directory dir, String... fields_to_be_removed) throws CorruptIndexException, IOException
	{
		if (!indexHasFields(dir, fields_to_be_removed))
			return dir;

		boolean is_file_based = dir instanceof FSDirectory;

		String tmp_name = ".tmp";
		FSDirectory fsdir = null;
		if (is_file_based) {
			fsdir = (FSDirectory) dir;
			tmp_name = fsdir.getDirectory().getName() + tmp_name;
		}

		Directory newDir = copyDirectoryExcludeFields(dir, baseDir, tmp_name, fields_to_be_removed);

		if (is_file_based) {
			// delete the original dir and rename tmp
			File org_file = fsdir.getDirectory();
			File tmp_file = ((FSDirectory) newDir).getDirectory();
			FileUtils.deleteDirectory(org_file);
			tmp_file.renameTo(org_file);
		}

		return newDir;
	}

	// since we may need to rebuild the index in a new directory, the analyzer needs to have been initialized apriori 
	public synchronized void removeFieldsFromDirectory(String... fields_to_be_removed) throws CorruptIndexException, IOException
	{
		directory = removeFieldsFromDirectory(directory, fields_to_be_removed);
		directory_blob = removeFieldsFromDirectory(directory_blob, fields_to_be_removed);
	}

	public synchronized void copyDirectoryExcludeFields(String out_dir, String... fields_to_be_removed) throws CorruptIndexException, IOException
	{
		directory = copyDirectoryExcludeFields(directory, out_dir, INDEX_NAME_EMAILS, fields_to_be_removed);
		directory_blob = copyDirectoryExcludeFields(directory_blob, out_dir, INDEX_NAME_ATTACHMENTS, fields_to_be_removed);
	}

	public synchronized void copyDirectoryWithDocFilter(String out_dir, FilterFunctor func) throws CorruptIndexException, IOException
	{
		directory = copyDirectoryWithDocFilter(directory, out_dir, INDEX_NAME_EMAILS, func);
		directory_blob = copyDirectoryWithDocFilter(directory_blob, out_dir, INDEX_NAME_ATTACHMENTS, func);
	}

	private synchronized boolean indexAttachments(EmailDocument e, BlobStore blobStore, Set<Blob> processedBlobSet, IndexStats stats) throws IOException
	{
		boolean result = true;
		if (e.attachments == null) return result;
		final String delimiter = "\n";
		for (Blob b : e.attachments) {
			if (processedBlobSet != null && processedBlobSet.contains(b)) continue; // skip if already processed (blob may be shared by multiple docs)
			int id_int = iwriter_blob.numDocs();
			String id = Integer.toString(++id_int);
			if (processedBlobSet != null) processedBlobSet.add(b);
			blobMap.put(id, b);

			Document doc = new Document(); // not to be confused with edu.stanford.muse.index.Document
			Pair<String,String> content = b.getContent(blobStore);
			if (content == null) {
				// failed to process blob
				result = false;
				continue; // but try to continue the process
			}

			// imp: for id, should use Field.Index.NOT_ANALYZED field should be http://vuknikolic.wordpress.com/2011/01/03/lucenes-field-options-store-and-index-aka-rtfm/
			doc.add(new Field("docNum", id, Field.Store.YES, Field.Index.NOT_ANALYZED));

			String documentText = content.first + delimiter + content.second;
			Set<String> names = extractNamesForDoc(documentText, doc);
		
			// we'll store all languages detected in the doc as a field in the index
			Set<String> languages = Languages.getAllLanguages(documentText);
			String lang_str = Util.join(languages, LANGUAGE_FIELD_DELIMITER);
			doc.add(new Field("languages", lang_str, Field.Store.YES, Field.Index.NO));

			String s =  Util.join(names, NAMES_FIELD_DELIMITER); // just some connector for storing the field
			if (s == null)
				s = "";

			doc.add(new Field("names", s, Field.Store.YES, Field.Index.ANALYZED));

			// log.info ("blob metadata = " + content.first);
			doc.add(new Field("meta", content.first, Field.Store.YES, Field.Index.ANALYZED));
			doc.add(new Field("body", content.second, Field.Store.YES, Field.Index.ANALYZED));

			iwriter_blob.addDocument(doc);
			//log.info("Indexed attachment #" + id + " : text = '" + documentText + "' names = '" + s + "'");
			if (stats != null) {
				stats.indexedTextLength_blob += documentText.length();
				stats.nIndexedNames_blob += names.size();
			}
		}
		return result;
	}

	public synchronized boolean indexAttachments(Collection<EmailDocument> docs, BlobStore blobStore) throws CorruptIndexException, LockObtainFailedException, IOException
	{
		if (iwriter_blob == null) {
			//if (directory_blob == null) directory_blob = initializeDirectory(directory_blob, INDEX_NAME_ATTACHMENTS); // should already be valid
			iwriter_blob = openIndexWriter(directory_blob);
		}
		blobMap = new LinkedHashMap<String, Blob>();
		Set<Blob> processedBlobSet = new LinkedHashSet<Blob>();
		boolean result = true;
		for (EmailDocument e : docs) {
			result &= indexAttachments(e, blobStore, processedBlobSet, stats);
		}
		iwriter_blob.close();
		return result;
	}

	static private Directory createDirectory(String baseDir, String name) throws IOException
	{
		//return new RAMDirectory();
		String index_dir = baseDir + File.separator + INDEX_BASE_DIR_NAME;
		new File(index_dir).mkdir(); // will not create parent basedir if not already exist
		return FSDirectory.open(new File(index_dir + File.separator + name));
	}

	private Directory createDirectory(String name) throws IOException
	{
		return createDirectory(this.baseDir, name);
	}

	public LuceneIndexer(String baseDir, IndexOptions io) throws IOException {
		super(io);
		this.baseDir = baseDir;
		analyzer = new StandardAnalyzer(MUSE_LUCENE_VERSION, MUSE_STOP_WORDS_SET);
		directory = createDirectory(INDEX_NAME_EMAILS);
		iwriter = openIndexWriter(directory);
		directory_blob = createDirectory(INDEX_NAME_ATTACHMENTS);
		iwriter_blob = openIndexWriter(directory_blob);
	}

	// set create = false to append to existing index.
	@SuppressWarnings("deprecation")
	private IndexWriter openIndexWriter(Directory dir, boolean create) throws CorruptIndexException, LockObtainFailedException, IOException
	{
		//IndexWriterConfig config = new IndexWriterConfig(MUSE_LUCENE_VERSION, null);
		//IndexWriter writer = new IndexWriter(dir, null, IndexWriter.MaxFieldLength.UNLIMITED);
		return new IndexWriter(dir, analyzer, create, new IndexWriter.MaxFieldLength(250000));
	}

	// auto append if exists. else, create a new index.
	private IndexWriter openIndexWriter(Directory dir) throws IOException
	{
		boolean create = !IndexReader.indexExists(dir);
		return openIndexWriter(dir, create);
	}


	public LuceneIndexer() throws IOException { 
		this(null, (IndexOptions) null);
	}

	public EmailDocument docForId(String id) { return docMap.get(id); }
	public Map<String, EmailDocument> getDocMap() { return docMap; }
	 
	public void setBaseDir(String baseDir)
	{
		if (this.baseDir != null && !this.baseDir.equals(baseDir)) {
			close();
		}
		this.baseDir = baseDir;
	}

	/** sets up directory 
	 * @throws IOException */
	public synchronized void setupDirectory() throws IOException
	{
		directory = initializeDirectory(directory, INDEX_NAME_EMAILS);
		directory_blob = initializeDirectory(directory_blob, INDEX_NAME_ATTACHMENTS);

		if (analyzer == null)
			analyzer = new StandardAnalyzer(MUSE_LUCENE_VERSION, MUSE_STOP_WORDS_SET);
	}

	/** sets up indexer just for reading... if needed for writing only, call setupForWrite. if need both read & write, call both. */
	public synchronized void setupForRead()
	{
		log.info ("setting up index for read only access");
		//closeHandles();
		try {
			setupDirectory();

			String[] defaultSearchFields, defaultSearchFieldsOriginal;
			if (Config.isPublicMode()) {
				defaultSearchFields = new String[]{"names"};
				defaultSearchFieldsOriginal = new String[]{"names_original"};
				removeFieldsFromDirectory("body_raw", "body_original", "title"); // should have been removed before archive export, but do it again, just in case				
			} else {
				defaultSearchFields = new String[]{"body", "title", "names"};
				defaultSearchFieldsOriginal = new String[]{"body_original", "title", "names_original"};
				// names field added above after email discussion with Sit 6/11/2013. problem is that we're not using the Lucene EnglishPossessiveFilter, so
				// NER will extract the name Stanford University in a sentence like:
				// "This is Stanford University's website." 
				// but when the user clicks on the name "Stanford University" in say monthly cards, we 
				// will not match the message with this sentence because of the apostrophe.
			}

			// Parse a simple query that searches for "text":
			if (parser == null) {
				//parser = new QueryParser(MUSE_LUCENE_VERSION, defaultSearchField, analyzer);
				parser = new MultiFieldQueryParser(MUSE_LUCENE_VERSION, defaultSearchFields, analyzer);
				parserOriginal = new MultiFieldQueryParser(MUSE_LUCENE_VERSION, defaultSearchFieldsOriginal, analyzer);
			}
		
			if (IndexReader.indexExists(directory))
			{
				isearcher = new IndexSearcher(directory, true); // read-only=true
				IndexReader ireader = isearcher.getIndexReader();
				contentDocNums = org.apache.lucene.search.FieldCache.DEFAULT.getStrings(ireader, "docNum"); 
			}
			
			if (IndexReader.indexExists(directory_blob))
			{
				isearcher_blob = new IndexSearcher(directory_blob, true); // read-only=true
				IndexReader ireader = isearcher_blob.getIndexReader();
				blobDocNums = org.apache.lucene.search.FieldCache.DEFAULT.getStrings(ireader, "docNum"); 
			}

			if (dirNameToDocNumMap == null)
				dirNameToDocNumMap = new LinkedHashMap<String, HashMap<Integer,String>>();
		} catch (Exception e) { Util.print_exception(e, log); }		
	}
	
	public int nDocsInIndex()
	{
		return iwriter.maxDoc();
	}
	
	/** preferably use this method to open an existing index.... set it up only for writing. if need read also, call setupForRead too.
	 * but packIndex MUST be called to close the writer, otherwise lucene will throw write lock errors */
	public void setupForWrite() throws CorruptIndexException, LockObtainFailedException, IOException
	{
		log.info ("setting up index for write access");
		setupDirectory();

		if (iwriter == null)
			iwriter = openIndexWriter(directory);
		if (iwriter_blob == null)
			iwriter_blob = openIndexWriter(directory_blob);

		// invalidate docNumMap cache as Lucene doc ID may change
		dirNameToDocNumMap = new LinkedHashMap<String, HashMap<Integer,String>>();
	}
	
	private synchronized Directory initializeDirectory(Directory dir, String name) throws IOException
	{
		if (dir == null)
			dir = createDirectory(name);
		if (dir.getLockFactory() == null)
			 dir.setLockFactory(new SingleInstanceLockFactory());
		return dir;
	}

	public static List<String> extractNames(String text) throws Exception
	{
		List<Pair<String, Float>> pairs = NER.namesFromText(text);
		List<String> names = new ArrayList<String>();
		for (Pair<String, ?> pair: pairs)
		{
			String name = pair.getFirst();
			name = name.replace("\n", " ").trim().intern();
			names.add(name);
		}
		
		return names;
	}
	
	public static Set<String> extractNamesAsSet(String text)
	{
		Set<String> names = new LinkedHashSet<String>();
		try {
			List<Pair<String, Float>> pairs = NER.namesFromText(text);
			for (Pair<String, ?> pair: pairs)
			{
				String name = pair.getFirst();
				name = name.replace("\n", " ").trim().intern();
				names.add(name);
			}
		} catch (Exception e) {
			log.warn("Unable to extract names from '" + text + "' : " + Util.stackTrace(e));
		}
		
		return names;
	}

	/*
	 * properly close index writers.
	 * also null out directories that may not be serializable
	 * (e.g., RAMDirectory is, but FSDirectory isn't)
	 */
	@Override
	public void close()
	{
		log.info ("Closing indexer handles");
		//closeHandles();
		analyzer = null;
		parser = parserOriginal = null;
		try {
			if (isearcher != null)
				isearcher.close();
		} catch (IOException e) { Util.print_exception(e, log); }
		isearcher = null;
		try {
			if (isearcher_blob != null)
				isearcher_blob.close();
		} catch (IOException e) { Util.print_exception(e, log); }
		isearcher_blob = null;
		try {
			if (iwriter != null)
				iwriter.close();
		} catch (Exception e) { Util.print_exception(e, log); }
		iwriter = null;
		try {
			if (iwriter_blob != null)
				iwriter_blob.close();
		} catch (Exception e) { Util.print_exception(e, log); }
		iwriter_blob = null;

		if (directory != null && !(directory instanceof Serializable)) {
			try {
				directory.close();
			} catch (Exception e) { Util.print_exception(e, log); }
			try {
				directory_blob.close();
			} catch (Exception e) { Util.print_exception(e, log); }
			directory = null;
			directory_blob = null;
		}
	}
	
	private Set<String> extractNamesForDoc(String text, Document doc)
	{
		Pair<Map<String, List<String>>, List<Triple<String, Integer, Integer>>> mapAndOffsets = NER.categoryToNamesMap(text);

		List<Triple<String, Integer, Integer>> offsets = mapAndOffsets.second;
		putNamesOffsets(doc, offsets);

		Map<String, List<String>> categoryToNamesMap = mapAndOffsets.first;
		// we'll get people, places, orgs in this map

		Set<String> allNames = new LinkedHashSet<String>(); 
		for (String category: categoryToNamesMap.keySet())
		{
			List<String> namesForThisCategory = Util.scrubNames(categoryToNamesMap.get(category));
			String s = Util.join(namesForThisCategory, NAMES_FIELD_DELIMITER);
			doc.add(new Field(category.toLowerCase(), s, Field.Store.YES, Field.Index.ANALYZED));
			allNames.addAll(namesForThisCategory);
		}

		return allNames;
	}

	private void putNamesOffsets(Document doc, List<Triple<String, Integer, Integer>> offsets)
	{
		try {
			ByteArrayOutputStream bs = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(bs);
			oos.writeObject(offsets);
			oos.close();
			bs.close();
			doc.add(new Field("names_offsets", bs.toByteArray()));
		} catch (IOException e) {
			log.warn("Failed to serialize names_offsets");
			e.printStackTrace();
		}
	}

	public static List<Triple<String, Integer, Integer>> getNamesOffsets(Document doc)
	{
		byte[] data = doc.getBinaryValue("names_offsets");
		if (data == null) return null;
		ByteArrayInputStream bs = new ByteArrayInputStream(data);
		List<Triple<String, Integer, Integer>> result;
		ObjectInputStream ois;
		try {
			ois = new ObjectInputStream(bs);
			result = (List<Triple<String, Integer, Integer>>) ois.readObject();
		} catch (Exception e) {
			log.warn("Failed to deserialize names_offsets");
			e.printStackTrace();
			result = new ArrayList<Triple<String,Integer,Integer>>();
		}

		return result;
	}

	/** internal method, core method for adding a doc to the index. 
	 * adds body, title, people, places, orgs. assumes the index, iwriter etc are already set up and open.
	 * does NER and returns the list of all names 
	 * @param stats */
	private synchronized int add1DocToIndex(String title, String body, edu.stanford.muse.index.Document  d, IndexStats stats) throws Exception
	{
		Document doc = new Document(); // not to be confused with edu.stanford.muse.index.Document

		String id = d.getUniqueId();
//		softAssertDocIdNotPresent(id);

		// imp: for id, should use Field.Index.NOT_ANALYZED field should be http://vuknikolic.wordpress.com/2011/01/03/lucenes-field-options-store-and-index-aka-rtfm/
		doc.add(new Field("docNum", id, Field.Store.YES, Field.Index.NOT_ANALYZED));
		
		// we'll store all languages detected in the doc as a field in the index
		Set<String> languages = Languages.getAllLanguages(body);
		d.languages = languages;
		String lang_str = Util.join(languages, LANGUAGE_FIELD_DELIMITER);
		doc.add(new Field("languages", lang_str, Field.Store.YES, Field.Index.NO));

		doc.add(new Field("title", title, Field.Store.YES, Field.Index.ANALYZED));

		// extract names from both title (weighted by subjectWeight) and body. put a fullstop after title to help NER.
		StringBuilder effectiveSubject = new StringBuilder(); // put body first so that the extracted NER offsets can be used without further adjustment at a later phase.
		for (int i = 0; i < io.subjectWeight; i++)
		{
			effectiveSubject.append(". ");
			effectiveSubject.append(title);
		}
		String textForNameExtraction = body + ". " + effectiveSubject; // Sit says put body first so that the extracted NER offsets can be used without further adjustment for epadd redaction
		Set<String> allNames = extractNamesForDoc(textForNameExtraction.toString(), doc);

		String s =  Util.join(allNames, NAMES_FIELD_DELIMITER); // just some connector for storing the field
		if (s == null)
			s = "";
		
		// should the names/names_orig filed be analyzed? We don't want them stemmed, after all.
		doc.add(new Field("names", s, Field.Store.YES, Field.Index.ANALYZED));

		// there are multiple body fields:
		// body_raw is the original as-is text, that will be used for rendering the message
		if (d instanceof EmailDocument)
		{
			// do preprocessing only for emails, not for other kinds of documents
			doc.add(new Field("body_raw", body, Field.Store.YES, Field.Index.ANALYZED)); // save raw before preprocessed
			
			// well, removing quoted parts of messages and fwded messages etc becomes problematic when we search for the term
			// search uses the body field (and not body_raw, which is used only when rendering the message contents)
			// so it needs to store the original full body, not just the non-quoted/non-fwded parts of the message!
			
			//body = preprocessDocument(d, body, null /* links */, io.includeQuotedMessages);
			//log.debug ("preprocessed documents: removed " + (len - body.length()) + " chars");
			//len = body.length();
			//body = Util.cleanupEmailMessage(body);
			// log.debug ("sanitized message: removed " + (len - body.length()) + " chars");
		}
		
		// the body field is what is used for searching. almost the same as body_raw, but in some cases, we expect
		// body != body_raw, e.g. if we have special logic to strip signatures, boilerplate text etc.
		// at the moment, body == body_raw, so we don't bother to store it.
		// doc.add(new Field("body", body, Field.Store.YES, Field.Index.ANALYZED));
		
		// body original is the original content in the message. this field is looked up for the purpose of sentiment analysis
		String bodyOriginal = EmailUtils.getOriginalContent(body);
		doc.add(new Field("body_original", bodyOriginal, Field.Store.YES, Field.Index.ANALYZED));
		int originalTextLength = bodyOriginal.length();
		// could do some stats here, on how many chars are eliminated by getOriginalContent
		String originalTextForNameExtraction = effectiveSubject + ". " + bodyOriginal;
		Set<String> originalNames = extractNamesForDoc(originalTextForNameExtraction.toString(), doc);
		
		s =  Util.join(originalNames, NAMES_FIELD_DELIMITER); // just some connector for storing the field
		if (s == null)
			s = "";
		
		doc.add(new Field("names_original", s, Field.Store.YES, Field.Index.ANALYZED));
		
//		if (d instanceof EmailDocument) {
//			EmailDocument ed = (EmailDocument) d;
//			String attachments = ed.getAllAttachmentContent("\n");
//			doc.add(new Field("attachments", attachments, Field.Store.NO, Field.Index.ANALYZED));
//		}

		iwriter.addDocument(doc);
		
		// why not maintain lucene doc id map instead of email doc id -> doc
		// how to get lucene doc id?
		docMap.put(id, (EmailDocument) d);
		if (stats != null) {
			stats.nDocuments++;
			stats.indexedTextSize += title.length() + body.length();
			stats.nNames += allNames.size();
			stats.nOriginalNames += originalNames.size();
			stats.indexedTextSizeOriginal += originalTextLength;
		}
		return allNames.size();
	}
	
	/* note sync. because we want only one writer to be going at it, at one time */
	@Override
	public synchronized int indexSubdoc(String title, String documentText, edu.stanford.muse.index.Document d, BlobStore blobStore)
	{
		if (d == null)
			return 0;
		
		if (documentText == null)
			documentText = "";

		int names = 0;
		
		try {
// why should we worry about nulls here?
//			if (analyzer == null) {
//				analyzer = new StandardAnalyzer(MUSE_LUCENE_VERSION, MUSE_STOP_WORDS_SET);
//			}
//			if (iwriter == null)
//			{
//				// reopen Directory
//				directory = initializeDirectory(directory, INDEX_NAME_EMAILS);
//				iwriter = openIndexWriter(directory, false);
//			}
//			if (iwriter_blob == null) {
//				directory_blob = initializeDirectory(directory_blob, INDEX_NAME_ATTACHMENTS);
//				iwriter_blob = openIndexWriter(directory_blob, true);
//			}
			add1DocToIndex(title, documentText, d, stats);
			if (blobStore != null && d instanceof EmailDocument && io.indexAttachments)
				indexAttachments((EmailDocument) d, blobStore, null, stats);
		} catch (Exception e) {
			Util.print_exception(e, log);
		}

		if (d instanceof EmailDocument)
		{
			if (d.links != null)
				links.addAll(d.links);
		}

		return names;
	}

	public List<Document> getAllDocs() throws CorruptIndexException, IOException 
	{
		List<Document> result = new ArrayList<Document>();

		IndexReader r = IndexReader.open(directory);			
		int num = r.numDocs();
		for (int i = 0; i < num; i++)
			if (!r.isDeleted(i))
				result.add(r.document(i));
		r.close();
		return result;
	}
		
	public List<Set<String>> getAllNames(Collection<String> ids, boolean originalContentOnly) throws CorruptIndexException, IOException 
	{
		List<Set<String>> result = new ArrayList<Set<String>>();
		for (String id: ids)
			result.add(getNamesForDocIdAsSet(id, originalContentOnly));
		return result;
	}
	
	@Override
	public Set<edu.stanford.muse.index.Document> docsForQuery(String term, int cluster, int threshold, boolean originalContentOnly) 
	{
		if (Util.nullOrEmpty(term))
			return new LinkedHashSet<edu.stanford.muse.index.Document>(getDocsInCluster(cluster));
		
		Set<edu.stanford.muse.index.Document> docs_in_cluster = null;
		if (cluster != -1)
			docs_in_cluster = new LinkedHashSet<edu.stanford.muse.index.Document>(getDocsInCluster(cluster));

		Set<edu.stanford.muse.index.Document> result = new LinkedHashSet<edu.stanford.muse.index.Document>();
		try {
			Collection<String> hitDocNums = luceneLookup(term, threshold, isearcher, originalContentOnly);
//			Collection<String> hitDocNums = luceneLookup(term);
			for (String d: hitDocNums)
			{
				EmailDocument ed = docMap.get(d);
				if (ed != null) {
					if (cluster == -1 || docs_in_cluster.contains(ed))
						// if for a specific cluster, obtain only the docs in the cluster
						result.add(ed);
				} else {
					log.warn ("Index hit for doc id " + d + " but doc does not exist!");
				}
			}
		} catch (Exception e) { Util.print_exception(e); }		

		return result;
	}

	public Set<Blob> blobsForQuery(String term)
	{
		Set<Blob> result = new LinkedHashSet<Blob>();

		if (Util.nullOrEmpty(term)) return result;

		try {
			Collection<String> hitDocNums = luceneLookup(term, 1, isearcher_blob, false /* original content only */);
//			Collection<String> hitDocNums = luceneLookup(term);
			for (String d: hitDocNums)
			{
				Blob b = blobMap.get(d);
				if (b != null) {
						result.add(b);
				} else {
					log.warn ("Index hit for blob id " + d + " but blob does not exist in map!");
				}
			}
		} catch (Exception e) { Util.print_exception(e); }		

		return result;
	}

	public int countHitsForQuery(String q) { return countHitsForQuery(q, false); }

	@Override
	public int countHitsForQuery(String q, boolean originalContentOnly) 
	{
		if (Util.nullOrEmpty(q))
			return 0;
		
		try {
			Query query = (originalContentOnly) ? parserOriginal.parse(q) : parser.parse(q);
			query = convertRegex(query); // to mimic built-in regex support
			ScoreDoc[] hits = isearcher.search(query, null, 10000).scoreDocs;
			return hits.length;
		} catch (Exception e) { Util.print_exception(e); }		

		return 0;
	}
	
	public synchronized void rollbackWrites() throws IOException
	{
		if (iwriter != null) {
			iwriter.rollback();
			iwriter = null;
		}
		if (iwriter_blob != null) {
			iwriter_blob.rollback();
			iwriter_blob = null;
		}
	}

	private Set<String> getNamesForDocIdAsSet(String id, boolean originalContentOnly) throws IOException
	{
		return new LinkedHashSet<String>(getNamesForDocId(id, originalContentOnly));
	}
	
	public List<String> getNamesForDocId(String id,  boolean originalContentOnly) throws IOException
	{
		// get this doc from the index first...
		Document docForThisId = getDoc(id);
		return getNamesForDoc(docForThisId, originalContentOnly);
	}
	
	private Set<String> getNamesForDocAsSet(Document doc, boolean originalContentOnly)
	{
		return new LinkedHashSet<String>(getNamesForDoc(doc, originalContentOnly));
	}

	private List<String> getNamesForDoc(Document doc, boolean originalContentOnly)
	{
		List<String> result = new ArrayList<String>();
		if (doc == null)
			return result;
		// ...and read its names
		String names = (originalContentOnly) ? doc.get("names_original") : doc.get("names");
		if (!Util.nullOrEmpty(names)) {
			StringTokenizer names_st = new StringTokenizer(names, LuceneIndexer.NAMES_FIELD_DELIMITER);
			while (names_st.hasMoreTokens())
				result.add(names_st.nextToken());
		}
		return result;
	}
	
	// assume the email isearcher
	private Collection<String> luceneLookupAsDocNums(String q, boolean originalContentOnly) throws CorruptIndexException, LockObtainFailedException, IOException, org.apache.lucene.queryParser.ParseException, GeneralSecurityException, ClassNotFoundException
	{
		return luceneLookupAsDocIds(q, 1, isearcher, originalContentOnly);
	}
	
	/** returns collection of docNum of the Lucene docs that hit, at least threshold times.
	 * warning! only looks up body field, no others
	 */
	private Collection<String> luceneLookupAsDocIds(String q, int threshold, IndexSearcher searcher, boolean originalContentOnly) throws CorruptIndexException, LockObtainFailedException, IOException, org.apache.lucene.queryParser.ParseException, GeneralSecurityException, ClassNotFoundException
	{
		Collection<String> result = new ArrayList<String>();
		
		String escaped_q = escapeRegex(q); // to mimic built-in regex support
	//	String escaped_q = q;
		Query query = originalContentOnly ? parserOriginal.parse(escaped_q) : parser.parse(escaped_q);
		query = convertRegex(query); // to mimic built-in regex support
		ScoreDoc[] hits = searcher.search(query, null, 10000).scoreDocs;

        // this logging causes a 50% overhead on the query -- maybe enable it only for debugging
		// log.info (hits.length + " hits for query " + Util.ellipsize(q, 30) + " => " + Util.ellipsize(escaped_q, 30) + " = " + Util.ellipsize(query.toString(), 30) + " :");

		// Iterate through the results:
		MapFieldSelector docNumField = new MapFieldSelector("docNum");

		// TODO: not very pretty code here to determine dir_name which selects the cache to use
		Util.softAssert(searcher == isearcher || searcher == isearcher_blob);
		String dir_name = searcher == isearcher ? INDEX_NAME_EMAILS : INDEX_NAME_ATTACHMENTS;

		HashMap<Integer,String> map = dirNameToDocNumMap.get(dir_name);
		if (map == null) {
			map = new LinkedHashMap<Integer, String>();
			dirNameToDocNumMap.put(dir_name, map);
			log.info("Uncached docNumMap");
		} else {
			log.info("Cached docNumMap");
		}
		int n_added = 0;
		for (int i = 0; i < hits.length; i++) {
			int ldocId = hits[i].doc; // this is the lucene doc id, we need to map it to our doc id.
			
			String docNum = null; // this will be our doc id
			
			// try to use the new fieldcache id's
			// if this works, we can get rid of the dirNameToDocNumMap
			try { docNum = (searcher == isearcher) ? contentDocNums[ldocId] : blobDocNums[ldocId]; } 
			catch (Exception e) { Util.print_exception(e, log); } 

			// NOTE: THIS SHOuLD NEVER BE EXECUTED NOW, WILL REMOVE IT SOON
			//	String docNum = map.get(ldocId);
			if (docNum == null) {
				Document hitDoc = searcher.doc(ldocId, docNumField); // expensive op esp with disk-based index
				docNum = hitDoc.getFieldable("docNum").stringValue();
				map.put(ldocId, docNum);
				n_added++;
			}
			
			if (threshold <= 1)
			{
				// common case: threshold is 1. 
				result.add(docNum);
			}
			else
			{
				// more expensive, do it only if threshold is > 1
				Explanation expl = searcher.explain(query, hits[i].doc);
				Explanation[] details = expl.getDetails();
				// NB: a catch here is that details.length doesn't reflect the actual # of hits for the query.
				// sometimes, for a single hit, there are 2 entries, a ComplexExplanation and an Explanation.
				// not sure why, but is somewhat corroborated by the code:
				// http://massapi.com/class/ex/Explanation.html
				// showing a single hit creating both a C.E and an E.
				// a more robust approach might be to look for the summary to end with product of: , sum of: etc.
				// e.g. http://www.gossamer-threads.com/lists/lucene/java-dev/49706
				// but for now, we'll count only the number of ComplexExplanation and check if its above threshold
//				log.info("doc id " + hits[i].toString() + " #details = " + details.length);
				
				// HORRIBLE HACK! - because we don't know a better way to find the threshold
				outer:
				for (Explanation detail: details)
				{				
					// log.info(detail.getClass().getName());

					if (detail instanceof ComplexExplanation)
					{
						ComplexExplanation ce = (ComplexExplanation) detail;
						String s = ce.toString();
						int total_tf = 0;
						while (true)
						{
							int idx = s.indexOf("tf(termFreq(");
							if (idx < 0)
								break outer;
							s = s.substring(idx);
							idx = s.indexOf("=");
							if (idx < 0)
								break outer;
							s = s.substring(idx+1);
							int idx1 = s.indexOf(")");
							if (idx < 0)
								break outer;
							String num_str = s.substring(0, idx1);
							int num = 0; 
							try {
								num = Integer.parseInt(num_str);
							} catch (Exception e) {
								log.warn ("ERROR parsing complex expl: " + num_str);
							}
							total_tf += num;
							if (total_tf >= threshold)
							{
								result.add(docNum);
								break outer;
							}
						}
					}
				}
			}
		}
		// isearcher.close();
		log.info(n_added + " docs added to docNumMap cache");
		return result;
	}
	
	/** Until we use Lucene that has built-in support for regex, we manually handle regex pattern.
	 *  This is not perfect (as it is not grammar-based). It would be better to make QueryParser recognize regex.
	 *
	 * @param query string that can contain regex (embedded in //)
	 * @return query string where regex pattern is escaped with \\*\\? (which survives both QueryParser and StandardAnalyzer)
	 * e.g., /foo.*bar/ => \\*\\?foo.*bar\\*\\?
	 */
	private String escapeRegex(String q)
	{
		// watch out for nested escaping of "\" in the replace string
		q = q.replaceAll("(^|\\s|\\()/", "$1\\\\\\\\*\\\\\\\\?"); // opening "/"
		q = q.replaceAll("/($|\\s|\\))", "\\\\\\\\*\\\\\\\\?$1"); // closing "/"
		return q;
	}

	/** Until we use Lucene that has built-in support for regex, we manually handle regex pattern.
	 * 
	 * @param parsed query
	 * @return new query whose WildcardQuery's with regex pattern (according to escapeRegex) are converted to RegexQuery's
	 */
	private Query convertRegex(Query query)
	{
		if (query instanceof BooleanQuery) {
			BooleanQuery bquery = (BooleanQuery) query;
			BooleanQuery result = new BooleanQuery();
			for (BooleanClause c : bquery.clauses()) {
				result.add(new BooleanClause(convertRegex(c.getQuery()), c.getOccur()));
			}
			return result;
		} else if (query instanceof WildcardQuery) {
			Term term = ((WildcardQuery) query).getTerm();
			String text = term.text();
			final String regex_marker = "\\*\\?"; // this regex_marker causes QueryParser to detect it as WildcardQuery
			if (text.startsWith(regex_marker) && text.endsWith(regex_marker)) {
				return new RegexQuery(new Term(term.field(), text.substring(regex_marker.length(), text.length()-regex_marker.length())));
			}
		}

		return query;
	}
	
	/** returns collection of docNum's that hit, at least threshold times */
	public Collection<String> luceneLookup(String q, int threshold, IndexSearcher searcher, boolean originalContentOnly) throws CorruptIndexException, LockObtainFailedException, IOException, org.apache.lucene.queryParser.ParseException, GeneralSecurityException, ClassNotFoundException
	{
		// get as documents, then convert to ids
		return luceneLookupAsDocIds(q, threshold, searcher, originalContentOnly);
//		Collection<Document> lookedupDocs = luceneLookupAsDocuments(q, threshold, searcher);
//		Collection<String> result = new ArrayList<String>();
//		for (Document d: lookedupDocs)
//		{
//			String docNum = d.getFieldable("docNum").stringValue();
//			result.add(docNum);
//		}
//		return result;
	}

	public Set<EmailDocument> luceneLookupDocs(String q) throws CorruptIndexException, LockObtainFailedException, IOException, org.apache.lucene.queryParser.ParseException, GeneralSecurityException, ClassNotFoundException
	{
		return luceneLookupDocs(q, false /* original content only */);
	}
	
	/** returns collection of EmailDocs that hit */
	public Set<EmailDocument> luceneLookupDocs(String q, boolean originalContentOnly) throws CorruptIndexException, LockObtainFailedException, IOException, org.apache.lucene.queryParser.ParseException, GeneralSecurityException, ClassNotFoundException
	{
		Collection<String> docNums = luceneLookupAsDocNums(q, originalContentOnly);
		Set<EmailDocument> result = new LinkedHashSet<EmailDocument>();
		for (String docNum: docNums)
		{
			EmailDocument ed = docMap.get(docNum);
			if (ed != null)
			{
				if (ed.languages == null)
				{
					// extract languages for the doc from the index and store it in the document, so we don't have to compute it again
					String lang = getDoc(docNum).getFieldable("languages").stringValue();
					StringTokenizer st = new StringTokenizer(lang, ",");
					Set<String> langs = new LinkedHashSet<String>();
					while (st.hasMoreTokens())
						langs.add(st.nextToken());
					if (langs.size() == 0) // shouldn't happen, just defensive
						langs.add("english");
					ed.languages = langs;
				}
				result.add(ed);
			}
			else
				log.warn ("Inconsistent Index! Docnum " + docNum + " is a hit in the index, but is not in the doc map!");
		}
		return result;
	}

	// CAUTION: permanently change the index!
	public synchronized int removeEmailDocs(Collection<? extends edu.stanford.muse.index.Document> docs) throws IOException
	{
		if (iwriter != null) {
			throw new IOException("iwriter is not null. prepareForSerialization() should be called first.");
		}

		if (isearcher != null) {
			isearcher.close();
			isearcher = null;
		}

		stats = null; // stats no longer valid
		
		int count = docMap.size();

		IndexWriterConfig cfg = new IndexWriterConfig(MUSE_LUCENE_VERSION, analyzer);
		IndexWriter writer = new IndexWriter(directory, cfg);
		//IndexWriter writer = new IndexWriter(directory, analyzer, false, new IndexWriter.MaxFieldLength(250000));
		assert(writer.numDocs() == docMap.size());

		for (edu.stanford.muse.index.Document d : docs) {
			String id = d.getUniqueId();
			EmailDocument ed = docMap.get(id);
			assert(d == ed);
			docMap.remove(id);
			writer.deleteDocuments(new TermQuery(new Term("docNum", id)));
			log.info("Removed doc " + id + " from index");
		}
		
		writer.commit();

		assert(writer.numDocs() == docMap.size());

		writer.close();

		count -= docMap.size(); // number of removed docs
		assert(count == docs.size());
		return count;
	}

	public Set<String> getNames(edu.stanford.muse.index.Document d, boolean originalContentOnly)
	{
		try {
			return getNamesForDocIdAsSet(d.getUniqueId(), originalContentOnly);
		} catch (Exception e) { 
			Util.print_exception(e, log); 
			return new LinkedHashSet<String>(); 
		}
	}
	
	public Document getDoc(edu.stanford.muse.index.Document d) throws IOException
	{
		return getDoc(d.getUniqueId());
	}
	
	private void softAssertDocIdNotPresent(String docId) throws IOException
	{
		TermQuery q = new TermQuery(new Term("docNum", docId));
		TopDocs td = isearcher.search(q, 1); // there must be only 1 doc with this id anyway
		Util.softAssert(td.totalHits == 0, "Oboy! docId: " + docId + " already present in the index, don't try to add it again!");
	}

	// look up the doc from docNum assigned to it
	private Document getDoc(String docId) throws IOException
	{
		if (isearcher == null) {
			isearcher = new IndexSearcher(directory, true); // read-only=true
		}

		// warning: do not try; luceneLookupAsDocuments("docNum:" + id); because it only looks up the body field
		TermQuery q = new TermQuery(new Term("docNum", docId));
		TopDocs td = isearcher.search(q, 1); // there must be only 1 doc with this id anyway
		Util.softAssert(td.totalHits <= 1, "docId = " + docId + " is not unique!");
		ScoreDoc[] sd = td.scoreDocs;
		if (sd.length != 1)
		{
			// something went wrong... report it and ignore this doc
			Util.warnIf(true, "lookup failed for id " + docId);
			return null;
		}

		return isearcher.doc(sd[0].doc);
	}

	@Override
	public String getContents(edu.stanford.muse.index.Document d, boolean originalContentOnly)
	{
		Document doc = null;
		try {
			doc = getDoc(d);
		} catch (IOException e) {
			log.warn("Unable to obtain document " + d.getUniqueId() + " from index");
			e.printStackTrace();
			return null;
		}

		String contents = null;
		if (!Config.isPublicMode()) { // content is ignored in public mode
			try {
				if (originalContentOnly)
					contents = doc.get("body_original");
				else
					contents = doc.get("body_raw");
//				if (contents == null) {
//					log.warn("No body_raw field, falling back to body");// + this.toString()); // giving repeatedly/excessive stats info
//					contents = doc.get("body");
//				}
			}
			catch (Exception e) {
				log.warn("Exception " + e + " trying to read field 'body_raw/body': " + Util.ellipsize(Util.stackTrace(e), 350));
				contents = null;
			}
		}

		if (contents == null) { // fall back to 'names' (or in public mode)
			try {
				contents = doc.get("body_redacted");
			}
			catch (Exception e) {
				log.warn("Exception " + e + " trying to read field 'body_redacted': " + Util.ellipsize(Util.stackTrace(e), 350));
				contents = null;
			}
		}

		if (contents == null) { // fall back to 'names' (or in public mode)
			try {
				Set<String> names = getNamesForDocAsSet(doc, originalContentOnly);
				contents = Util.joinSort(Util.scrubNames(names), "\n"); // it seems <br> will get automatically added downstream
				/*
				contents = Util.joinSort(names, "<br/>\n");
				// note: no indexer annotate here (because its distracting in public view to have some links highlighted and some not)
				// will probably revisit soon

				// workaround for html tag in names. probably should remove these tags as part of NER.
				if (contents.contains("<")) {
					Set<String> plain_names = new LinkedHashSet<String>();
					for (String s : names) {
						s = s.replaceAll("</?[A-Za-z]+[^>]*>", "");
						plain_names.add(s);
					}
					contents = Util.joinSort(plain_names, "<br>\n");
				}
				*/
			}
			catch (Exception e) {
				log.warn("Exception " + e + " trying to read extracted names of " + this.toString());
				contents = null;
			}

			if (contents == null)
				contents = "\n\nContents not available.\n\n";
		}

		return contents;
	}

	public static void main (String args[]) throws IOException, ClassNotFoundException
	{
		LuceneIndexer li = new LuceneIndexer();
		EmailDocument ed = new EmailDocument("1");
		li.indexSubdoc("no subject", "doc 1", ed, null);
		li.close();
		li.analyzer = null; li.isearcher = null; li.parser = null; li.parserOriginal = null;
		Util.writeObjectToFile("/tmp/1", li);
		li = (LuceneIndexer) Util.readObjectFromFile("/tmp/1");
		if (((RAMDirectory) li.directory).getLockFactory() == null)
			 ((RAMDirectory) li.directory).setLockFactory(new SingleInstanceLockFactory());
		ed = new EmailDocument("2");
		li.indexSubdoc("no subject", "doc 2", ed, null);
		li.close();
	}
	
	/*
	@Override
	public Map<String, List<String>> getSentiments(edu.stanford.muse.index.Document d)
	{
		Map<String, List<String>> emotionWordsMap = new LinkedHashMap<String, List<String>>();
		for (String s[]: Sentiments.emotionsData)
		{
			String emotion = s[0];
			String emotionWords = s[1];
			StringTokenizer st = new StringTokenizer(emotionWords, "|");
			while (st.hasMoreTokens())
			{
				String word = st.nextToken();
				try {
					Set<EmailDocument> docs = luceneLookupDocs(emotionWords);
					if (!Util.nullOrEmpty(docs) && docs.contains(d))
					{
						List<String> list = emotionWordsMap.get(emotion);
						if (list == null)
						{
							list = new ArrayList<String>();
							emotionWordsMap.put(emotion, list);
						}
						list.add(word);
					}
				} catch (Exception e) { Util.print_exception(e, log); }
			}
		}

		emotionWordsMap = Util.sortMapByListSize(emotionWordsMap);
		return emotionWordsMap;
	}
	 */
	
}
