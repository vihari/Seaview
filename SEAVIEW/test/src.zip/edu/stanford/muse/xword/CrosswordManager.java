package edu.stanford.muse.xword;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;

import edu.stanford.muse.email.CalendarUtil;
import edu.stanford.muse.email.Filter;
import edu.stanford.muse.email.MuseEmailFetcher;
import edu.stanford.muse.exceptions.CancelledException;
import edu.stanford.muse.exceptions.NoDefaultFolderException;
import edu.stanford.muse.index.Archive;
import edu.stanford.muse.index.DatedDocument;
import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.Util;
import edu.stanford.muse.webapp.Sessions;

public class CrosswordManager {
	private static final long serialVersionUID = 1L;
    public static Log log = LogFactory.getLog(CrosswordManager.class);

	public static int N_MESSAGES = 500;
	Filter filter;
	
	transient MuseEmailFetcher fetcher;
	int nMessagesFetched;
	Date earliestFetched; // content from this date onwards is already in archive
	public Archive archive;
	private boolean exhausted = false;
	
	List<Pair<Date, Date>> levelDates = new ArrayList<Pair<Date, Date>>();
	
	public CrosswordManager (Archive archive, MuseEmailFetcher mef)
	{
		this.archive = archive;
		this.fetcher = mef;
	}
	
	public boolean exhausted() { return exhausted; }

	public void setupDocsForNextLevel(HttpSession session) throws UnsupportedEncodingException, MessagingException, InterruptedException, IOException, JSONException, NoDefaultFolderException, CancelledException
	{
		setupDocsForLevel(session, levelDates.size());
	}
	
	/** returns error message if any */
	public void setupDocsForLevel(HttpSession session, int level) throws UnsupportedEncodingException, MessagingException, InterruptedException, IOException, JSONException, NoDefaultFolderException, CancelledException
	{
		Collection<DatedDocument> messagesInThisWindow = null;
		Date currentStart, currentEnd;

		log.info("Setting up docs for xword level " + level);
		
		if (level > levelDates.size()) 
		{
			log.warn ("Can't ask for level " + level + " levelDates.size = " + levelDates.size());
			return;
		}
		
		if (level < levelDates.size())
		{
			currentStart = levelDates.get(level).getFirst();
			currentEnd = levelDates.get(level).getSecond();
		}
		else 
		{
			// level better be = levelDates.size
			int MAX_QUARTERS_TO_GO_BACK = 10;
			if (level == 0)
			{
				currentEnd = new Date();
				currentStart = CalendarUtil.quarterBeginning(currentEnd);
			}
			else
			{
				Pair<Date, Date> lastLevel = levelDates.get(levelDates.size()-1);
				currentStart = lastLevel.getFirst();
				currentEnd = new Date(currentStart.getTime()-1L);
				currentStart = CalendarUtil.quarterBeginning(currentEnd);
			}

			int nQuarters = 0;
			archive.initializeForReadWrite();
			// go back quarter by quarter
			while (true)
			{
				if (earliestFetched == null || currentStart.before(earliestFetched))
				{
					Filter filter = new Filter(true /* sentOnly */, currentStart, currentEnd, null /* search term */);
					fetcher.fetchAndIndexEmails(archive, filter, null, session, true, false, true, -1, -1, -1);
					earliestFetched = currentStart;
				}
				messagesInThisWindow = archive.docsInDateRange(currentStart, currentEnd);
				if (messagesInThisWindow.size() >= N_MESSAGES)
					break;
				if (++nQuarters >= MAX_QUARTERS_TO_GO_BACK)
					break;
				// bummer... not enough messages, go back another quarter
				currentStart = CalendarUtil.quarterBeginning(new Date(currentStart.getTime()-1L));
			}
			levelDates.add(new Pair<Date, Date>(currentStart, currentEnd));
			archive.postProcess();
			archive.finalizeForWrite();
			Sessions.saveSession(session, "default");
		}
		
		if (messagesInThisWindow.size() < N_MESSAGES)
			exhausted = true;

		messagesInThisWindow = archive.docsInDateRange(currentStart, currentEnd);
		log.info(messagesInThisWindow.size() + " messages in window from " + CalendarUtil.formatDateForDisplay(currentStart) + " to " + CalendarUtil.formatDateForDisplay(currentEnd));
		if (!Util.nullOrEmpty(messagesInThisWindow))
			session.setAttribute("emailDocs",  messagesInThisWindow);
	}
}
