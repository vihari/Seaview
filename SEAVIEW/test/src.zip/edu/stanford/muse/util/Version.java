package edu.stanford.muse.util;
public class Version {  public static final String num = "0.9.47 (beta)"; 
public static final String buildInfo = "Built by hangal, Fri 15 Feb 2013 3:19 AM";} 
