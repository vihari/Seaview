/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.slant;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import twitter4j.PagableResponseList;
import twitter4j.ResponseList;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.User;
import twitter4j.auth.RequestToken;

import edu.stanford.muse.webapp.JSPHelper;

public class TwitterCallbackServlet extends HttpServlet {
	private static final long serialVersionUID = 1657390011452788111L;

	public static Logger logger = Logger.getLogger(TwitterCallbackServlet.class);
	SimpleLayout layout = new SimpleLayout();
	FileAppender appender = null;

	private static int indexurlcount=0;
	private static int totalurlcount=0;
	private static int duplicateurlcount=0;
	private static int shorturlcount=0;
	private static int rejectedurlcount=0;
	private static int top100urlcount=0;

	Twitter twitter ;
	String OAuthtoken;

	public String getURLInString(String arg) {
		String s = arg;
		// seperate input by spaces ( URLs don't have spaces )
		String [] parts = s.split("\\s");
		boolean urlFound=false;
		String weburl="";
		// Attempt to convert each item into an URL.   
		for( String item : parts ) try {
			URL url = new URL(item);
			urlFound= true;
			weburl=item;
			break;
		} catch (MalformedURLException e) {
			// If there was an URL that was not it!...
			//System.out.print( "malformed"+ item + " " );
			urlFound = false;
		}
		return weburl;

	}

	public boolean URLInString(String arg) {
		String s = arg;
		//System.out.print("url in string:"+arg );
		// seperate input by spaces ( URLs don't have spaces )
		String [] parts = s.split("\\s");
		boolean urlFound=false;
		// Attempt to convert each item into an URL.   
		for( String item : parts ) try {
			//System.out.print("item:"+item );
			URL url = new URL(item);
			// If possible then replace with anchor...
			totalurlcount++;
			urlFound= true;
			break;
		} catch (MalformedURLException e) {
			// If there was an URL that was not it!...
			//System.out.print( item + " " );
			urlFound = false;
		}
		return urlFound;

	}

	/*
	 * This method accepts the score i.e weight we assign to a url
	 * this helps us rerank results
	 */
	public void populateCSE(String authtoken,String domain,double score)
	{
		

		try
		{
			HttpClient client = new HttpClient();
			PostMethod annotation_post = new PostMethod("http://www.google.com/coop/api/default/annotations/");				

			String label;
			domain = URLEncoder.encode( domain, "UTF-8" );
			if(domain.indexOf("http")<0)
				label="<Annotation about=\"http://"+domain+"/*\" score=\""+ score+ "\">";
			else
				label="<Annotation about=\""+domain+" score=\""+ score+ "\">";
			String new_annotation ="<Batch>" +
					"<Add>" + 
					"<Annotations>" +
					label +
					"<Label name=\"_cse_testengine\"/>" +
	                 "</Annotation>" +
					"</Annotations>" +
					"</Add>" +
					"</Batch>";

			System.out.println("uploading annotation :"+ new_annotation);
			annotation_post.addRequestHeader("Content-type", "text/xml");
			annotation_post.addRequestHeader("Authorization", "GoogleLogin auth=" + authtoken);

			StringRequestEntity rq_en = new StringRequestEntity(new_annotation,"text/xml","UTF-8");
			annotation_post.setRequestEntity(rq_en);

			int astatusCode = client.executeMethod(annotation_post);


			if (astatusCode==HttpStatus.SC_OK)
			{
				System.out.println("Annotations updated");
				indexurlcount++;
			}
			else{
				System.out.println("Annotation update failed");
				String responseBody = IOUtils.toString(annotation_post.getResponseBodyAsStream(), "UTF-8");         
				System.out.println("Result remoteRequest: "+responseBody);
				System.out.println("Annotation update failed");
				rejectedurlcount++;
			}
		}
		catch(Exception e)
		{
			System.out.println("\nexception:"+e.getMessage());
		}
	}


	/*Overloaded
	 * 
	 * */
	 
	public void populateCSE(String authtoken,String domain,String rank)
	{
		double score=0.1;
		if(rank.equals("high"))
			score=1;
		if(rank.equals("medium"))
			score=0.8;

		try
		{
			HttpClient client = new HttpClient();
			PostMethod annotation_post = new PostMethod("http://www.google.com/coop/api/default/annotations/");				

			String label;
			domain = URLEncoder.encode( domain, "UTF-8" );
			if(domain.indexOf("http")<0)
				label="<Annotation about=\"http://"+domain+"/*\" score=\""+ score+ "\">";
			else
				label="<Annotation about=\""+domain+" score=\""+ score+ "\">";
			String new_annotation ="<Batch>" +
					"<Add>" + 
					"<Annotations>" +
					label +
					"<Label name=\"_cse_testengine\"/>" +
					"<Label name=\""+rank+"\"/>"+
					"</Annotation>" +
					"</Annotations>" +
					"</Add>" +
					"</Batch>";

			System.out.println("uploading annotation :"+ new_annotation);
			annotation_post.addRequestHeader("Content-type", "text/xml");
			annotation_post.addRequestHeader("Authorization", "GoogleLogin auth=" + authtoken);

			StringRequestEntity rq_en = new StringRequestEntity(new_annotation,"text/xml","UTF-8");
			annotation_post.setRequestEntity(rq_en);

			int astatusCode = client.executeMethod(annotation_post);


			if (astatusCode==HttpStatus.SC_OK)
			{
				System.out.println("Annotations updated");
				indexurlcount++;
			}
			else{
				System.out.println("Annotation update failed");
				String responseBody = IOUtils.toString(annotation_post.getResponseBodyAsStream(), "UTF-8");         
				System.out.println("Result remoteRequest: "+responseBody);
				System.out.println("Annotation update failed");
				rejectedurlcount++;
			}
		}
		catch(Exception e)
		{
			System.out.println("\nexception:"+e.getMessage());
		}
	}

	public void populateCSE(String authtoken,String domain)
	{
		try
		{
			HttpClient client = new HttpClient();
			PostMethod annotation_post = new PostMethod("http://www.google.com/coop/api/default/annotations/");				

			String label;
			domain = URLEncoder.encode( domain, "UTF-8" );
			if(domain.indexOf("http")<0)
				label="<Annotation about=\"http://"+domain+"/*\">";
			else
				label="<Annotation about=\""+domain+"\">";
			String new_annotation ="<Batch>" +
					"<Add>" + 
					"<Annotations>" +
					label +
					"<Label name=\"_cse_testengine\"/>" +
					"</Annotation>" +
					"</Annotations>" +
					"</Add>" +
					"</Batch>";

			System.out.println("uploading annotation :"+ new_annotation);
			annotation_post.addRequestHeader("Content-type", "text/xml");
			annotation_post.addRequestHeader("Authorization", "GoogleLogin auth=" + authtoken);

			StringRequestEntity rq_en = new StringRequestEntity(new_annotation,"text/xml","UTF-8");
			annotation_post.setRequestEntity(rq_en);

			int astatusCode = client.executeMethod(annotation_post);


			if (astatusCode==HttpStatus.SC_OK)
			{
				System.out.println("Annotations updated");
				indexurlcount++;
			}
			else{
				System.out.println("Annotation update failed");
				String responseBody = IOUtils.toString(annotation_post.getResponseBodyAsStream(), "UTF-8");         
				System.out.println("Result remoteRequest: "+responseBody);
				System.out.println("Annotation update failed");
				rejectedurlcount++;
			}
		}
		catch(Exception e)
		{
			System.out.println("\nexception:"+e.getMessage());
		}
	}
	
	public void annotateCSE(org.json.simple.JSONArray obj) {

		Map<String, Integer> m = new HashMap<String, Integer>();

		for(int i=0;i<obj.size();i++)
		{
			org.json.simple.JSONArray obj2=(org.json.simple.JSONArray)obj.get(i);
			for(int j=0;j<obj2.size();j++)
			{
				org.json.simple.JSONObject status=(org.json.simple.JSONObject)obj2.get(j);
				String jsonText = JSONValue.toJSONString(status);
				JSONParser parser = new JSONParser();
				KeyFinder finder = new KeyFinder();
				finder.setMatchKey("text");
				try{
					while(!finder.isEnd()){
						parser.parse(jsonText, finder, true);
						if(finder.isFound()){
							finder.setFound(false);
							//System.out.println("found text:");
							//System.out.println(finder.getValue());
							if(URLInString(finder.getValue().toString()))
							{
								String weburl= getURLInString(finder.getValue().toString());
								//System.out.println("weburl:"+ weburl);
								try{
									URL url;
									String tempurl=expandURL(weburl);
									url = new URL(tempurl);
									tempurl = url.getHost();
									Integer freq = m.get(tempurl);
									m.put(tempurl, (freq == null) ? 1 : freq + 1);

									//fix
									//publishCSE(weburl);
								}
								catch(Exception e)
								{
									System.out.println("\nexception:"+e.getMessage());
								}
							}
						}
					}           
				}
				catch(ParseException pe){
					pe.printStackTrace();
				}
			}
		}

		int high=0;
		int low=99;
		
		Iterator it = m.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry)it.next();
			//System.out.println(pairs.getKey() + " = " + pairs.getValue());
			Integer i=  (Integer)pairs.getValue();
			int count = i.intValue();
			if (count>high)
				high=count;
			if (count<low)
				low=count;
			
			
		}
		ValueComparator bvc =  new ValueComparator(m);
        TreeMap<String,Integer> sorted_map = new TreeMap(bvc);

		sorted_map.putAll(m);

      
        for (String key : sorted_map.keySet()) {
            System.out.println("key/value: " + key + "/"+sorted_map.get(key));
            String web=key;
			Integer i=  (Integer)sorted_map.get(key);
			int count = i.intValue();
			double score=0.9*count/(high -low)  ;
			
			if(isTop100(web))
			{
				score=score- (1/posTop100(web));
			}
			try
			{
				/*URL url;
				
				url = new URL(web);
				web = url.getHost();*/
				//populateCSE(OAuthtoken,weburl);
				//populateCSE(OAuthtoken,web,rank);
				populateCSE(OAuthtoken,web,score);
			}
			catch(Exception e)
			{
				System.out.println("problm in host");
			}
        }


		
		
	}


	class ValueComparator implements Comparator {

		  Map base;
		  public ValueComparator(Map base) {
		      this.base = base;
		  }

		  public int compare(Object a, Object b) {

		    if((Integer)base.get(a) >(Integer)base.get(b)) {
		      return 1;
		    } else if((Integer)base.get(a) == (Integer)base.get(b)) {
		      return 0;
		    } else {
		      return -1;
		    }
		  }
		}


	public int posTop100(String weburl)
	{
		URL url;
		String domain;
		try{
			url = new URL(weburl);
			domain = url.getHost();
		}
		catch(Exception e)
		{
			return 100;
		}
		for(int i=0;i< CustomSearchHelper.top100.length;i++)
		{
			if(domain.contains(CustomSearchHelper.top100[i]))
			{
				return i;
			}
		}

		return 100;
	}


	public boolean isTop100(String weburl)
	{
		URL url;
		String domain;
		try{
			url = new URL(weburl);
			domain = url.getHost();
		}
		catch(Exception e)
		{
			return false;
		}
		for(int i=0;i<CustomSearchHelper.top100.length;i++)
		{
			if(domain.contains(CustomSearchHelper.top100[i]))
			{
				top100urlcount++;
				return true;
			}
		}

		return false;
	}

	public boolean isShortURL(String weburl)
	{
		URL url;
		String domain;
		try{
			url = new URL(weburl);
			domain = url.getHost();
		}
		catch(Exception e)
		{
			return false;
		}
		for(int i=0;i< CustomSearchHelper.url_shorteners.length;i++)
		{
			if(domain.contains(CustomSearchHelper.url_shorteners[i]))
			{
				shorturlcount++;
				return true;
			}
		}

		return false;
	}

	public boolean isIndexed(String weburl)
	{
		try {
			String userHome = System.getProperty("user.home");  
			String file = userHome + "/tmp/urls.txt";
			BufferedReader in = new BufferedReader(new FileReader(file));
			String str;
			while ((str = in.readLine()) != null) {
				if (str.equals(weburl)||weburl.contains(str))
				{
					duplicateurlcount++;
					return true;
				}
			}
			in.close();
			return false;
		} catch (IOException e) {
			System.out.println("\nexception:"+e.getMessage());
			return false;
		}
	}

	public String expandURL(String weburl)
	{
		String longurl=weburl;
		System.out.println("\n input url is:"+weburl);
		try{
			//URL url = new URL(weburl);
			//String domain = url.getHost();
			//http://url-expander.appspot.com/expand.jsp?url=" + encodeURIComponent(mytxt);
			weburl=URLEncoder.encode( weburl, "UTF-8" );
			URL appurl = new URL("http://url-expander.appspot.com/expand.jsp?url="+weburl);
			System.out.println("\n input encoded url is: http://url-expander.appspot.com/expand.jsp?url="+weburl);
			URLConnection yc = appurl.openConnection();
			BufferedReader in = new BufferedReader(
					new InputStreamReader(
							yc.getInputStream()));
			String inputLine;

			while ((inputLine = in.readLine()) != null) 
			{
				System.out.println(inputLine);
				if(inputLine.length()>0)
					longurl=inputLine;
			}
			in.close();

		}
		catch (Exception e)
		{
			System.out.println("\nexception:"+e.getMessage());
		}
		System.out.println("\n output url is:"+longurl);
		return longurl;

	}


	//@deprecated
	public void publishCSE(String weburl)
	{


		URL url;
		try
		{
			weburl=expandURL(weburl);
			if(isIndexed(weburl)||isShortURL(weburl))
				return;
			String rank="high";
			if(isTop100(weburl))
			{
				rank="low";
			}


			url = new URL(weburl);
			weburl = url.getHost();
			//populateCSE(OAuthtoken,weburl);
			populateCSE(OAuthtoken,weburl,rank);
			String userHome = System.getProperty("user.home");  
			String file = userHome + "/tmp/urls.txt";
			FileWriter fstream = new FileWriter(file);
			BufferedWriter out = new BufferedWriter(fstream);
			//out.write(weburl);
			out.append(weburl);
			//Close the output stream
			out.close();

		}
		catch(Exception e)
		{
			System.out.println("\nexception:"+e.getMessage());
		}
	}



	public void buildCSE(String authtoken)
	{

		String response = "";
		try{
			HttpClient client = new HttpClient();

			//First perform the ClientLogin to get the authtoken
			//See http://code.google.com/apis/accounts/docs/AuthForInstalledApps.html

			PostMethod create_post = new PostMethod("http://www.google.com/cse/api/default/cse/testengine");


			String new_annotation ="<CustomSearchEngine  language=\"en\">" +
					"<Title> CSE </Title>" + 
					"<Description>Custom Search</Description>" + 
					"<Context>" +
					"<BackgroundLabels>"+
					"<Label name=\"_cse_testengine\" mode=\"FILTER\" />"+
					"<Label name=\"_cse_exclude_testengine\" mode=\"ELIMINATE\" />"+
					"<Label name=\"high\" mode=\"BOOST\" weight=\"1.0\"/>" +
					"<Label name=\"medium\" mode=\"BOOST\" weight=\"0.8\"/>" +
					"<Label name=\"low\" mode=\"BOOST\" weight=\"0.1\"/>" +
					"</BackgroundLabels>"+
					"</Context>"+
					"<LookAndFeel nonprofit=\"false\" />"+
					"</CustomSearchEngine>";


			create_post.addRequestHeader("Content-type", "text/xml");
			create_post.addRequestHeader("Authorization", "GoogleLogin auth=" + authtoken);

			StringRequestEntity rq_en = new StringRequestEntity(new_annotation,"text/xml","UTF-8");
			create_post.setRequestEntity(rq_en);

			int astatusCode = client.executeMethod(create_post);

			if (astatusCode==HttpStatus.SC_OK)
			{
				System.out.println("engine created");
				logger.log(Level.INFO, 
						"engine created");
			}
			else
			{
				System.out.println("creation failed");
				logger.log(Level.INFO, 
						"engine not created");
			}
			//If successful, the CSE annotation is displayed in the response.
			System.out.println(create_post.getResponseBodyAsString())	;

		}
		catch(Exception e)
		{
			System.out.println("\nexception:"+e.getMessage());
		}



	}

	public void Authenticate(String name,String pass)
	{
		//System.out.println("About to post\nURL: "+target+ "content: " + content);
		String response = "";
		try{
			URL url = new URL("https://www.google.com/accounts/ClientLogin");
			URLConnection conn = url.openConnection();
			// Set connection parameters.
			conn.setDoInput (true);
			conn.setDoOutput (true);
			conn.setUseCaches (false);
			// Make server believe we are form data...

			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			DataOutputStream out = new DataOutputStream (conn.getOutputStream ());
			
			String userHome = System.getProperty("user.home"); 
			String file = userHome + File.separator + "tmp" + File.separator + "cseconfig.txt";
		    BufferedReader in_user = new BufferedReader(new FileReader(file));
		    String str;
		    str = in_user.readLine();
		    if(str==null)
		    	str="musetestlogin2";
		    if(name==null)
		    	str="musetestlogin2";
		    if(pass==null)
		    	pass="whowonthelottery";
			String content = "accountType=HOSTED_OR_GOOGLE&Email="+name+"&Passwd="+pass+"&service=cprose&source=muse.chrome.extension";
			// Write out the bytes of the content string to the stream.
			//String content = "accountType=HOSTED_OR_GOOGLE&Email=musetestlogin2&Passwd=whowonthelottery&service=cprose&source=muse.chrome.extension";
			out.writeBytes(content);
			out.flush ();
			out.close ();
			// Read response from the input stream.
			BufferedReader in = new BufferedReader (new InputStreamReader(conn.getInputStream ()));
			String temp;
			while ((temp = in.readLine()) != null){
				response += temp + "\n";
			}
			temp = null;
			in.close ();
			System.out.println("Server response:\n'" + response + "'");

			//----
			String delimiter = "Auth=";
			/* given string will be split by the argument delimiter provided. */
			String [] token = response.split(delimiter);
			String authtoken=token[1];
			authtoken=authtoken.trim();
			authtoken = authtoken.replaceAll("(\\r|\\n)", "");
			OAuthtoken=authtoken;
			System.out.println("auth token is:"+ authtoken);
			buildCSE(authtoken);
		}
		catch(Exception e)
		{
			System.out.println("\nexception:"+e.getMessage());
		}
	}
	
	public ResponseList<User> findAllFriends() throws TwitterException{
		ResponseList<User> listFriends = null;
		long cursor = -1l;
		PagableResponseList<User> buffer = twitter.getFriendsStatuses( cursor );
		System.out.println("buffer.size() " + buffer.size());
		if (buffer.size()>0) {
			listFriends = buffer;
			while (buffer.hasNext()) {
				cursor = buffer.getNextCursor();
				buffer = twitter.getFriendsStatuses( cursor );
				listFriends.addAll(buffer);
			}
		}
		return listFriends;
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		twitter = (Twitter) JSPHelper.getSessionAttribute(request.getSession(), "twitter");
		RequestToken requestToken = (RequestToken) JSPHelper.getSessionAttribute(request.getSession(), "requestToken");
		String verifier = request.getParameter("oauth_verifier");
		org.json.simple.JSONArray obj;
		String name=request.getParameter("login");
		String pass=request.getParameter("password");
		Authenticate(name,pass);
		try {
			/*logger.log(Level.TRACE, 
            "And a trace message using log() method.");*/

			/*appender = new FileAppender(layout, "/home/abhinay/javalog.log", false);
			logger.addAppender(appender);*/

			twitter.getOAuthAccessToken(requestToken, verifier);
			request.getSession().removeAttribute("requestToken");
			String jsonObject="[";
			// start rate limiting coment here
			twitter.getFriendsTimeline();
			// ResponseList<Status> statuses = twitter.getFriendsTimeline();

			ResponseList<User> followees = findAllFriends();
			logger.log(Level.INFO, 
					"Number of people user is following: "+ followees.size());
			for (User followee : followees) {

				//System.out.println(status.getScreenName());
				//System.out.println(status.getStatusesCount());
				//Status sts=status.getStatus();
				//  System.out.println(sts.getText());
				try{
					URL url = new URL("http://api.twitter.com/1/statuses/user_timeline.json?screen_name="+followee.getScreenName());
					URLConnection connection = url.openConnection();
					InputStream in = connection.getInputStream();
					BufferedReader res = new BufferedReader(new InputStreamReader(in, "UTF-8"));
					StringBuffer sBuffer = new StringBuffer();
					String inputLine;
					while ((inputLine = res.readLine()) != null)
						sBuffer.append(inputLine);
					jsonObject+=sBuffer.toString()+",";   
					res.close();
				}
				catch(Exception e)
				{

				}

			}
			jsonObject=jsonObject.substring(0, jsonObject.length()-1)+"]";
			logger.log(Level.INFO, "json object is: "+jsonObject);
			obj = (org.json.simple.JSONArray) new JSONParser().parse(new StringReader(jsonObject));
			HttpSession session = request.getSession(true);

			//Check if our session variable is set, if so, get the session variable value
			//which is an Integer object, and add one to the value.
			//If the value is not set, create an Integer object with the default value 1.
			//Add the variable to the session overwriting any possible present values.
			// Integer param = (Integer) JSPHelper.getSessionAttribute(session, "MySessionVariable");
			if (obj != null) {
				session.setAttribute("MySessionJSON", obj);
				obj = (org.json.simple.JSONArray) JSPHelper.getSessionAttribute(session, "MySessionJSON");
			}

			//end rate limit comment here

			System.out.println(obj.toString());
		} catch (Exception e) {
			throw new ServletException(e);
		}
		Authenticate(name,pass);
		annotateCSE(obj);

		logger.log(Level.INFO, 
				"<Index URLs , Total Urls , Duplicate Urls , Short Urls , Rejected Urls , Top 100 domain urls>: "+ 
						"< "+indexurlcount+" , "+ totalurlcount +" , "+ duplicateurlcount +" , "+ shorturlcount +" , "+ rejectedurlcount +" , " + top100urlcount + ">");
		response.sendRedirect(request.getContextPath() + "/");
	}
}
