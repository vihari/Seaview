/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.email;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Session;
import javax.mail.Store;

import edu.stanford.muse.util.Pair;
import edu.stanford.muse.util.Util;

public class VerifyEmailSetup {

	public static Pair<Boolean, String> run ()
	{
        int totalMessages = -1;
        PrintStream savedOut = System.out;
        InputStream savedIn = System.in;
        
		try {
			   // Get a Properties object
	        Properties props = System.getProperties();
	        
	        // Get a Session object
	        Session session = Session.getInstance(props, null);
	        session.setDebug(true);
	        String filename = System.getProperty ("java.io.tmpdir") + File.separatorChar + "verifyEmailSetup";
	        PrintStream ps = new PrintStream(new FileOutputStream(filename));
	        System.setOut(ps);
	        System.setErr(ps);
	  
	        // Get a Store object
	        Store store = null;
	        store = session.getStore("imaps");
	        store.connect("imap.gmail.com", 993, "checkmuse", "ga104tes");
	        Folder folder = store.getFolder("[Gmail]/Sent Mail");
	        totalMessages = folder.getMessageCount();
	        // System.err.println (totalMessages + " messages!");
	        ps.close();
	        String contents = Util.getFileContents(filename);
	        System.out.println (contents);
	        return new Pair<Boolean, String>(Boolean.TRUE, contents);
		} catch (Exception e) {
			System.out.println ("Verification failed: " + Util.stackTrace(e));
			return new Pair<Boolean, String>(Boolean.FALSE, Util.stackTrace(e));
		} finally
		{
			System.setOut (savedOut);
			System.setIn (savedIn);
		}
	}
	
	public static void main (String args[])
	{
		run();
	}
}
