/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.email;

import java.util.LinkedHashSet;
import java.util.Set;

/* class to model a mailing list with some members */
public class MailingList implements java.io.Serializable {
	private final static long serialVersionUID = 1L;

	// SUPER_DEFINITE is when we have an explicit List-Post header
	public final static int SUPER_DEFINITE = 8, DEFINITE = 1, MAYBE = 2, DEFINITE_NOT = 4, DUNNO = 0;
	
	public Contact ci;
	public Set<Contact> members = new LinkedHashSet<Contact>();
//	public int state;
	
	public MailingList(Contact ci)
	{
		this.ci = ci;	
	}

	public void addMember(Contact c)
	{
		members.add(c);
	}
	
//	void setState(int x) { state = x; }
	
}
