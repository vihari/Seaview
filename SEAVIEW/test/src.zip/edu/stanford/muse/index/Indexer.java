/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.index;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import edu.stanford.muse.datacache.Blob;
import edu.stanford.muse.datacache.BlobStore;
import edu.stanford.muse.email.StatusProvider;
import edu.stanford.muse.util.JSONUtils;
import edu.stanford.muse.util.Util;

/* Note: this indexer is half-heartedly abstract. its closely tied to its only real implementation, LuceneIndexer. 
 * They can be pretty much seen as one class, though this might change if we want to create other indexers in the future.
 * it is also pretty closely tied with the summarizer (which generates cards).
 * the function of the indexer is to perform indexing, and provide a query interface to the index.
 * 
 * This index has 2-levels: Docs and MultiDocs (that themselves contain entire documents as subdocs) against each other,
 * The index can be looked up with specific terms, and returns subdocs that contain the term.
 * Index stores NER terms also.
 */
abstract public class Indexer implements StatusProvider, java.io.Serializable {
	
    static Log log = LogFactory.getLog(Indexer.class);
    private static final long serialVersionUID = 1L;

    static final int DEFAULT_SUBJECT_WEIGHT = 2; // weight given to email subject; 2 means subject is given 2x weight
    private static final boolean PHRASES_CAN_SPAN_EMPTY_LINE = false; // false by default, no external controls for this.
	// if false, empty line is treated as a sentence separator
    
	private static final int MAX_DOCUMENT_SIZE = 2000000000;
	public static final int MAX_MAILING_LIST_NAME_LENGTH = 20;
	public static final int N_TOP_TERMS_PICKED_PER_SUPERDOC = 30;
	public static final boolean MERGE_TERMS = false; // turned off since we're doing NER and only using unigrams

	IndexOptions io;
	private boolean cancel = false;
	protected List<LinkInfo> links = new ArrayList<LinkInfo>();
 	// Collection<String> dataErrors = new LinkedHashSet<String>();
 	
 	static class IndexStats implements java.io.Serializable {
 	    private static final long serialVersionUID = 1L;
 		int nTokens = 0, nStopTokens = 0, nDictTokens = 0;
 		long processedTextLength = 0, nProcessedNames = 0;
 		long processedTextLength_blob = 0, nProcessedNames_blob = 0;
 	}

 	IndexStats stats = new IndexStats();

 	protected List<MultiDoc> docClusters;
	Map<Integer,Integer> nonEmptyTimeClusterMap = new LinkedHashMap<Integer, Integer>(); // mapping of non-zero time cluster index to actual time cluster index
		private String clusterStats = "";
	
	public Map<String, Integer> locationCounts = new LinkedHashMap<String, Integer>(); // the # of times a string was listed as a location type by NER
	List<Document> docs = new ArrayList<Document>();
	List<Document> subdocs = new ArrayList<Document>();
	public Summarizer summarizer = new Summarizer(this);
	
	public Indexer(IndexOptions io) throws IOException
	{
		clear();
		this.io = io;
		try {
		if (io != null && io.do_NER)
			NER.initialize();
		} catch (Exception e) {
			Util.report_exception(e);
		}
	}

	public void clear()
	{
		cancel = false;
		links.clear();
		summarizer.clear();
	}

	public boolean clustersIncludeAllDocs(Collection<Document> docs)
	{
		Set<Document> allIndexerDocs = new LinkedHashSet<Document>();
		for (MultiDoc mdoc: docClusters)
			allIndexerDocs.addAll(mdoc.docs);
		for (Document doc: docs)
			if (!allIndexerDocs.contains(doc))
				return false;
		return true;
	}

	/*
	public Collection<String> getDataErrors()
	{
		return Collections.unmodifiableCollection(dataErrors);
	}
	*/
	
	private String computeClusterStats(List<MultiDoc> clusters)
	{
		int nClusters = clusters.size();
		String clusterCounts = "";
		for (MultiDoc mdoc: clusters)
			clusterCounts += mdoc.docs.size() + "-";
		return nClusters + " document clusters with message counts: " + clusterCounts;
	}

	/** quick method for extracting links only, without doing all the parsing and indexing - used by slant, etc. */
	public void extractLinks(Collection<Document> docs) throws IOException
	{
		try {
			for (Document d: docs)
			{
				if (cancel)
					break;

				String contents = "";
				if (!io.ignoreDocumentBody)
				{
					contents = getContents(d);
				}

				if (d instanceof EmailDocument)
				{
					// do preprocessing only for emails, not for other kinds of documents
					// int len = contents.length();
					List<LinkInfo> linksForThisDoc = new ArrayList<LinkInfo>();
					contents = preprocessDocument(d, contents, linksForThisDoc, io.includeQuotedMessages); // Util.getFileContents(inputPrefix + "." + ed.docNum);
					linksForThisDoc = removeDuplicateLinkInfos(linksForThisDoc);
					d.links = linksForThisDoc; // not necessarily needed, right ? should have been init'ed when we first read the contents of this Doc. but doesn't hurt.
					links.addAll(linksForThisDoc);
				}
			}
		} catch (Exception e) { Util.print_exception(e); }
	}

	
	/** NEEDS REVIEW.
	 * removes http links etc, adds them in linkList if it is not null. removes quoted parts of message */
	public static String preprocessDocument(Document doc, String text, List<LinkInfo> linkList, boolean inclQM) throws IOException
	{
		StringBuilder result = new StringBuilder();
		BufferedReader br = new BufferedReader(new StringReader(text));

		// stopper for the tokenizer when we meet a line that needs to be ignored
		String stopper = " . ";

		while (true)
		{
			String line = br.readLine();
			if (line == null)
				break;

			line = line.trim();

			if (!inclQM && line.startsWith(">")) // ignore quoted messages
			{
				result.append(stopper);
				continue;
			}

			// we often see lines like this just before a quoted block begins:
			// hangal@cs.stanford.edu wrote:
			// note: we ignore the line, regardless of whether includeQM is true,
			// because we never want to consider this line, it generates garbage results
			// note: should we break out here, not just continue ?!
			if (line.indexOf("@") >= 0 && line.endsWith("wrote:"))
			{
				result.append(stopper);
				continue;
			}

			if (line.startsWith("----") && line.indexOf("Original Message") >= 0)
			{
				result.append(stopper);
				continue;
			}

			// often there is an empty line separating sentences that otherwise don't have a punctuation separator.
			// e.g. regards, <empty line> <name>
			if (!PHRASES_CAN_SPAN_EMPTY_LINE && line.length() == 0)
			{
				result.append (stopper);
				continue;
			}

			// strip links
			if (line.toLowerCase().contains("http:"))
			{
				// replace http links with a stop word
				StringBuilder line1 = new StringBuilder();
				StringTokenizer st = new StringTokenizer(line, " \r\n\t<>\""); // tokenize based on things likely to identify starting of link, http://...
				while (st.hasMoreTokens())
				{
					String s = st.nextToken();
					s = Util.stripPunctuation(s);
					if (s.toLowerCase().startsWith("http:"))
					{
						if (linkList != null && doc != null)
							linkList.add(new LinkInfo(s, doc));
						line1.append (" . "); // arbitrary stop word in place of http link
					}
					else
						line1.append (s);

					line1.append (" ");
				}
				line = line1.toString(); // overwrite original line
			}

			result.append (line);
			result.append ("\n");
		}

		return result.toString();
	}

	/** computes term->list<docs> index.
	 * returns the list of names in the document text (if io.do_NER is true)
	 * this is used only to query a term for all docs that contain it.
	 * could also be done in a separate pass if its memory intensive.
	 * returns number of names processed 
	 * @param stats */
	abstract public  int indexSubdoc(String title, String documentText, Document doc, BlobStore optionalBlobStore);

	/* doc no longer links to its content on its own (i.e., no url field, no contents file). 
	 * thus, indexer has to implement a mechanism to supply the content of the requested doc. 
	 */
	abstract public String getContents(Document doc);

	public String computeStats()
	{
		return computeStats(true);
	}

	public String computeStats(boolean blur)
	{		
		String result = "Index options: " + io.toString(blur) + "\n" + currentJobDocsetSize + " post-filter docs and " +
				docs.size() + " multi-docs\n" +
			   clusterStats + "\n";
		if (stats != null)
		{
			result +=
			   Util.commatize(stats.processedTextLength/1024) + "K chars processed, " + stats.nProcessedNames + " names\n" +
			   Util.commatize(stats.processedTextLength_blob/1024) + "K chars of attachments processed, " + stats.nProcessedNames_blob + " names in attachments\n" +
			   Util.commatize(InternTable.getSizeInChars()) + " chars in " + Util.commatize(InternTable.getNEntries()) + " entries in intern table\n";
		}
		Util.getMemoryStats();

		return result;
	}

	long currentJobStartTimeMillis = 0L;
	public int currentJobDocsetSize, currentJobDocsProcessed, currentJobErrors;

	public void cancel()
	{
		cancel = true;
		log.warn ("Indexer cancelled!");
	}

	public boolean isCancelled() { return cancel; }

	public String getStatusMessage()
	{
		if (currentJobDocsetSize == 0)
			return JSONUtils.getStatusJSON("Starting indexer...");

		// compute how much time remains
		long elapsedTimeMillis = System.currentTimeMillis() - currentJobStartTimeMillis;
		long unprocessedTimeSeconds = -1;

		// compute unprocessed message
		if (currentJobDocsProcessed != 0)
		{
			long unprocessedTimeMillis = (currentJobDocsetSize - currentJobDocsProcessed) * elapsedTimeMillis/currentJobDocsProcessed;
			unprocessedTimeSeconds = unprocessedTimeMillis / 1000;
		}

		int doneCount = currentJobDocsProcessed + currentJobErrors;
		String descriptor = (io.ignoreDocumentBody) ? "headers" : " messages";
		int pctComplete = (doneCount*100)/currentJobDocsetSize;
		String processedMessage = "";
		if (pctComplete < 100)
			processedMessage = "Indexing " + Util.commatize(currentJobDocsetSize) + " " + descriptor;
		else
		{
			processedMessage = "Creating summaries...";
			unprocessedTimeSeconds = -1L;
		}
		return JSONUtils.getStatusJSON(processedMessage, pctComplete, elapsedTimeMillis/1000, unprocessedTimeSeconds);
	}

	/** -1 => all clusters */
	public List<Document> getDocsInCluster(int clusterNum)
	{
		List<Document> result = new ArrayList<Document>();
		if (clusterNum < 0)
		{
			for (MultiDoc md: docClusters)
				result.addAll(md.docs);
		}
		else
		{
			MultiDoc clusterDocs = docClusters.get(clusterNum);
			result.addAll(clusterDocs.docs);
		}
		return result;
	}
	
	/** we're done indexing, optimize for storage, and prepare for queries, if applicable */
	abstract protected void packIndex();
	abstract public Set<edu.stanford.muse.index.Document> docsForQuery(String term, int cluster, int threshold);
	abstract public Set<Blob> blobsForQuery(String term);
	abstract public int countHitsForQuery(String term);
	abstract public List<String> getNamesForDocId(String id) throws IOException;
	abstract public Set<String> getNames(edu.stanford.muse.index.Document doc);

	public Set<edu.stanford.muse.index.Document> docsForQuery(String term, int cluster)
	{
		return docsForQuery(term, cluster, 1);
	}

	public String getHTMLAnnotatedDocumentContents(String contents, Date d, String docId, Set<String> stemmedTermsToHighlight, Set<String> unstemmedTermsToHighlight) throws Exception
	{
		return Highlighter.getHTMLAnnotatedDocumentContents(contents, d, docId, stemmedTermsToHighlight, unstemmedTermsToHighlight, 
									null, summarizer.importantTermsCanonical /* unstemmed because we are only using names */);
	}

	// remove any duplicate link URLs from the incoming LinkInfos
	private static List<LinkInfo> removeDuplicateLinkInfos(List<LinkInfo> input)
	{
		List<LinkInfo> result = new ArrayList<LinkInfo>();
		Set<String> seenURLs = new LinkedHashSet<String>();
		for (LinkInfo li: input)
			if (!seenURLs.contains(li.link))
			{
				result.add(li);
				seenURLs.add(li.link);
			}
		return result;
	}

	public List<LinkInfo> getLinks()
	{
		return links;
	}

	/** note a data error that occurs during indexing */
	/**
	 * FLAG DEBUG: remove this
	private void markDataError(String s) 
	{
		log.warn ("DATA WARNING:" + s);
		if (dataErrors == null)
			dataErrors = new ArrayList<String>();
		dataErrors.add(s);
	}
	 */	
	/** main entry point for indexing. note: recomputeCards has to be called separately */
	/*
	void processDocumentCollection(List<MultiDoc> mDocs, List<Document> docs, BlobStore blobStore) throws Exception
	{
		log.info ("Processing " + docs.size() + " documents");
		try {
			indexDocumentCollection(mDocs, docs, blobStore);
		} catch (OutOfMemoryError oome) {
			log.error ("Sorry, out of memory, results may be incomplete!");
			clear();
		}		
	}
	
	/** preprocessed and indexes the docs. */
	/*
	private void indexDocumentCollection(List<MultiDoc> mDocs, List<Document> allDocs, BlobStore blobStore) throws Exception
	{
		this.clear();
		currentJobStartTimeMillis = System.currentTimeMillis();
		currentJobDocsetSize = allDocs.size();
		currentJobDocsProcessed = currentJobErrors = 0;

		System.gc();
		String stat1 = "Memory status before indexing " + allDocs.size() + " documents: " + Util.getMemoryStats();
		log.info (stat1);
		docClusters = mDocs;

		if (io.do_NER)
			NER.printAllTypes();

		computeClusterStats(mDocs);
		log.info ("Indexing " + allDocs.size() + " documents in " + docClusters.size() + " clusters");
		int clusterCount = -1;
		int docsIndexed = 0, multiDocsIndexed = 0;
		Posting.nPostingsAllocated = 0;
		docClusters = mDocs;

		try {
			for (MultiDoc md: docClusters)
			{
				clusterCount++;
				log.info ("-----------------------------");
				log.info ("Indexing " + md.docs.size() + " documents in document cluster #" + clusterCount + ": " + md.description);

				for (Document d: md.docs)
				{
					if (cancel)
						throw new CancelledException();

					String contents = "";
					if (!io.ignoreDocumentBody)
					{
						try {
							contents = d.getContents();
						} catch (Exception e) {
							markDataError ("Exception trying to read " + d + ": " + e);
						}
					}

					if (contents.length() > MAX_DOCUMENT_SIZE)
					{
						markDataError ("Document too long, size " + Util.commatize(contents.length()) + " bytes, dropping it. Begins with: " + d + Util.ellipsize(contents, 80));
						contents = "";
					}
					
					String subject = d.getSubjectWithoutTitle();
					subject = EmailUtils.cleanupSubjectLine(subject);

					indexSubdoc(subject, contents, d, blobStore);

					docsIndexed++;
					currentJobDocsProcessed++;
				} // end cluster

				log.info ("Finished indexing multi doc " + md);
				if (md.docs.size() > 0)
					log.info ("Current stats:" + computeStats());

				multiDocsIndexed++;
				//			IndexUtils.dumpDocument(clusterPrefix, clusterText); // i don't think we need to do this except for debugging
				System.out.print("."); // goes to console, that's ok...

				if (md.docs.size() > 0)
				{
					String stat2 = ("Memory status after indexing " + docsIndexed + " of " + allDocs.size() + " documents in "
							+ multiDocsIndexed + " (non-zero) multi-docs, total text length " + stats.processedTextLength + " chars, " + stats.nProcessedNames + " names. " + Util.getMemoryStats());
					log.info (stat2);
				}
			}
		} catch (OutOfMemoryError oome) {
			String s = "REAL WARNING! SEVERE WARNING! Out of memory during indexing. Please retry with more memory!" + oome;
			s += "\n";
			log.error (s);
			// option: heroically soldier on and try to work with partial results
		}

		// imp: do this at the end to save memory. doesn't save memory during indexing but saves mem later, when the index is being used.
		// esp. important for lens.
		NER.release_classifier(); // release memory for classifier
		log.info ("Memory status after releasing classifier: " + Util.getMemoryStats());
		packIndex();
		
		return;
	}
	*/

	public String toString()
	{
		return computeStats();
	}
}
