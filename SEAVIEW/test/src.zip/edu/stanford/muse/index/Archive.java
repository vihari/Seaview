/*
 Copyright (C) 2012 The Stanford MobiSocial Laboratory

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edu.stanford.muse.index;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.store.LockObtainFailedException;

import edu.stanford.muse.datacache.Blob;
import edu.stanford.muse.datacache.BlobStore;
import edu.stanford.muse.datacache.FileBlobStore;
import edu.stanford.muse.email.AddressBook;
import edu.stanford.muse.email.Contact;
import edu.stanford.muse.email.FolderInfo;
import edu.stanford.muse.email.StatusProvider;
import edu.stanford.muse.groups.SimilarGroup;
import edu.stanford.muse.util.EmailUtils;
import edu.stanford.muse.util.Util;
import edu.stanford.muse.webapp.Config;
import edu.stanford.muse.webapp.Sessions;

/** Core data structure that represents an archive. 
    Conceptually, an archive is a collection of indexed messages (which can be incrementally updated), along with a blob store.
    It also has addressbooks, group assigner etc, which are second order properties -- they may be updated independently of the docs (in the future).
    allDocs is the indexed docs, NOT the ones in the current filter... need to work this out.
    An archive should be capable of being loaded up in multiple sessions simultaneously.    
    one problem currently is that summarizer is stored in indexer -- however, we should pull it out into per-session state.
    TODO: decide whether baseDir should be in here
*/
public class Archive implements Serializable {

    private static Log log = LogFactory.getLog(Archive.class);
	private final static long serialVersionUID = 1L;

	/** all of these things don't change based on the current filter */
	public Indexer indexer;
	private IndexOptions indexOptions;
	public BlobStore blobStore;
	public AddressBook addressBook;
	public GroupAssigner groupAssigner;
	private List<Document> allDocs; // this is the equivalent of fullEmailDocs earlier
	transient private Set<Document> allDocsAsSet = null;
	private Set<FolderInfo> fetchedFolderInfos = new LinkedHashSet<FolderInfo>(); // keep this private since its updated in a controlled way
	public Set<String> ownerNames = new LinkedHashSet<String>(), ownerEmailAddrs = new LinkedHashSet<String>();
	
	// clusters are somewhat ephemeral and not necessarily a core part of the Archive struct. consider moving it elsewhere.
    List<MultiDoc> docClusters;
    
	public void setBlobStore(BlobStore blobStore) { this.blobStore = blobStore;	}
	public void setGroupAssigner(GroupAssigner groupAssigner) { this.groupAssigner = groupAssigner;	}
	public void setAddressBook(AddressBook ab) { addressBook = ab;	}

	public BlobStore getBlobStore() { return blobStore; }
	public AddressBook getAddressBook() { return addressBook; }

	/* should happen rarely, only while exporting session. fragile operation, make sure blobStore etc are updated consistently */
	 public void setAllDocs(List<Document> docs) 
	{ 
		log.info("Updating archive's alldocs to new list of " + docs.size() + " docs");
		allDocs = docs; allDocsAsSet = null; 
	} 
	
	// private constructor
	private Archive() { }

	/** clear all fields, use when indexer needs to be completely cleared */
	public void clear() 
	{
		if (indexer != null)
			indexer.clear();
		if (allDocs != null)
			allDocs.clear();
		if (allDocsAsSet != null)
			allDocsAsSet.clear();
		groupAssigner = null;
		ownerEmailAddrs.clear(); 
		ownerNames.clear();
	}

	public void addOwnerNames(Collection<String> names) { ownerNames.addAll(names); }
	public void addOwnerEmailAddrs(Collection<String> emailAddrs) { ownerEmailAddrs.addAll(emailAddrs); }
	public void addOwnerEmailAddr(String emailAddr) { ownerEmailAddrs.add(emailAddr); }
	
	
	/** This should be the only place that creates the cache dir. */
	public static void prepareBaseDir(String dir)
	{
		new File(dir + File.separator).mkdirs();
		// copy lexicons over to the muse dir
		String[] lexicons = {"default.english.lex.txt", "default.chinese.lex.txt", "default.hindi.lex.txt", "default.kannada.lex.txt", "default.tamil.lex.txt"};
		log.info (lexicons.length + " lexicons copied to " + dir);
		for (String l: lexicons)
		{
			try {
				InputStream is = EmailUtils.class.getClassLoader().getResourceAsStream("lexicon/" + l);
				Util.copy_stream_to_file(is, dir + File.separator + l);
			} catch (Exception e) { Util.print_exception(e, log);}
		}
	}
	
	public static void clearCache(String cacheDir, String rootDir)
	{
		if (cacheDir != null)
		{
			// delete only indexes, blobs, sessions
			// keep sentiment stuff around
			Util.deleteDir(cacheDir + File.separatorChar + "blobs");
			Util.deleteDir(cacheDir + File.separatorChar + "indexes");
			Util.deleteDir(cacheDir + File.separatorChar + "sessions"); // could also call sessions.deleteallsessions, but lazy...

			// prepare cache dir anew
			prepareBaseDir(cacheDir);
		}
		
		// rootdir is used only for webapp/<user> (piclens etc) we'll get rid of it in future
		if (rootDir != null)
		{
			Util.deleteDir(rootDir);
			new File(rootDir + File.separator).mkdirs();
		}
	}

	/** returns the final, sorted, deduped version of allDocs that this driver worked on in its last run */
	public List<Document> getAllDocs()
	{
		if (allDocs == null) {
			synchronized (this) {
				if (allDocs == null) {
					allDocs = new ArrayList<Document>();
					allDocsAsSet = new LinkedHashSet<Document>();
				}
			}
		}
		return allDocs;
	}

	public Set<Document> getAllDocsAsSet()
	{
		// allDocsAsSet is lazily computed
		if (allDocsAsSet == null) {
			synchronized (this) {
				if (allDocsAsSet == null) {
					allDocsAsSet = new LinkedHashSet<Document>(getAllDocs());
					Util.softAssert(allDocs.size() == allDocsAsSet.size());
				}
			}
		}
		return allDocsAsSet;
	}

	public int nDocsInCluster(int i)
	{
		if (i < 0 || i >= docClusters.size())
			return -1;
		return docClusters.get(i).getDocs().size();
	}

	public int nClusters()
	{
		return docClusters.size();
	}

	// work in progress - status provider
	public StatusProvider getStatusProvider() { return indexer; }

	public Map<String, Set<Document>> getSentimentMap(Lexicon lex, String... captions)
	{
		return lex.getEmotions(indexer, getAllDocsAsSet(), false /* doNota */, captions);
	}
	
	// create a new/empty archive.
	// baseDir is for specifying base location of LuceneIndexer's file-based directories
	public void setup (String baseDir, String args[]) throws IOException
	{
		prepareBaseDir(baseDir);
		indexOptions = new IndexOptions();
		indexOptions.parseArgs(args);
		log.info ("Index options are: " + indexOptions);
//		indexer = new Indexer(indexOptions);
		indexer = new LuceneIndexer(baseDir, indexOptions);
	}

	public String getContents(Document d)
	{
		return indexer.getContents(d);
	}

	private void setupAddressBook(List<Document> docs)
	{
		// in this case, we don't care whether email addrs are incoming or outgoing,
		// so the ownAddrs can be just a null string
		if (addressBook == null)
			addressBook = new AddressBook((String[]) null, (String[]) null);
		log.info ("Setting up address book for " + docs.size() + " messages (indexing driver)");
		for (Document d: docs)
			if (d instanceof EmailDocument)
				addressBook.processContactsFromMessage((EmailDocument) d);

		addressBook.organizeContacts();
	}

	
	public List<LinkInfo> extractLinks(Collection<Document> docs) throws Exception
	{
		prepareAllDocs(docs, indexOptions);
		indexer.clear();
		indexer.extractLinks(docs);
		return EmailUtils.getLinksForDocs(docs);
	}
	
	public Collection<DatedDocument> docsInDateRange(Date start, Date end)
	{
		List<DatedDocument> result = new ArrayList<DatedDocument>();
		if (Util.nullOrEmpty(allDocs))
			return result;
		
		for (Document d: allDocs)
		{
			try {
				DatedDocument dd = (DatedDocument) d;
				if ((dd.date.after(start) && dd.date.before(end)) || dd.date.equals(start) || dd.date.equals(end))
					result.add(dd);
			} catch (Exception e) { }
		}
		return result;		
	}

	public boolean containsDoc(Document doc)
	{
		return getAllDocsAsSet().contains(doc);
	}

	/** core method, adds a single doc to the archive. remember to call postProcess at the end of any series of calls to add docs */
	public synchronized boolean addDoc(Document doc, String contents)
	{
		if (containsDoc(doc)) return false;

		getAllDocsAsSet().add(doc);
		getAllDocs().add(doc);

		String subject = doc.getSubjectWithoutTitle();
		subject = EmailUtils.cleanupSubjectLine(subject);

		indexer.indexSubdoc(subject, contents, doc, blobStore);

		if (getAllDocs().size() % 100 == 0)
			log.info("Memory status after " + getAllDocs().size() + " emails: " + Util.getMemoryStats());

		return true;
	}

	/** prepares all docs for indexing, incl. applying filters, removing dups and sorting 
	 * @throws Exception */
	private void prepareAllDocs(Collection<Document> docs, IndexOptions io) throws Exception
	{
		allDocs = new ArrayList<Document>();
		allDocs.addAll(docs);
		allDocs = EmailUtils.removeDupsAndSort(allDocs);
		log.info (allDocs.size() + " documents after removing duplicates");

		if (addressBook == null && !io.noRecipients)
		{
			log.warn ("no address book previously set up!");
			setupAddressBook(allDocs); // set up without the benefit of ownaddrs
		}

		if (io.filter != null && addressBook != null)
		{
			Contact ownCI = addressBook.getOwnContact(); // may return null if we don't have own info
			io.filter.setOwnContactInfo(ownCI);
		}

		// if no filter, accept doc (default)
		List<Document> newAllDocs = new ArrayList<Document>();
		for (Document d: allDocs)
			if (io.filter == null || (io.filter != null && io.filter.matches(d)))
				newAllDocs.add(d);
		
		EmailUtils.cleanDates(newAllDocs);

		log.info (newAllDocs.size() + " documents after filtering");

		allDocs = newAllDocs;
		Collections.sort (allDocs); // may not be essential
		allDocsAsSet = null;
	}

	/** set up doc clusters by group or by time*/
	public void prepareDocClusters(List<SimilarGroup<String>> groups)
	{
		/** by default, we only use month based clusters right now */
		if (indexOptions.categoryBased)
		{
			docClusters = IndexUtils.partitionDocsByCategory(allDocs);
		}
		else
		{
			if (groups != null)
			{
				Map<String, Set<EmailDocument>> groupsToDocsMap = IndexUtils.partitionDocsByGroup((Collection) allDocs, groups, addressBook, true);
				int i = 0;
				for (String groupName: groupsToDocsMap.keySet())
				{
					MultiDoc md = new MultiDoc(i++, groupName);
					docClusters.add(md);
					for (EmailDocument d: groupsToDocsMap.get(groupName))
						md.add(d);
				}
			}
			else
				docClusters = IndexUtils.partitionDocsByInterval((List) allDocs, indexOptions.monthsNotYears);
		}

		log.info (docClusters.size() + " clusters of documents");
	
	//	outputPrefix = io.outputPrefix;
		log.info (allDocs.size() + " documents in " + docClusters.size() + " time clusters, " + indexer.nonEmptyTimeClusterMap.size() + " non-empty");
	}
	
	/** adds a collection of folderinfo's to the archive, updating existing ones as needed */
	public void addFetchedFolderInfos(Collection<FolderInfo> fis)
	{
		// if a folderinfo with the same accountKey and longname already exists, its lastSeenUID may need to be updated.
		
		// first organize a key -> folder info map in case we have a large # of folders
		Map<String, FolderInfo> map = new LinkedHashMap<String, FolderInfo>();
		for (FolderInfo fi: fetchedFolderInfos)
		{
			String key = fi.accountKey + "..." + fi.longName;
			map.put(key, fi);
		}
		
		for (FolderInfo fi: fis)
		{
			String key = fi.accountKey + "..." + fi.longName;
			FolderInfo existing_fi = map.get(key);
			if (existing_fi != null)
			{
				if (existing_fi.lastSeenUID < fi.lastSeenUID)
					existing_fi.lastSeenUID = fi.lastSeenUID;
			}
			else
				fetchedFolderInfos.add(fi);
		}
	}
	
	/** returns last seen UID for the specified folder, -1 if its not been seen before */
	public long getLastUIDForFolder(String accountID, String fullFolderName)
	{
		// this is a linear time op -- could be made more efficient with a set / map if needed
		for (FolderInfo fi: fetchedFolderInfos)
		{
			if (fi.accountKey.equals(accountID) && fullFolderName.equals(fi.longName))
				return fi.lastSeenUID;
		}
		return -1L;
	}
	
	public void initializeForRead()
	{
		if (indexer instanceof LuceneIndexer) {
			LuceneIndexer li = (LuceneIndexer) indexer;
			li.setupForReadOnly();
		}
	}

	public void initializeForReadWrite() throws CorruptIndexException, LockObtainFailedException, IOException
	{
		if (indexer instanceof LuceneIndexer) {
			LuceneIndexer li = (LuceneIndexer) indexer;
			li.setupForReadWrite();
		}
	}

	public List<LinkInfo> postProcess()
	{
		return postProcess (allDocs, null);
	}

	/** should be called at the end of a series of calls to add doc to the archive. returns links.
	 * splits by groups if not null, otherwise by time (or category if specified in indexoptions)
	 * @throws Exception */
	public List<LinkInfo> postProcess(Collection<Document> docs, List<SimilarGroup<String>> groups)
	{
		// should we sort the messages by time here?
		
		log.info (indexer.computeStats());
		log.info (indexer.getLinks().size() + " links");
		//prepareAllDocs(docs, io);		
		prepareDocClusters(groups);		
		// TODO: indexer.summarizer.recomputeCards((Collection) allDocs, addressBook.getOwnNamesSet(), Summarizer.DEFAULT_N_CARD_TERMS);

		List<LinkInfo> links = indexer.getLinks();
		return links;
	}

	public void finalizeForWrite()
	{
		indexer.packIndex();
		try {
		if (blobStore != null)
			blobStore.pack(); // ideally, do this only if its dirty
		} catch (Exception e) { Util.print_exception(e, log); }
	}

	public void rollbackIndexWrites() throws IOException
	{
		if (indexer instanceof LuceneIndexer) {
			LuceneIndexer li = (LuceneIndexer) indexer;
			li.rollbackWrites();
		}
	}

	// replace subject with extracted names
	private static void replaceDescriptionWithNames(Collection<Document> allDocs) throws Exception
	{
		for (Document d : allDocs) {
			if (!Util.nullOrEmpty(d.description)) {
				log.info("Replacing description for docNum = " + d.docNum);
				List<String> names = LuceneIndexer.extractNames(d.description);
				Collections.sort(names);
				d.description = Util.join(names, LuceneIndexer.NAMES_FIELD_DELIMITER);
				// todo... title field in index also needs to be updated
			}
		}
	}
	
	/** export archive with just the given docs to prepare for public mode. docsToExport should be a subset of what's already in the archive.
	 * returns true if successful. */
	public boolean trimArchive(Collection<EmailDocument> docsToRetain) throws Exception
	{
		if (docsToRetain == null)
			return true; // return without doing anything
		
		// exports messages in current filter (allEmailDocs)
		//HttpSession session = request.getSession();
		Collection<Document> fullEmailDocs = this.getAllDocs();
		LuceneIndexer indexer = (LuceneIndexer) this.indexer;

		// compute which docs to remove vs. keep
		Set<Document> docsToKeep = new LinkedHashSet<Document>(docsToRetain);
		Set<Document> docsToRemove = new LinkedHashSet<Document>();
		for (Document d: fullEmailDocs)
			if (!docsToKeep.contains(d))
				docsToRemove.add(d);
		
		// remove unneeded docs from the index
		indexer.removeEmailDocs(docsToRemove);
		this.setAllDocs(new ArrayList<Document>(docsToRetain));

		// note: not updating contents file now
		// update the .contents file (remove the tagged docs from .contents and replace text with names)
		//	Sessions.updateContentsFile((Collection) docsToKeep, indexer, dir, false /* replace_text_with_names */);		
		return true;
	}
	
	/** a fresh archive is created under out_dir. 
	 * name is the name of the session under it.
	 * blobs are exported into this archive dir.
	 * destructive! but should be so only in memory.
	 * original files on disk should be unmodified.
	 * @throws Exception */
	public String export(boolean exportInPublicMode, String out_dir, String name) throws Exception
	{
		if (Util.nullOrEmpty(out_dir))
			return null;
		File dir = new File(out_dir);
		if (dir.exists() && dir.isDirectory())
			log.warn("Overwriting existing directory '" + out_dir + "' (it may already exist)");
		else if (!dir.mkdirs()) {
			log.warn("Unable to create directory: " + out_dir);
			return null;
		}
		Archive.prepareBaseDir(out_dir); // this gets us the default lexicon. ideally we should copy over lexicon/groups files also from the current archive...
		
		// replace subject line with names if in public mode
		if (exportInPublicMode)
		{
			replaceDescriptionWithNames(allDocs);
		}

		// copy index and if in public mode, also remove body, title fields
		String[] excludedFields = { "body_raw", "body", "title" };
		String[] noExcludedFields = {};
		((LuceneIndexer) indexer).copyDirectoryExcludeFields(out_dir, exportInPublicMode ? excludedFields : noExcludedFields);

		// write out the archive file
		String archiveDir = out_dir + File.separatorChar + "sessions";
		new File(archiveDir).mkdirs();
		Sessions.saveArchive(archiveDir + File.separatorChar + name + Sessions.SESSION_SUFFIX, this); // save .session file
		
		// save the blobs in a new blobstore
		Set<Blob> blobsToKeep = new LinkedHashSet<Blob>();
		for (Document d: allDocs)
			if (d instanceof EmailDocument)
				if (!Util.nullOrEmpty(((EmailDocument) d).attachments))
					blobsToKeep.addAll(((EmailDocument) d).attachments);		
		String blobsDir = out_dir + File.separatorChar + "blobs";
		new File(blobsDir).mkdirs();
		((FileBlobStore) blobStore).createCopy(blobsDir, blobsToKeep);	
		
		return out_dir;
	}
	
	public String getStats()
	{
		StringBuilder sb = new StringBuilder(allDocs.size() + " original docs with " + ownerEmailAddrs.size() + " email addresses " + ownerNames.size() + " names for owner");
		if  (addressBook != null)
			sb.append(addressBook.getStats() + "\n");
		sb.append (indexer.computeStats() + "\n" + indexer.getLinks().size() + " links");
		return sb.toString();
	}

	public static Archive createArchive()
	{
		return new Archive();
	}
	
	/** returns html for the given terms, with terms highlighted by the indexer.
	 * if IA_links is set, points links to the Internet archive's version of the page.
	 * docId is used to initialize a new view created by clicking on a link within this message,
	 * date is used to create the link to the IA */
	public String annotate(String s, Date date, String docId, Set<String> highlightTermsStemmed, Set<String> highlightTermsUnstemmed, boolean IA_links)
	{
		try {
			s = indexer.getHTMLAnnotatedDocumentContents(s, (IA_links?date:null), docId, highlightTermsStemmed, highlightTermsUnstemmed);
		} catch (Exception e) { log.warn ("indexer failed to annotate doc contents " + Util.stackTrace(e)); }

		return s;
	}
	
	// need to remove current dependency on indexer (only for debug).
	public StringBuilder getHTMLForContents(Document d, Date date, String docId, Set<String> highlightTermsStemmed, Set<String> highlightTermsUnstemmed, boolean IA_links) throws Exception
	{
		String contents = getContents(d);
		String htmlContents = annotate(contents, date, docId, highlightTermsStemmed, highlightTermsUnstemmed, IA_links);

		if (Config.isPublicMode())
			contents = Util.maskEmailDomain(htmlContents);

		StringBuilder sb = new StringBuilder();
		sb.append (htmlContents);
		return sb;
	}
	
	/* break up docs into clusters, based on existing docClusters */
	public List<MultiDoc> clustersForDocs(Collection<? extends Document> docs)
	{
		Map<Document, Integer> map = new LinkedHashMap<Document, Integer>();
		int i = 0;
		for (MultiDoc mdoc: docClusters)
		{
			for (Document d: mdoc.docs)
				map.put(d, i);
			i++;
		}

		List<MultiDoc> new_mDocs = new ArrayList<MultiDoc>();
		for (@SuppressWarnings("unused") MultiDoc md: docClusters)
			new_mDocs.add(null);

		for (Document d: docs)
		{
			int x = map.get(d);
			MultiDoc new_mDoc = new_mDocs.get(x);
			if (new_mDoc == null)
			{
				MultiDoc original = docClusters.get(x);
				new_mDoc = new MultiDoc(original.docNum, original.description);
				new_mDocs.set(x, new_mDoc);
			}
			new_mDoc.add(d);
		}

		List<MultiDoc> result = new ArrayList<MultiDoc>();
		for (MultiDoc md: new_mDocs)
			if (md != null)
				result.add(md);

		return result;
	}
}
